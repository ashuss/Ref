package com.capgemini.smarthire.reusable.transaction.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ROLE_MASTER")
public class RoleMasterEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ROLE_ID")
	private long roleId;
	
	@Column(name = "ROLE_NAME")
    private String roleName;
	
	@Column(name = "ACTIVE_FLAG")
    private Boolean activeFlag;
	
	@Column(name = "CREATED_BY")
    private String createdBy;
	
	@Column(name = "CREATED_DATE")
    private Date createdDate;
	
	@Column(name = "UPDATED_BY")
    private String updatedBy;
	
	@Column(name = "UPDATED_DATE")
    private Date updatedDate;
	
	@OneToMany(mappedBy="roleMasterEntity",cascade=CascadeType.ALL)
	@JsonIgnore
	private List<EmployeeRoleDetailsEntity> employeeRoleDetailsEntity;

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Boolean getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(Boolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public List<EmployeeRoleDetailsEntity> getEmployeeRoleDetailsEntity() {
		return employeeRoleDetailsEntity;
	}

	public void setEmployeeRoleDetailsEntity(List<EmployeeRoleDetailsEntity> employeeRoleDetailsEntity) {
		this.employeeRoleDetailsEntity = employeeRoleDetailsEntity;
	}
}
