package com.capgemini.smarthire.reusable.transaction.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "INTERVIEWER_CALENDAR")
public class InterviewerCalendarDetailsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "INTERVIEWER_CALENDAR_ID")
	private long interviewerCalendarId;

	@ManyToOne
	@JoinColumn(name = "EMP_ID")
	@JsonIgnore
	private EmployeeMasterEntity employeeMasterEntity;

	@OneToOne
	@JoinColumn(name = "RECRUITER_CALENDER_ID")
	private RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity;

	@Column(name = "IS_BOOKED")
	private boolean isBooked;

	@Column(name = "FROM_TIME")
	private Date fromTime;

	@Column(name = "TO_TIME")
	private Date toTime;

	@Column(name = "ACTIVE_FLAG")
	private Boolean activeFlag;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "UPDATED_BY")
	private String updatedBy;

	@Column(name = "UPDATED_DATE")
	private Date updatedDate;

	@Column(name = "FEEDBACK_COMMENT")
	private String feedbackComment;

	@ManyToOne
	@JoinColumn(name = "FEEDBACK_STATUS_ID")
	@JsonIgnore
	private FeedbackStatusEntity FeedbackStatusEntity;
	
	@ManyToOne
	@JoinColumn(name = "PARTICIPATION_TYPE_ID")
	@JsonIgnore
	private ParticipationTypeEntity participationTypeEntity;


	public long getInterviewerCalendarId() {
		return interviewerCalendarId;
	}

	public void setInterviewerCalendarId(long interviewerCalendarId) {
		this.interviewerCalendarId = interviewerCalendarId;
	}

	public EmployeeMasterEntity getEmployeeMasterEntity() {
		return employeeMasterEntity;
	}

	public void setEmployeeMasterEntity(EmployeeMasterEntity employeeMasterEntity) {
		this.employeeMasterEntity = employeeMasterEntity;
	}

	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public Date getToTime() {
		return toTime;
	}

	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}

	public Boolean getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(Boolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public RecruiterCalendarDetailsEntity getRecruiterCalendarDetailsEntity() {
		return recruiterCalendarDetailsEntity;
	}

	public void setRecruiterCalendarDetailsEntity(RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity) {
		this.recruiterCalendarDetailsEntity = recruiterCalendarDetailsEntity;
	}

	public boolean isBooked() {
		return isBooked;
	}

	public void setBooked(boolean isBooked) {
		this.isBooked = isBooked;
	}

	public String getFeedbackComment() {
		return feedbackComment;
	}

	public void setFeedbackComment(String feedbackComment) {
		this.feedbackComment = feedbackComment;
	}

	public FeedbackStatusEntity getFeedbackStatusEntity() {
		return FeedbackStatusEntity;
	}

	public void setFeedbackStatusEntity(FeedbackStatusEntity feedbackStatusEntity) {
		FeedbackStatusEntity = feedbackStatusEntity;
	}

	public ParticipationTypeEntity getParticipationTypeEntity() {
		return participationTypeEntity;
	}

	public void setParticipationTypeEntity(ParticipationTypeEntity participationTypeEntity) {
		this.participationTypeEntity = participationTypeEntity;
	}
}
