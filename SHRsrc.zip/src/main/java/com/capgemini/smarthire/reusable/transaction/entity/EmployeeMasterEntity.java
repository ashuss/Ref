package com.capgemini.smarthire.reusable.transaction.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "EMPLOYEE_MASTER")
public class EmployeeMasterEntity {

	@Id
	// @GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "EMP_ID")
	private long empId;

	@Column(name = "EMP_NAME")
	private String empName;

	@Column(name = "EMAIL_ID")
	private String emailId;

	@Column(name = "LOCATION")
	private String location;

	@Column(name = "ACTIVE_FLAG")
	private Boolean activeFlag;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "UPDATED_BY")
	private String updatedBy;

	@Column(name = "UPDATED_DATE")
	private Date updatedDate;

	@ManyToOne
	@JoinColumn(name = "GRADE_ID")
	@JsonIgnore
	private GradeMasterEntity gradeMasterEntity;

	@ManyToOne
	@JoinColumn(name = "BU_ID")
	@JsonIgnore
	private BUMasterEntity buMasterEntity;

	@OneToMany(mappedBy = "employeeMasterEntity", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<EmployeeRoleDetailsEntity> employeeRoleDetailsEntity;

	@OneToMany(mappedBy = "employeeMasterEntity", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<EmployeeTechnologyDetailsEntity> employeeTechnologyDetailsEntities;

	@OneToMany(mappedBy = "employeeMasterEntity", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<InterviewerCalendarDetailsEntity> interviewerCalenderDetailsEntities;

	@OneToMany(mappedBy = "interviewer", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<RecruiterCalendarDetailsEntity> recruiterCalendarDetailsEntityList;

	@OneToMany(mappedBy = "employeeMasterEntity", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<RecruiterCalendarDetailsEntity> recruiterCalendarDetailsEntities;

	@OneToMany(mappedBy = "supervisorMasterEntity", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<EmployeeMasterEntity> resources;

	@ManyToOne
	@JoinColumn(name = "SUPERVISOR_ID", referencedColumnName = "EMP_ID")
	@JsonIgnore
	private EmployeeMasterEntity supervisorMasterEntity;

	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Boolean getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(Boolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public GradeMasterEntity getGradeMasterEntity() {
		return gradeMasterEntity;
	}

	public void setGradeMasterEntity(GradeMasterEntity gradeMasterEntity) {
		this.gradeMasterEntity = gradeMasterEntity;
	}

	public List<EmployeeRoleDetailsEntity> getEmployeeRoleDetailsEntity() {
		return employeeRoleDetailsEntity;
	}

	public void setEmployeeRoleDetailsEntity(List<EmployeeRoleDetailsEntity> employeeRoleDetailsEntity) {
		this.employeeRoleDetailsEntity = employeeRoleDetailsEntity;
	}

	public List<EmployeeTechnologyDetailsEntity> getEmployeeTechnologyDetailsEntities() {
		return employeeTechnologyDetailsEntities;
	}

	public void setEmployeeTechnologyDetailsEntities(
			List<EmployeeTechnologyDetailsEntity> employeeTechnologyDetailsEntities) {
		this.employeeTechnologyDetailsEntities = employeeTechnologyDetailsEntities;
	}

	public List<InterviewerCalendarDetailsEntity> getInterviewerCalenderDetailsEntities() {
		return interviewerCalenderDetailsEntities;
	}

	public void setInterviewerCalenderDetailsEntities(
			List<InterviewerCalendarDetailsEntity> interviewerCalenderDetailsEntities) {
		this.interviewerCalenderDetailsEntities = interviewerCalenderDetailsEntities;
	}

	public List<RecruiterCalendarDetailsEntity> getRecruiterCalendarDetailsEntities() {
		return recruiterCalendarDetailsEntities;
	}

	public void setRecruiterCalendarDetailsEntities(
			List<RecruiterCalendarDetailsEntity> recruiterCalendarDetailsEntities) {
		this.recruiterCalendarDetailsEntities = recruiterCalendarDetailsEntities;
	}

	public List<RecruiterCalendarDetailsEntity> getRecruiterCalendarDetailsEntityList() {
		return recruiterCalendarDetailsEntityList;
	}

	public void setRecruiterCalendarDetailsEntityList(
			List<RecruiterCalendarDetailsEntity> recruiterCalendarDetailsEntityList) {
		this.recruiterCalendarDetailsEntityList = recruiterCalendarDetailsEntityList;
	}

	public BUMasterEntity getBuMasterEntity() {
		return buMasterEntity;
	}

	public void setBuMasterEntity(BUMasterEntity buMasterEntity) {
		this.buMasterEntity = buMasterEntity;
	}

	public List<EmployeeMasterEntity> getResources() {
		return resources;
	}

	public void setResources(List<EmployeeMasterEntity> resources) {
		this.resources = resources;
	}

	public EmployeeMasterEntity getSupervisorMasterEntity() {
		return supervisorMasterEntity;
	}

	public void setSupervisorMasterEntity(EmployeeMasterEntity supervisorMasterEntity) {
		this.supervisorMasterEntity = supervisorMasterEntity;
	}

}
