package com.capgemini.smarthire.reusable.transaction.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LOOKUP_MASTER")
public class LookupMasterEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOOKUP_ID")
	private long lookupId;
	
	@Column(name = "SCREEN_ID")
	private long screenId;
	
	@Column(name = "LOOKUP_ITEM")
	private String lookupItem;

	public long getLookupId() {
		return lookupId;
	}

	public void setLookupId(long lookupId) {
		this.lookupId = lookupId;
	}

	public long getScreenId() {
		return screenId;
	}

	public void setScreenId(long screenId) {
		this.screenId = screenId;
	}

	public String getLookupItem() {
		return lookupItem;
	}

	public void setLookupItem(String lookupItem) {
		this.lookupItem = lookupItem;
	}

}
