package com.capgemini.smarthire.reusable.transaction.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "BU_MASTER")
public class BUMasterEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "BU_ID")
    private long BUId;

    @Column(name = "BU_NAME")
    private String BUName;

    @Column(name = "ACTIVE_FLAG")
    private Boolean activeFlag;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    @OneToMany(mappedBy = "buMasterEntity", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<EmployeeMasterEntity> employeeMasterEntities;

    @OneToMany(mappedBy = "buMasterEntity", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<RecruiterCalendarDetailsEntity> recruiterCalendarDetailsEntities;

    public long getBUId() {
        return BUId;
    }

    public void setBUId(long bUId) {
        BUId = bUId;
    }

    public String getBUName() {
        return BUName;
    }

    public void setBUName(String bUName) {
        BUName = bUName;
    }

    public Boolean getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(Boolean activeFlag) {
        this.activeFlag = activeFlag;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public List<EmployeeMasterEntity> getEmployeeMasterEntities() {
        return employeeMasterEntities;
    }

    public void setEmployeeMasterEntities(List<EmployeeMasterEntity> employeeMasterEntities) {
        this.employeeMasterEntities = employeeMasterEntities;
    }

    public List<RecruiterCalendarDetailsEntity> getRecruiterCalendarDetailsEntities() {
        return recruiterCalendarDetailsEntities;
    }

    public void setRecruiterCalendarDetailsEntities(
            List<RecruiterCalendarDetailsEntity> recruiterCalendarDetailsEntities) {
        this.recruiterCalendarDetailsEntities = recruiterCalendarDetailsEntities;
    }

}
