package com.capgemini.smarthire.reusable.transaction.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "RECRUITER_CALENDAR")
public class RecruiterCalendarDetailsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RECRUITER_CALENDAR_ID")
	private long recruiterCalendarId;

	@ManyToOne
	@JoinColumn(name = "EMP_ID")
	@JsonIgnore
	private EmployeeMasterEntity employeeMasterEntity;

	@Column(name = "CANDIDATE_NAME")
	private String candidateName;

	@Column(name = "COMMENTS")
	private String comments;

	@Column(name = "IS_INTERVIEWER_ASSIGNED")
	private Boolean isInterviewerAssigned;

	@ManyToOne
	@JoinColumn(name = "TECHNOLOGY_ID")
	@JsonIgnore
	private TechnologyMasterEntity technologyMasterEntity;

	@ManyToOne
	@JoinColumn(name = "INTERVIEW_TYPE_ID")
	@JsonIgnore
	private InterviewTypeMasterEntity interviewTypeMasterEntity;

	@ManyToOne
	@JoinColumn(name = "INTERVIEWER_ID", nullable = true)
	private EmployeeMasterEntity interviewer;
	
	@ManyToOne
    @JoinColumn(name = "BU_ID")
    private BUMasterEntity buMasterEntity;

	@OneToOne(mappedBy = "recruiterCalendarDetailsEntity")
	private InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity;

	@Column(name = "FROM_TIME")
	private Date fromTime;

	@Column(name = "TO_TIME")
	private Date toTime;

	@Column(name = "ACTIVE_FLAG")
	private Boolean activeFlag;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "UPDATED_BY")
	private String updatedBy;

	@Column(name = "UPDATED_DATE")
	private Date updatedDate;

	public long getRecruiterCalendarId() {
		return recruiterCalendarId;
	}

	public void setRecruiterCalendarId(long recruiterCalendarId) {
		this.recruiterCalendarId = recruiterCalendarId;
	}

	public EmployeeMasterEntity getEmployeeMasterEntity() {
		return employeeMasterEntity;
	}

	public void setEmployeeMasterEntity(EmployeeMasterEntity employeeMasterEntity) {
		this.employeeMasterEntity = employeeMasterEntity;
	}

	public String getCandidateName() {
		return candidateName;
	}

	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}

	public TechnologyMasterEntity getTechnologyMasterEntity() {
		return technologyMasterEntity;
	}

	public void setTechnologyMasterEntity(TechnologyMasterEntity technologyMasterEntity) {
		this.technologyMasterEntity = technologyMasterEntity;
	}

	public InterviewTypeMasterEntity getInterviewTypeMasterEntity() {
		return interviewTypeMasterEntity;
	}

	public void setInterviewTypeMasterEntity(InterviewTypeMasterEntity interviewTypeMasterEntity) {
		this.interviewTypeMasterEntity = interviewTypeMasterEntity;
	}

	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public Date getToTime() {
		return toTime;
	}

	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}

	public EmployeeMasterEntity getInterviewer() {
		return interviewer;
	}

	public void setInterviewer(EmployeeMasterEntity interviewer) {
		this.interviewer = interviewer;
	}

	public Boolean getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(Boolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public InterviewerCalendarDetailsEntity getInterviewerCalendarDetailsEntity() {
		return interviewerCalendarDetailsEntity;
	}

	public void setInterviewerCalendarDetailsEntity(InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity) {
		this.interviewerCalendarDetailsEntity = interviewerCalendarDetailsEntity;
	}

	public Boolean getIsInterviewerAssigned() {
		return isInterviewerAssigned;
	}

	public void setIsInterviewerAssigned(Boolean isInterviewerAssigned) {
		this.isInterviewerAssigned = isInterviewerAssigned;
	}

	public String getComments() {
      return comments;
    }

    public void setComments(String comments) {
      this.comments = comments;
    }

    public BUMasterEntity getBuMasterEntity() {
        return buMasterEntity;
    }

    public void setBuMasterEntity(BUMasterEntity buMasterEntity) {
        this.buMasterEntity = buMasterEntity;
    }

}
