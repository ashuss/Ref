package com.capgemini.smarthire.reusable.transaction.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "INTERVIEW_GRADE_TYPE")
public class InterviewGradeTypeDetailsEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="INTERVIEW_GRADE_ID")
	private long interviewGradeId;
	
	@ManyToOne
	@JoinColumn(name="GRADE_ID")
	@JsonIgnore
	private GradeMasterEntity gradeMasterEntity;
	
	@ManyToOne
	@JoinColumn(name="INTERVIEW_TYPE_ID")
	@JsonIgnore
	private InterviewTypeMasterEntity interviewTypeMasterEntity;
	
	@Column(name = "CREATED_BY")
    private String createdBy;
	
	@Column(name = "CREATED_DATE")
    private Date createdDate;
	
	@Column(name = "UPDATED_BY")
    private String updatedBy;
	
	@Column(name = "UPDATED_DATE")
    private Date updatedDate;

	public long getInterviewGradeId() {
		return interviewGradeId;
	}

	public void setInterviewGradeId(long interviewGradeId) {
		this.interviewGradeId = interviewGradeId;
	}

	public GradeMasterEntity getGradeMasterEntity() {
		return gradeMasterEntity;
	}

	public void setGradeMasterEntity(GradeMasterEntity gradeMasterEntity) {
		this.gradeMasterEntity = gradeMasterEntity;
	}

	public InterviewTypeMasterEntity getInterviewTypeMasterEntity() {
		return interviewTypeMasterEntity;
	}

	public void setInterviewTypeMasterEntity(InterviewTypeMasterEntity interviewTypeMasterEntity) {
		this.interviewTypeMasterEntity = interviewTypeMasterEntity;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
}
