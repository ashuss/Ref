package com.capgemini.smarthire.reusable.transaction.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "EMPLOYEE_ROLE")
public class EmployeeRoleDetailsEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="EMP_ROLE_ID")
	private long empRoleId;
	
	@ManyToOne
	@JoinColumn(name="EMP_ID")
	@JsonIgnore
	private EmployeeMasterEntity employeeMasterEntity;
	
	@ManyToOne
	@JoinColumn(name="ROLE_ID")
	@JsonIgnore
	private RoleMasterEntity roleMasterEntity;
	
	@Column(name = "CREATED_BY")
    private String createdBy;
	
	@Column(name = "CREATED_DATE")
    private Date createdDate;
	
	@Column(name = "UPDATED_BY")
    private String updatedBy;
	
	@Column(name = "UPDATED_DATE")
    private Date updatedDate;

	public long getEmpRoleId() {
		return empRoleId;
	}

	public void setEmpRoleId(long empRoleId) {
		this.empRoleId = empRoleId;
	}

	public EmployeeMasterEntity getEmployeeMasterEntity() {
		return employeeMasterEntity;
	}

	public void setEmployeeMasterEntity(EmployeeMasterEntity employeeMasterEntity) {
		this.employeeMasterEntity = employeeMasterEntity;
	}

	public RoleMasterEntity getRoleMasterEntity() {
		return roleMasterEntity;
	}

	public void setRoleMasterEntity(RoleMasterEntity roleMasterEntity) {
		this.roleMasterEntity = roleMasterEntity;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
}
