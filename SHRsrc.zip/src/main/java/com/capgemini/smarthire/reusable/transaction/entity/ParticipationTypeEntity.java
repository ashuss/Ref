package com.capgemini.smarthire.reusable.transaction.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "PARTICIPATION_TYPE")
public class ParticipationTypeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PARTICIPATION_ID")
	private long participationId;

	@Column(name = "PARTICIPATION_NAME")
	private String participationName;

	@OneToMany(mappedBy = "participationTypeEntity", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<InterviewerCalendarDetailsEntity> interviewerCalendarDetailsEntitiyList;

	public long getParticipationId() {
		return participationId;
	}

	public void setParticipationId(long participationId) {
		this.participationId = participationId;
	}

	public String getParticipationName() {
		return participationName;
	}

	public void setParticipationName(String participationName) {
		this.participationName = participationName;
	}

	public List<InterviewerCalendarDetailsEntity> getInterviewerCalendarDetailsEntitiyList() {
		return interviewerCalendarDetailsEntitiyList;
	}

	public void setInterviewerCalendarDetailsEntitiyList(
			List<InterviewerCalendarDetailsEntity> interviewerCalendarDetailsEntitiyList) {
		this.interviewerCalendarDetailsEntitiyList = interviewerCalendarDetailsEntitiyList;
	}

}
