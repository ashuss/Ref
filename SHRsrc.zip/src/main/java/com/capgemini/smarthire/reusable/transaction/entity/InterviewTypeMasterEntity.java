package com.capgemini.smarthire.reusable.transaction.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "INTERVIEW_TYPE")
public class InterviewTypeMasterEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="INTERVIEW_TYPE_ID")
	private long interviewTypeId;
	
	@Column(name = "TYPE_NAME")
    private String typeName;
	
	@Column(name = "ACTIVE_FLAG")
    private Boolean activeFlag;
	
	@Column(name = "CREATED_BY")
    private String createdBy;
	
	@Column(name = "CREATED_DATE")
    private Date createdDate;
	
	@Column(name = "UPDATED_BY")
    private String updatedBy;
	
	@Column(name = "UPDATED_DATE")
    private Date updatedDate;
	
	@OneToMany(mappedBy="interviewTypeMasterEntity",cascade=CascadeType.ALL)
	@JsonIgnore
	private List<InterviewGradeTypeDetailsEntity> interviewGradeTypeDetailsEntities;
	
	@OneToMany(mappedBy="interviewTypeMasterEntity",cascade=CascadeType.ALL)
	@JsonIgnore
	private List<RecruiterCalendarDetailsEntity> recruiterCalendarDetailsEntities;

	public long getInterviewTypeId() {
		return interviewTypeId;
	}

	public void setInterviewTypeId(long interviewTypeId) {
		this.interviewTypeId = interviewTypeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Boolean getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(Boolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public List<InterviewGradeTypeDetailsEntity> getInterviewGradeTypeDetailsEntities() {
		return interviewGradeTypeDetailsEntities;
	}

	public void setInterviewGradeTypeDetailsEntities(
			List<InterviewGradeTypeDetailsEntity> interviewGradeTypeDetailsEntities) {
		this.interviewGradeTypeDetailsEntities = interviewGradeTypeDetailsEntities;
	}

	public List<RecruiterCalendarDetailsEntity> getRecruiterCalendarDetailsEntities() {
		return recruiterCalendarDetailsEntities;
	}

	public void setRecruiterCalendarDetailsEntities(List<RecruiterCalendarDetailsEntity> recruiterCalendarDetailsEntities) {
		this.recruiterCalendarDetailsEntities = recruiterCalendarDetailsEntities;
	}
}
