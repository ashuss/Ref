package com.tcg.empmgmt.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcg.empmgmt.dtos.EmpDataDto;
import com.tcg.empmgmt.dtos.EmpDetailsDto;
import com.tcg.empmgmt.dtos.ResponseDto;
import com.tcg.empmgmt.service.IEmpDataService;
import com.tcg.empmgmt.service.IEmpDetailsService;

@RestController
public class AdminController {
	@Autowired
	IEmpDetailsService iEmp;

	@Autowired
	IEmpDataService iData;

	@RequestMapping(value = "/addEmpData")
	public ResponseDto addUserData(@RequestBody EmpDetailsDto empDto) throws IOException {
		return iEmp.addEmpData(empDto);
	}

	@RequestMapping(value = "/searchUser/{emp_id}")
	public EmpDetailsDto searchEmpData(@PathVariable long emp_id) throws IOException {
		EmpDetailsDto emp = iEmp.findEmpByEmpId(emp_id);
		return emp;
	}

	@RequestMapping(value = "/addData")
	public ResponseDto addEmprData(@RequestBody EmpDataDto empDto) throws IOException {
		return iData.saveEmpDetails(empDto);
	}

}
