package com.tcg.empmgmt.repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.tcg.empmgmt.entity.EmpDetailsEntity;

public interface EmpDetailsRepository extends JpaRepository<EmpDetailsEntity, Long> {

	@Query("SELECT empMaster FROM EmpDetailsEntity empMaster WHERE empMaster.emp_id=?1")
	public List<EmpDetailsEntity> findEmpByEmpId(long emp_id);
}
