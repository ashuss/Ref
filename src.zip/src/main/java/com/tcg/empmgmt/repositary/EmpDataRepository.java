package com.tcg.empmgmt.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcg.empmgmt.entity.EmpDataEntity;


@Repository
public interface EmpDataRepository extends JpaRepository<EmpDataEntity, Long> {

}
