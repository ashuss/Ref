package com.tcg.empmgmt.dtos;

import java.sql.Time;
import java.util.Date;

public class EmpDataDto extends EmpDetailsDto {

	private String date;

	private String transport_mode;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTransport_mode() {
		return transport_mode;
	}

	public void setTransport_mode(String transport_mode) {
		this.transport_mode = transport_mode;
	}

}
