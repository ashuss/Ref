package com.tcg.empmgmt.dtos;

import java.util.List;

public class ResponseDto {
	private boolean success;
	private String data;
	private List<Object> response;
	private String message;

	public ResponseDto() {

	}

	public List<Object> getResponse() {
		return response;
	}

	public void setResponse(List<Object> response) {
		this.response = response;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public ResponseDto(boolean success, String data) {
		super();
		this.success = success;
		this.data = data;
	}

}
