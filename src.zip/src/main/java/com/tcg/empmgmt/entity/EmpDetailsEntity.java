package com.tcg.empmgmt.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EMP_MASTER")
public class EmpDetailsEntity {

	@Id
	@Column(name = "EMP_ID")
	private Long emp_id;

	@Column(name = "EMP_NAME")
	private String emp_name;

	@Column(name = "EMP_LOCATION")
	private String location;

	@Column(name = "PHONE_NO")
	private Long phone_no;

	@Column(name = "PROJECT_NAME")
	private String project_name;

	@Column(name = "MANAGER_NAME")
	private String manager_name;

	@OneToOne(mappedBy = "empDetailsEntity", cascade = CascadeType.ALL)
	private EmpDataEntity empDataEntity;

	public Long getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(Long emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Long getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(Long phone_no) {
		this.phone_no = phone_no;
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

	public String getManager_name() {
		return manager_name;
	}

	public void setManager_name(String manager_name) {
		this.manager_name = manager_name;
	}

	public EmpDataEntity getEmpDataEntity() {
		return empDataEntity;
	}

	public void setEmpDataEntity(EmpDataEntity empDataEntity) {
		this.empDataEntity = empDataEntity;
	}

}
