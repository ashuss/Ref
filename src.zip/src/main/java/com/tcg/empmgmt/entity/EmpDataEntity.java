package com.tcg.empmgmt.entity;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ADMIN_MASTER")
public class EmpDataEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EMP_MASTER_ID")
	private long empMasterId;

	@Column(name = "DATE")
	private Date date;

	// @Column(name = "TIME")
	// private Time leave_time;

	public long getEmpMasterId() {
		return empMasterId;
	}

	public void setEmpMasterId(long empMasterId) {
		this.empMasterId = empMasterId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	// public Time getLeave_time() {
	// return leave_time;
	// }
	//
	// public void setLeave_time(Time leave_time) {
	// this.leave_time = leave_time;
	// }

	@Column(name = "TRANSPORT_MODE")
	private String transport_mode;

	@OneToOne
	@JoinColumn(name = "EMP_ID", referencedColumnName = "EMP_ID")
	@JsonIgnore
	private EmpDetailsEntity empDetailsEntity;

	public String getTransport_mode() {
		return transport_mode;
	}

	public void setTransport_mode(String transport_mode) {
		this.transport_mode = transport_mode;
	}

	public EmpDetailsEntity getEmpDetailsEntity() {
		return empDetailsEntity;
	}

	public void setEmpDetailsEntity(EmpDetailsEntity empDetailsEntity) {
		this.empDetailsEntity = empDetailsEntity;
	}

	public long getContainerMasterId() {
		return empMasterId;
	}

	public void setContainerMasterId(long empMasterId) {
		this.empMasterId = empMasterId;
	}

}
