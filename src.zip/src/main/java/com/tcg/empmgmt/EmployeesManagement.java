package com.tcg.empmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class EmployeesManagement {

	public static void main(String[] args) {
		SpringApplication.run(EmployeesManagement.class, args);

	}

}
