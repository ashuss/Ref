package com.tcg.empmgmt.service;



import com.tcg.empmgmt.dtos.EmpDetailsDto;
import com.tcg.empmgmt.dtos.ResponseDto;

public interface IEmpDetailsService {

	public ResponseDto addEmpData(EmpDetailsDto empDto);

	public EmpDetailsDto findEmpByEmpId(long emp_id);
}
