package com.tcg.empmgmt.service;

import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcg.empmgmt.dtos.EmpDataDto;
import com.tcg.empmgmt.dtos.ResponseDto;
import com.tcg.empmgmt.entity.EmpDataEntity;
import com.tcg.empmgmt.entity.EmpDetailsEntity;
import com.tcg.empmgmt.repositary.EmpDataRepository;
import com.tcg.empmgmt.repositary.EmpDetailsRepository;

@Service
public class EmpDataServiceImpl implements IEmpDataService {

	@Autowired
	EmpDataRepository empDataRepository;

	@Override
	public ResponseDto saveEmpDetails(EmpDataDto empDto) {
		ResponseDto response = new ResponseDto();
		Date today = new Date();

		Time time1;
		String date1 = (empDto.getDate());

		Date date2;

		try {
			date2 = new SimpleDateFormat("yyyy-dd-MM hh:mm:ss").parse(date1);

			System.out.println("today " + today);
			System.out.println("empdata date " + empDto.getDate());
			if (date2.after(today)) {

				if (empDto.getTransport_mode() != null && empDto.getTransport_mode() != "") {
					EmpDataEntity empDataEntity = new EmpDataEntity();
					empDataEntity.setDate(date2);
					empDataEntity.setTransport_mode(empDto.getTransport_mode());
					EmpDetailsEntity empDetailsEntity = new EmpDetailsEntity();
					empDetailsEntity.setEmp_id(empDto.getEmp_id());
					empDetailsEntity.setEmp_name(empDto.getEmp_name());
					empDetailsEntity.setLocation(empDto.getLocation());
					empDetailsEntity.setManager_name(empDto.getManager_name());
					empDetailsEntity.setPhone_no(empDto.getPhone_no());
					empDetailsEntity.setProject_name(empDto.getProject_name());
					empDataEntity.setEmpDetailsEntity(empDetailsEntity);
					EmpDataEntity saveEmpDataEntity = empDataRepository.save(empDataEntity);
					response.setSuccess(true);
					response.setData("Employee Added Successfully");
				} else {
					response.setSuccess(false);
					response.setData("Failed to Add");
				}

			} else {
				System.out.println("Before");
			}
		} catch (ParseException e) {

			e.printStackTrace();
		}

		return response;
	}

}
