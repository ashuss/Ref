package com.tcg.empmgmt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcg.empmgmt.dtos.EmpDetailsDto;
import com.tcg.empmgmt.dtos.ResponseDto;
import com.tcg.empmgmt.entity.EmpDetailsEntity;
import com.tcg.empmgmt.repositary.EmpDetailsRepository;

@Service
public class EmpDetailsServiceImpl implements IEmpDetailsService {

	@Autowired
	EmpDetailsRepository empDetailsRepository;

	public ResponseDto addEmpData(EmpDetailsDto empDto) {
		ResponseDto response = new ResponseDto();
		if (empDto.getEmp_id() != null && empDto.getEmp_name() != "" && empDto.getEmp_name() != null
				&& empDto.getLocation() != null && empDto.getLocation() != "" && empDto.getManager_name() != null
				&& empDto.getManager_name() != "" && empDto.getPhone_no() != null && empDto.getProject_name() != null
				&& empDto.getProject_name() != "") {
			EmpDetailsEntity empDetailsEntity = new EmpDetailsEntity();
			empDetailsEntity.setEmp_id(empDto.getEmp_id());
			empDetailsEntity.setEmp_name(empDto.getEmp_name());
			empDetailsEntity.setLocation(empDto.getLocation());
			empDetailsEntity.setManager_name(empDto.getManager_name());
			empDetailsEntity.setPhone_no(empDto.getPhone_no());
			empDetailsEntity.setProject_name(empDto.getProject_name());
			EmpDetailsEntity saveEmpDetailsEntity = empDetailsRepository.save(empDetailsEntity);

			response.setSuccess(true);
			response.setData("Employee Added Successfully");

		} else {
			response.setSuccess(false);
			response.setData("Employee Name already exists.. ");
		}
		return response;
	}

	public EmpDetailsDto findEmpByEmpId(long emp_id) {
		EmpDetailsEntity empDetailsEntity = empDetailsRepository.findOne(emp_id);
		ResponseDto response = new ResponseDto();
		EmpDetailsDto empDto = null;
		List<EmpDetailsDto> empList = new ArrayList<>();

		empDto = new EmpDetailsDto();
		empDto.setEmp_id(empDetailsEntity.getEmp_id());
		empDto.setEmp_name(empDetailsEntity.getEmp_name());
		empDto.setLocation(empDetailsEntity.getLocation());
		empDto.setManager_name(empDetailsEntity.getManager_name());
		empDto.setPhone_no(empDetailsEntity.getPhone_no());
		empDto.setProject_name(empDetailsEntity.getProject_name());
		// empList.add(empDto);

		response.setSuccess(true);
		response.setMessage("Valid EmpId");
		return empDto;
	}

}
