package com.tcg.empmgmt.service;

import com.tcg.empmgmt.dtos.EmpDataDto;

import com.tcg.empmgmt.dtos.ResponseDto;

public interface IEmpDataService {

	public ResponseDto saveEmpDetails(EmpDataDto empDto);
}
