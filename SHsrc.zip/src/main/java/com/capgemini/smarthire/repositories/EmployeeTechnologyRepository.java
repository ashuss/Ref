package com.capgemini.smarthire.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.smarthire.reusable.transaction.entity.EmployeeTechnologyDetailsEntity;

public interface EmployeeTechnologyRepository extends JpaRepository<EmployeeTechnologyDetailsEntity, Long> {

    @Query("select e from EmployeeTechnologyDetailsEntity e where e.employeeMasterEntity.empId=?1 and e.technologyMasterEntity.technologyId=?2")
    public EmployeeTechnologyDetailsEntity findExisting(long id, long technologyId);

    @Query("select e.technologyMasterEntity.technologyName from EmployeeTechnologyDetailsEntity e where e.employeeMasterEntity.empId=?1")
    public List<String> getDetails(Long empId);
}
