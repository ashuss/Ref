package com.capgemini.smarthire.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.smarthire.reusable.transaction.entity.InterviewTypeMasterEntity;

public interface InterviewTypeMasterRepository extends JpaRepository<InterviewTypeMasterEntity, Long> {

}
