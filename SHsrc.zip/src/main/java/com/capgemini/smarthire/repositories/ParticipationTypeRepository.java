package com.capgemini.smarthire.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.smarthire.reusable.transaction.entity.ParticipationTypeEntity;



public interface ParticipationTypeRepository extends JpaRepository<ParticipationTypeEntity, Long> {

}
