package com.capgemini.smarthire.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.smarthire.reusable.transaction.entity.EmployeeMasterEntity;

public interface EmployeeMasterRepository extends JpaRepository<EmployeeMasterEntity, Long> {

    @Query("select e from EmployeeMasterEntity e where e.emailId=?1 and e.activeFlag=true")
    public EmployeeMasterEntity getEmployeeByEmail(String emailId);
    
    @Query("select e from EmployeeMasterEntity e where e.supervisorMasterEntity.emailId=?1")
    public List<EmployeeMasterEntity> getResources(String emailId);

}
