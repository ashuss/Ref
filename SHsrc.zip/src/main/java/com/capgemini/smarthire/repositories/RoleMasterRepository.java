package com.capgemini.smarthire.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.smarthire.reusable.transaction.entity.RoleMasterEntity;

public interface RoleMasterRepository extends JpaRepository<RoleMasterEntity, Long> {

    public RoleMasterEntity findByRoleName(String roleName);

    @Query("select r from RoleMasterEntity r where r.roleId in (select e.roleMasterEntity.roleId from EmployeeRoleDetailsEntity e where e.employeeMasterEntity.empId = ?1)")
	public List<RoleMasterEntity> findRoleByEmpId(long empId);
}
