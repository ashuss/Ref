package com.capgemini.smarthire.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.smarthire.reusable.transaction.entity.GradeMasterEntity;

public interface GradeMasterRepository extends JpaRepository<GradeMasterEntity, Long> {

    public GradeMasterEntity findByGradeName(String gradeName);
}
