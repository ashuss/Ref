package com.capgemini.smarthire.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.smarthire.reusable.transaction.entity.FeedbackStatusEntity;

public interface FeedbackStatusRepository extends JpaRepository<FeedbackStatusEntity, Long>{

}
