package com.capgemini.smarthire.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.smarthire.reusable.transaction.entity.RecruiterCalendarDetailsEntity;

public interface RecruiterCalendarDetailsRepository extends JpaRepository<RecruiterCalendarDetailsEntity, Long> {

    @Query("select r from RecruiterCalendarDetailsEntity r where r.employeeMasterEntity.emailId=?1 and r.employeeMasterEntity.activeFlag=true")
    public List<RecruiterCalendarDetailsEntity> findSlotsByEmail(String email);

    @Query("select r from RecruiterCalendarDetailsEntity r where extract(day from r.fromTime)=?1 and extract(month from r.fromTime)=?2 and extract(year from r.fromTime)=?3")
    public List<RecruiterCalendarDetailsEntity> findRecruiterCalenderList(int date, int month, int year);
   

}
