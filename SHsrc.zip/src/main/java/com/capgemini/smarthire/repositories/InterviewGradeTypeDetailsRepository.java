package com.capgemini.smarthire.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.smarthire.reusable.transaction.entity.InterviewGradeTypeDetailsEntity;

public interface InterviewGradeTypeDetailsRepository extends JpaRepository<InterviewGradeTypeDetailsEntity, Long> {

	@Query("SELECT i.interviewTypeMasterEntity.typeName FROM InterviewGradeTypeDetailsEntity i WHERE i.gradeMasterEntity.gradeId = ?1")
	public String findInterviewType(long gradeId);

}
