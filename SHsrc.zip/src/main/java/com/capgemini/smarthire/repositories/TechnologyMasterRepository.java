package com.capgemini.smarthire.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.smarthire.reusable.transaction.entity.TechnologyMasterEntity;

public interface TechnologyMasterRepository extends JpaRepository<TechnologyMasterEntity, Long> {

    public TechnologyMasterEntity findByTechnologyName(String technolgyName);
}
