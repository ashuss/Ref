package com.capgemini.smarthire.repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.smarthire.reusable.transaction.entity.EmployeeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.InterviewerCalendarDetailsEntity;

public interface InterviewerRepository extends JpaRepository<InterviewerCalendarDetailsEntity, Long> {

	@Query("select i from InterviewerCalendarDetailsEntity i where i.employeeMasterEntity.emailId=?1 and i.employeeMasterEntity.activeFlag=true")
	public List<InterviewerCalendarDetailsEntity> findSlotsByEmail(String email);
	
	@Query("select i from InterviewerCalendarDetailsEntity i where i.employeeMasterEntity.activeFlag=true and i.isBooked=false and i.fromTime > ?4 and (i.employeeMasterEntity.empId in (select t.employeeMasterEntity.empId from EmployeeTechnologyDetailsEntity t where t.technologyMasterEntity.technologyId = ?2)) and (i.employeeMasterEntity.gradeMasterEntity.gradeId in (select g.gradeMasterEntity.gradeId from InterviewGradeTypeDetailsEntity g where g.interviewTypeMasterEntity.interviewTypeId = ?1)) and (i.employeeMasterEntity.buMasterEntity.BUId = ?3)")
	public List<InterviewerCalendarDetailsEntity> findInterviewersSlots(long interviewerId, long technologyId, long buId, Date today);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime=?1 and i.toTime=?2 and i.employeeMasterEntity.empId=?3 and i.participationTypeEntity.participationId = ?4")
	public InterviewerCalendarDetailsEntity findCalenderBySlotAndIdAndParticipation(Date fromTime, Date toTime, long interviewerId, long participationTypeId);
	
	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime=?1 and i.toTime=?2 and i.employeeMasterEntity.empId=?3")
	public InterviewerCalendarDetailsEntity findCalenderBySlotAndId(Date fromTime, Date toTime, long interviewerId);

	@Query("select i.employeeMasterEntity from InterviewerCalendarDetailsEntity i where i.fromTime=?1 and i.isBooked=false and i.toTime=?2 and (i.employeeMasterEntity.empId in (select t.employeeMasterEntity.empId from EmployeeTechnologyDetailsEntity t where t.technologyMasterEntity.technologyId = ?3)) and (i.employeeMasterEntity.gradeMasterEntity.gradeId in (select g.gradeMasterEntity.gradeId from InterviewGradeTypeDetailsEntity g where g.interviewTypeMasterEntity.interviewTypeId = ?4)) and (i.employeeMasterEntity.buMasterEntity.BUId = ?5)")
	public List<EmployeeMasterEntity> fetchInterviewerDropdown(Date fromTime, Date toTime, long technologyId,
			long interviewTypeId, long buId);

	@Query("select i from InterviewerCalendarDetailsEntity i order by i.employeeMasterEntity.empId")
	public List<InterviewerCalendarDetailsEntity> slotsDetail();

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime>=?1 and i.toTime<=?2")
	public List<InterviewerCalendarDetailsEntity> getAvailibility(Date fromTime, Date toTime);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime>=?2 and i.toTime<=?3 and i.employeeMasterEntity.empId = ?1")
	public List<InterviewerCalendarDetailsEntity> fetchInterviewerReport(long empId, Date fromTime, Date toTime);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime>=?1 and i.toTime<=?2 and i.isBooked = true")
    public List<InterviewerCalendarDetailsEntity> findByToTimeAndFromTime(
                  Date fromtime, Date totime);
	
	@Query("select i from InterviewerCalendarDetailsEntity i where i.employeeMasterEntity.empId=?1 and i.fromTime>=?2 and i.toTime<=?3")
    public InterviewerCalendarDetailsEntity findParticipationType(long empid, Date fromtime, Date totime);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.technologyMasterEntity.technologyId = ?3")
	public List<InterviewerCalendarDetailsEntity> fetchReportByTechId(Date fromTime, Date toTime, long techId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.technologyMasterEntity.technologyId = ?3 and i.employeeMasterEntity.gradeMasterEntity.gradeId in (select e.gradeMasterEntity.gradeId from InterviewGradeTypeDetailsEntity e where e.interviewTypeMasterEntity.interviewTypeId = ?4)")
	public List<InterviewerCalendarDetailsEntity> fetchReportByTechIdAndTypeId(Date fromTime, Date toTime, long techId,
			long interviewTypeId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.employeeMasterEntity.empId in (select e.empId from EmployeeMasterEntity e where e.supervisorMasterEntity.empId = ?3) and ?4 in (select r.roleMasterEntity.roleId from EmployeeRoleDetailsEntity r where r.employeeMasterEntity.empId in (select e.empId from EmployeeMasterEntity e where e.supervisorMasterEntity.empId = ?3))")
	public List<InterviewerCalendarDetailsEntity> fetchSupervisorReport(Date fromTime, Date toTime, long empId, long roleId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.employeeMasterEntity.empId in (select e.empId from EmployeeMasterEntity e where e.supervisorMasterEntity.empId = ?3) and i.recruiterCalendarDetailsEntity.technologyMasterEntity.technologyId = ?4 and ?5 in (select r.roleMasterEntity.roleId from EmployeeRoleDetailsEntity r where r.employeeMasterEntity.empId in (select e.empId from EmployeeMasterEntity e where e.supervisorMasterEntity.empId = ?3))")
	public List<InterviewerCalendarDetailsEntity> fetchSupervisorReportByTech(Date fromTime, Date toTime, long empId,
			long techId, long roleId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.employeeMasterEntity.empId in (select e.empId from EmployeeMasterEntity e where e.supervisorMasterEntity.empId = ?3) and i.recruiterCalendarDetailsEntity.technologyMasterEntity.technologyId = ?4 and i.employeeMasterEntity.gradeMasterEntity.gradeId in (select e.gradeMasterEntity.gradeId from InterviewGradeTypeDetailsEntity e where e.interviewTypeMasterEntity.interviewTypeId = ?5) and ?6 in (select r.roleMasterEntity.roleId from EmployeeRoleDetailsEntity r where r.employeeMasterEntity.empId in (select e.empId from EmployeeMasterEntity e where e.supervisorMasterEntity.empId = ?3))")
	public List<InterviewerCalendarDetailsEntity> fetchSupervisorReportByTechAndType(Date fromTime, Date toTime,
			long empId, long techId, long interviewTypeId, long roleId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.technologyMasterEntity.technologyId = ?3 and i.employeeMasterEntity.gradeMasterEntity.gradeId in (select e.gradeMasterEntity.gradeId from InterviewGradeTypeDetailsEntity e where e.interviewTypeMasterEntity.interviewTypeId = ?4) and i.recruiterCalendarDetailsEntity.employeeMasterEntity.empId = ?5")
	public List<InterviewerCalendarDetailsEntity> fetchSupervisorResourceReportByTechIdAndTypeId(Date fromTime,
			Date toTime, long techId, long interviewTypeId, long empId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.technologyMasterEntity.technologyId = ?3 and i.recruiterCalendarDetailsEntity.employeeMasterEntity.empId = ?4")
	public List<InterviewerCalendarDetailsEntity> fetchSupervisorResourceReportByTechId(Date fromTime, Date toTime,
			long techId, long empId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.employeeMasterEntity.empId = ?3")
	public List<InterviewerCalendarDetailsEntity> fetchSupervisorResourceReport(Date fromTime, Date toTime, long empId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime>=?1 and i.toTime<=?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.technologyMasterEntity.technologyId = ?3")
	public List<InterviewerCalendarDetailsEntity> findByToTimeAndFromTimeAndTechId(Date fromTime, Date toTime,
			long techId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.recruiterCalendarDetailsEntity.employeeMasterEntity.empId in (select e.empId from EmployeeMasterEntity e where e.supervisorMasterEntity.empId = ?3) and i.employeeMasterEntity.gradeMasterEntity.gradeId in (select e.gradeMasterEntity.gradeId from InterviewGradeTypeDetailsEntity e where e.interviewTypeMasterEntity.interviewTypeId = ?4) and ?5 in (select r.roleMasterEntity.roleId from EmployeeRoleDetailsEntity r where r.employeeMasterEntity.empId in (select e.empId from EmployeeMasterEntity e where e.supervisorMasterEntity.empId = ?3))")
	public List<InterviewerCalendarDetailsEntity> fetchSupervisorReportByType(Date fromTime, Date toTime, long empId,
			long interviewTypeId, long roleId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.employeeMasterEntity.gradeMasterEntity.gradeId in (select e.gradeMasterEntity.gradeId from InterviewGradeTypeDetailsEntity e where e.interviewTypeMasterEntity.interviewTypeId = ?3) and i.recruiterCalendarDetailsEntity.employeeMasterEntity.empId = ?4")
	public List<InterviewerCalendarDetailsEntity> fetchSupervisorResourceReportByTypeId(Date fromTime, Date toTime,
			long interviewTypeId, long empId);

	@Query("select i from InterviewerCalendarDetailsEntity i where i.fromTime >= ?1 and i.toTime <= ?2 and i.isBooked = true and i.employeeMasterEntity.gradeMasterEntity.gradeId in (select e.gradeMasterEntity.gradeId from InterviewGradeTypeDetailsEntity e where e.interviewTypeMasterEntity.interviewTypeId = ?3)")
	public List<InterviewerCalendarDetailsEntity> fetchReportByTypeId(Date fromTime, Date toTime, long interviewTypeId);


}
