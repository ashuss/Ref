package com.capgemini.smarthire.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.repositories.EmployeeMasterRepository;
import com.capgemini.smarthire.repositories.EmployeeRoleRepository;
import com.capgemini.smarthire.repositories.RoleMasterRepository;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RoleMasterEntity;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    EmployeeMasterRepository employeeMasterRepository;

    @Autowired
    EmployeeRoleRepository employeeRoleRepository;

    @Autowired
    RoleMasterRepository roleMasterRepository;

    @Override
    public List<String> getRole(EmailDto emailDto) {
        List<String> roles = new ArrayList<>();
        EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository.getEmployeeByEmail(emailDto.getEmail());
        if (employeeMasterEntity != null) {
            List<RoleMasterEntity> roleMasterEntities = employeeRoleRepository
                    .findRoleByEmpId(employeeMasterEntity.getEmpId());
            for (RoleMasterEntity roleMasterEntity : roleMasterEntities) {
                roles.add(roleMasterEntity.getRoleName());
            }
        }
        return roles;
    }

}
