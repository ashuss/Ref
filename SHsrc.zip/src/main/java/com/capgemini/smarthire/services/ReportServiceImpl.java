package com.capgemini.smarthire.services;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.capgemini.smarthire.dtos.SmarthireReportDTO;
import com.capgemini.smarthire.repositories.InterviewerRepository;
import com.capgemini.smarthire.repositories.RecruiterCalendarDetailsRepository;
import com.capgemini.smarthire.reusable.transaction.entity.InterviewerCalendarDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RecruiterCalendarDetailsEntity;
import com.capgemini.smarthire.reusable.util.Utils;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;

@Service
public class ReportServiceImpl extends AbstractXlsView implements ReportService {

	private static final int HOUR = 5;
	private static final int MINUTES = 30;
	private static final short BLUE = HSSFColor.BLUE.index;

	@Autowired
	InterviewerRepository interviewerCalendarRepository;

	@Autowired
	RecruiterCalendarDetailsRepository recruiterRepo;

	@Override
	public void buildExcelDocument(SmarthireReportDTO reportDto, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		HSSFWorkbook workbook1 = new HSSFWorkbook();
		response.setContentType("application/xls");
		response.setHeader("content-disposition", "attachment;filename=" + "Report.xls");

		HSSFCellStyle style = workbook1.createCellStyle();
		style.setFillPattern(FillPatternType.FINE_DOTS);
		HSSFFont font = workbook1.createFont();
		font.setBold(true);
		font.setFontName(HSSFFont.FONT_ARIAL);
		style.setFont(font);

		ServletOutputStream writer = response.getOutputStream();
		HSSFSheet sheet = workbook1.createSheet("SpotQuoteData");
		HSSFSheet availableSheet = getAvailableSheet(workbook1, style, "AVAILABLE", 7);
		HSSFSheet bookedSheet = getBookedSheet(workbook1, style, "BOOKED");
		HSSFSheet interviewedSheet = getInterviewedSheet(workbook1, style, "INTERVIEWED");
		HSSFSheet notInterviewedSheet = getNotInterviewedSheet(workbook1, style, "NOT INTERVIEWED");

		HSSFRow header = sheet.createRow(0);
		header.createCell(0).setCellValue("EMP ID");
		header.getCell(0).setCellStyle(style);
		header.createCell(1).setCellValue("EMP NAME");
		header.getCell(1).setCellStyle(style);
		header.createCell(2).setCellValue("EMAIL ID");
		header.getCell(2).setCellStyle(style);
		header.createCell(3).setCellValue("CREATED DATE");
		header.getCell(3).setCellStyle(style);
		header.createCell(4).setCellValue("BOOKED DATE");
		header.getCell(4).setCellStyle(style);
		header.createCell(5).setCellValue("FROM TIME");
		header.getCell(5).setCellStyle(style);
		header.createCell(6).setCellValue("TO TIME");
		header.getCell(6).setCellStyle(style);
		header.createCell(7).setCellValue("IS BOOKED");
		header.getCell(7).setCellStyle(style);

		int rowNum = 1;

		List<InterviewerCalendarDetailsEntity> interviewerCalendarDetailsEntities = null;
		if (reportDto.getTechId() != 0 && reportDto.getInterviewTypeId() != 0) {
			interviewerCalendarDetailsEntities = interviewerCalendarRepository.fetchReportByTechIdAndTypeId(
					reportDto.getFromTime(), reportDto.getToTime(), reportDto.getTechId(),
					reportDto.getInterviewTypeId());
		} else if (reportDto.getTechId() != 0) {
			interviewerCalendarDetailsEntities = interviewerCalendarRepository
					.fetchReportByTechId(reportDto.getFromTime(), reportDto.getToTime(), reportDto.getTechId());
		} else {
			interviewerCalendarDetailsEntities = interviewerCalendarRepository.getAvailibility(reportDto.getFromTime(),
					reportDto.getToTime());
		}

		interviewerCalendarRepository.findAll();

		for (InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity : interviewerCalendarDetailsEntities) {
			HSSFRow row = sheet.createRow(rowNum++);
			String interviewerEmpId = String
					.valueOf(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId());
			String interviewerEmpName = interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName();
			String interviewerEmailId = interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId();
			String createdDate = Utils.dateToString(interviewerCalendarDetailsEntity.getCreatedDate());
			String fromdate = Utils.dateToString(interviewerCalendarDetailsEntity.getFromTime());
			String todate = Utils.dateToString(interviewerCalendarDetailsEntity.getToTime());
			String location = interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getLocation();

			DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			DateFormat timeFormat = new SimpleDateFormat("KK:mm a");
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

			Calendar from = Calendar.getInstance();
			from.setTime(inputFormat.parse(fromdate));
			from.add(Calendar.HOUR_OF_DAY, HOUR);
			from.add(Calendar.MINUTE, MINUTES);

			Calendar to = Calendar.getInstance();
			to.setTime(inputFormat.parse(todate));
			to.add(Calendar.HOUR_OF_DAY, HOUR);
			to.add(Calendar.MINUTE, MINUTES);

			String bookedDateExcel = dateFormat.format(inputFormat.parse(todate));
			String fromTimeExcel = timeFormat.format(from.getTime());
			if ("00:00 PM".equals(fromTimeExcel)) {
				fromTimeExcel = "12:00 PM";
			}
			String toTimeExcel = timeFormat.format(to.getTime());
			if ("00:00 PM".equals(toTimeExcel)) {
				toTimeExcel = "12:00 PM";
			}
			String isBooked = (interviewerCalendarDetailsEntity.isBooked()) ? "Y" : "N";

			row.createCell(0).setCellValue(interviewerEmpId);
			row.createCell(1).setCellValue(interviewerEmpName);
			row.createCell(2).setCellValue(interviewerEmailId);
			row.createCell(3).setCellValue(createdDate.split(" ")[0]);
			row.createCell(4).setCellValue(bookedDateExcel);
			row.createCell(5).setCellValue(fromTimeExcel);
			row.createCell(6).setCellValue(toTimeExcel);
			row.createCell(7).setCellValue(isBooked);

			HSSFRow rowAvailable = availableSheet.createRow(rowNum);
			rowAvailable.createCell(0).setCellValue(interviewerEmpId);
			rowAvailable.createCell(1).setCellValue(interviewerEmpName);
			rowAvailable.createCell(2).setCellValue(interviewerEmailId);
			rowAvailable.createCell(3).setCellValue(location);
			rowAvailable.createCell(4).setCellValue(fromTimeExcel);
			rowAvailable.createCell(5).setCellValue(toTimeExcel);
			rowAvailable.createCell(7).setCellValue(createdDate.split(" ")[0]);

		}

		List<RecruiterCalendarDetailsEntity> recruiterDetails = recruiterRepo.findAll();

		for (RecruiterCalendarDetailsEntity rD : recruiterDetails) {
			long recruiterId = rD.getEmployeeMasterEntity().getEmpId();
			String recruiterName = rD.getEmployeeMasterEntity().getEmpName();
			String recruiterEmail = rD.getEmployeeMasterEntity().getEmailId();
			String candidateName = rD.getCandidateName();
			long interviewerId = rD.getInterviewer().getEmpId();
			String interviewerName = rD.getInterviewer().getEmpName();
			String interviewerEmail = rD.getInterviewer().getEmailId();
			String location = rD.getEmployeeMasterEntity().getLocation();
			String createdDate = Utils.dateToString(rD.getCreatedDate());
			String fromdate = Utils.dateToString(rD.getFromTime());
			String todate = Utils.dateToString(rD.getToTime());

			DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			DateFormat timeFormat = new SimpleDateFormat("KK:mm a");
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

			Calendar from = Calendar.getInstance();
			from.setTime(inputFormat.parse(fromdate));
			from.add(Calendar.HOUR_OF_DAY, HOUR);
			from.add(Calendar.MINUTE, MINUTES);

			Calendar to = Calendar.getInstance();
			to.setTime(inputFormat.parse(todate));
			to.add(Calendar.HOUR_OF_DAY, HOUR);
			to.add(Calendar.MINUTE, MINUTES);

			String bookedDateExcel = dateFormat.format(inputFormat.parse(todate));
			String fromTimeExcel = timeFormat.format(from.getTime());
			if ("00:00 PM".equals(fromTimeExcel)) {
				fromTimeExcel = "12:00 PM";
			}
			String toTimeExcel = timeFormat.format(to.getTime());
			if ("00:00 PM".equals(toTimeExcel)) {
				toTimeExcel = "12:00 PM";
			}

			HSSFRow rowAvailable = bookedSheet.createRow(rowNum);
			rowAvailable.createCell(0).setCellValue(interviewerId);
			rowAvailable.createCell(1).setCellValue(interviewerName);
			rowAvailable.createCell(2).setCellValue(interviewerEmail);
			rowAvailable.createCell(3).setCellValue(location);
			rowAvailable.createCell(4).setCellValue(fromTimeExcel);
			rowAvailable.createCell(5).setCellValue(toTimeExcel);
			rowAvailable.createCell(7).setCellValue(createdDate.split(" ")[0]);
			rowAvailable.createCell(8).setCellValue(recruiterId);
			rowAvailable.createCell(9).setCellValue(recruiterName);
			rowAvailable.createCell(10).setCellValue(recruiterEmail);
			rowAvailable.createCell(11).setCellValue(candidateName);

		}
		workbook1.write(writer);

	}

	public HSSFSheet getAvailableSheet(HSSFWorkbook workbook, HSSFCellStyle style, String sheetName, int mergerdCells) {
		HSSFSheet sheet = workbook.createSheet(sheetName);
		sheet.createFreezePane(0, 2);
		sheet.setDefaultColumnWidth(25);
		HSSFRow headerName = sheet.createRow(0);
		HSSFRow headerColumns = sheet.createRow(1);

		headerName.createCell(0).setCellValue(sheetName);
		headerName.getCell(0).setCellStyle(style);
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, mergerdCells));

		headerColumns.createCell(0).setCellValue("INTERVIEWER_ID");
		headerColumns.getCell(0).setCellStyle(style);
		headerColumns.createCell(1).setCellValue("INTERVIEWER NAME");
		headerColumns.getCell(1).setCellStyle(style);
		headerColumns.createCell(2).setCellValue("INTERVIEWER EMAIL ID");
		headerColumns.getCell(2).setCellStyle(style);
		headerColumns.createCell(3).setCellValue("LOCATION");
		headerColumns.getCell(3).setCellStyle(style);
		headerColumns.createCell(4).setCellValue("FROM_TIME");
		headerColumns.getCell(4).setCellStyle(style);
		headerColumns.createCell(5).setCellValue("TO_TIME");
		headerColumns.getCell(5).setCellStyle(style);
		headerColumns.createCell(6).setCellValue("BOOKED_DATE");
		headerColumns.getCell(6).setCellStyle(style);
		headerColumns.createCell(7).setCellValue("CREATED DATE");
		headerColumns.getCell(7).setCellStyle(style);

		return sheet;

	}

	public HSSFSheet getBookedSheet(HSSFWorkbook workbook, HSSFCellStyle style, String sheetName) {

		HSSFSheet sheet = getAvailableSheet(workbook, style, "BOOKED", 11);
		// HSSFRow headerColumns = sheet.getRow(0);
		HSSFRow headerColumnRow = sheet.getRow(1);

		headerColumnRow.createCell(8).setCellValue("RECRUITER ID");
		headerColumnRow.getCell(8).setCellStyle(style);
		headerColumnRow.createCell(9).setCellValue("RECRUITER NAME");
		headerColumnRow.getCell(9).setCellStyle(style);
		headerColumnRow.createCell(10).setCellValue("RECRUITER EMAIL ID");
		headerColumnRow.getCell(10).setCellStyle(style);
		headerColumnRow.createCell(11).setCellValue("CANDIDATE NAME");
		headerColumnRow.getCell(11).setCellStyle(style);

		return sheet;

	}

	public HSSFSheet getInterviewedSheet(HSSFWorkbook workbook, HSSFCellStyle style, String sheetName) {

		HSSFSheet sheet = getAvailableSheet(workbook, style, "INTERVIEWED", 9);
		// HSSFRow headerColumns = sheet.getRow(0);
		HSSFRow headerColumnRow = sheet.getRow(1);

		headerColumnRow.createCell(8).setCellValue("FEEDBACK STATUS");
		headerColumnRow.getCell(8).setCellStyle(style);
		headerColumnRow.createCell(9).setCellValue("FEEDBACK COMMENTS");
		headerColumnRow.getCell(9).setCellStyle(style);

		return sheet;

	}

	public HSSFSheet getNotInterviewedSheet(HSSFWorkbook workbook, HSSFCellStyle style, String sheetName) {
		HSSFSheet sheet = getAvailableSheet(workbook, style, "NOT INTERVIEWED", 9);
		// HSSFRow headerColumns = sheet.getRow(0);
		HSSFRow headerColumnRow = sheet.getRow(1);

		headerColumnRow.createCell(8).setCellValue("FEEDBACK STATUS");
		headerColumnRow.getCell(8).setCellStyle(style);
		headerColumnRow.createCell(9).setCellValue("FEEDBACK COMMENTS");
		headerColumnRow.getCell(9).setCellStyle(style);

		return sheet;

	}

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

	}

}
