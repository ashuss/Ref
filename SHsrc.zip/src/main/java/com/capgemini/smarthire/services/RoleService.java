package com.capgemini.smarthire.services;

import java.util.List;

import com.capgemini.smarthire.dtos.EmailDto;

public interface RoleService {

    public List<String> getRole(EmailDto emailDto);

}
