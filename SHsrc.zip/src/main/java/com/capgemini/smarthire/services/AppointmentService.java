package com.capgemini.smarthire.services;

import com.capgemini.smarthire.dtos.AppointmentDTO;

public interface AppointmentService {

	public String sendAppointment(AppointmentDTO appointmentDTO);
}
