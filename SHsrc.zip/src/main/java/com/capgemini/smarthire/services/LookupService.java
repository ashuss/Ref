package com.capgemini.smarthire.services;

import java.util.List;

import com.capgemini.smarthire.dtos.LookupDTO;
import com.capgemini.smarthire.exception.SmarthireException;

public interface LookupService {

    public List<LookupDTO> fetchDropdown(long screenId) throws SmarthireException;

}
