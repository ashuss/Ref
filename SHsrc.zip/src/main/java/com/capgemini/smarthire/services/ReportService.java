package com.capgemini.smarthire.services;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.smarthire.dtos.SmarthireReportDTO;

public interface ReportService {

	public void buildExcelDocument(SmarthireReportDTO reportDto, HttpServletRequest request, HttpServletResponse response) throws Exception;

}
