package com.capgemini.smarthire.services;

import java.util.List;

import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.ResourceDTO;
import com.capgemini.smarthire.exception.SmarthireException;

public interface SupervisorService {

	public List<ResourceDTO> getResources(EmailDto emailDto) throws SmarthireException;
}
