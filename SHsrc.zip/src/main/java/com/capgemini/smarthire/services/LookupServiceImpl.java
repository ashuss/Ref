package com.capgemini.smarthire.services;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smarthire.dtos.LookupDTO;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.repositories.BUMasterRepository;
import com.capgemini.smarthire.repositories.InterviewTypeMasterRepository;
import com.capgemini.smarthire.repositories.LookupRepository;
import com.capgemini.smarthire.repositories.ParticipationTypeRepository;
import com.capgemini.smarthire.repositories.TechnologyMasterRepository;
import com.capgemini.smarthire.reusable.transaction.entity.BUMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.InterviewTypeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.ParticipationTypeEntity;
import com.capgemini.smarthire.reusable.transaction.entity.TechnologyMasterEntity;

@Service
public class LookupServiceImpl implements LookupService {

    private static final String INTERVIEWTYPE = "interviewtype";
    private static final String TECHNOLOGY = "technology";
    private static final String BU = "BU";
    private static final String PARTICIPATION = "participation";

    @Autowired
    LookupRepository lookupRepository;

    @Autowired
    TechnologyMasterRepository technologyRepository;

    @Autowired
    InterviewTypeMasterRepository interviewTypeRepository;
    
    @Autowired
    BUMasterRepository buRepository;
    
    @Autowired
    ParticipationTypeRepository participationTypeRepository;

    @SuppressWarnings("unchecked")
    @Override
    public List<LookupDTO> fetchDropdown(long screenId) throws SmarthireException {

        List<String> screenList = lookupRepository.fetchScreenList(screenId);

        if (screenList != null) {
            List<LookupDTO> lookupList = new ArrayList<>();
            for (String lookupItem : screenList) {
                
                LookupDTO lookupDTO = new LookupDTO();
                lookupDTO.setDropdownName(lookupItem);
                
                JSONObject dropdownJson = getDropdownJson(lookupItem);
               
                lookupDTO.setDropdown(dropdownJson);
                lookupList.add(lookupDTO);
            }
            return lookupList;
        } else {
            throw new SmarthireException("NO DROPDOWN AVAILABLE");
        }

    }
    
    private JSONObject getDropdownJson(String lookupItem){
        JSONObject dropdownJson = new JSONObject();
        
        if (TECHNOLOGY.equals(lookupItem)) {
            List<TechnologyMasterEntity> technologyList = technologyRepository.findAll();
            for (TechnologyMasterEntity technology : technologyList) {
                dropdownJson.put(technology.getTechnologyId(), technology.getTechnologyName());
            }
        } else if (INTERVIEWTYPE.equals(lookupItem)) {
            List<InterviewTypeMasterEntity> interviewTypeList = interviewTypeRepository.findAll();
            for (InterviewTypeMasterEntity interviewType : interviewTypeList) {
                dropdownJson.put(interviewType.getInterviewTypeId(), interviewType.getTypeName());
            }
        } else if (BU.equals(lookupItem)) {
            List<BUMasterEntity> buList = buRepository.findAll();
            for (BUMasterEntity bu : buList) {
                dropdownJson.put(bu.getBUId(), bu.getBUName());
            }
        }else if (PARTICIPATION.equals(lookupItem)) {
            List<ParticipationTypeEntity> participationList = participationTypeRepository.findAll();
            for (ParticipationTypeEntity participation : participationList) {
                dropdownJson.put(participation.getParticipationId(), participation.getParticipationName());
            }
        }
        
        return dropdownJson;
    }

}
