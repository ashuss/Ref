package com.capgemini.smarthire.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

import com.capgemini.smarthire.dtos.SendEmailDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class EmailServiceImpl implements EmailService {

	@Override
	public String sendEmail(SendEmailDTO emailDTO) {
		String finalUrl = "http://3.209.34.69:8022/sendmail";
		String resultString = "";
		String pushData = "";
		JSONObject pushObject = new JSONObject();
		JSONParser jsonParser = new JSONParser();
		ObjectMapper mapper = new ObjectMapper();
		try {
			String jsonString = mapper.writeValueAsString(emailDTO);
			pushData = jsonString;
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
        HttpPost post = new HttpPost(finalUrl);
        HttpClient client = HttpClientBuilder.create().build();

        /*HttpHost proxy = new HttpHost(PROXY_URL, PORT_NUMBER, HTTP_STRING);
        RequestConfig config = RequestConfig.custom().setProxy(proxy) .build();
        post.setConfig(config);*/
        post.setHeader("Content-Type", "application/json");
        StringEntity se;

        try {
            se = new StringEntity(pushData);
            post.setEntity(se);
            HttpResponse response = client.execute(post);
            InputStreamReader isr = new InputStreamReader(response.getEntity().getContent());
            try(BufferedReader rd = new BufferedReader(isr)){
            StringBuilder result = new StringBuilder();
            
            Scanner sc = new Scanner(rd);
            while(sc.hasNext()) {
                result.append(sc.nextLine());
            }
            sc.close();
            isr.close();
            
            if (!result.toString().isEmpty()) {
                resultString = result.toString();
            }
            }
        }catch (IOException e) {
            //Logger.error(e, "error in getting response from uservaribles");
        }
		return resultString;
	}

}
