package com.capgemini.smarthire.services;

import com.capgemini.smarthire.dtos.SendEmailDTO;

public interface EmailService {

	public String sendEmail(SendEmailDTO emailDTO);
}
