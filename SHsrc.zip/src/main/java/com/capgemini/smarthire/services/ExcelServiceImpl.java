package com.capgemini.smarthire.services;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smarthire.dtos.EmployeeData;
import com.capgemini.smarthire.repositories.EmployeeMasterRepository;
import com.capgemini.smarthire.repositories.EmployeeRoleRepository;
import com.capgemini.smarthire.repositories.EmployeeTechnologyRepository;
import com.capgemini.smarthire.repositories.GradeMasterRepository;
import com.capgemini.smarthire.repositories.RoleMasterRepository;
import com.capgemini.smarthire.repositories.TechnologyMasterRepository;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeRoleDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeTechnologyDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.GradeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RoleMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.TechnologyMasterEntity;
import com.jcabi.log.Logger;

@Service
public class ExcelServiceImpl implements ExcelService {

    private static final String EXCEPTION = "Exception";
    private static final String ADMIN = "Admin";

    @Autowired
    GradeMasterRepository gradeMasterRepository;

    @Autowired
    EmployeeMasterRepository employeeMasterRepository;

    @Autowired
    RoleMasterRepository roleMasterRepository;

    @Autowired
    EmployeeRoleRepository employeeRoleRepository;

    @Autowired
    TechnologyMasterRepository technologyMasterRepository;

    @Autowired
    EmployeeTechnologyRepository employeeTechnologyRepository;

    @Override
    public Boolean readExcel() {
        try (InputStream in = new FileInputStream(
                getClass().getClassLoader().getResource("employeedata.csv").getFile());) {
            CSV csv = new CSV(true, ',', in);
            List<String> fieldNames = new ArrayList<>();
            if (csv.hasNext()) {
                fieldNames = new ArrayList<>(csv.next());
            }

            List<Map<String, String>> list = new ArrayList<>();
            while (csv.hasNext()) {
                List<String> x = csv.next();
                Map<String, String> obj = new LinkedHashMap<>();
                for (int i = 0; i < x.size(); i++) {
                    obj.put(fieldNames.get(i), x.get(i));
                }
                list.add(obj);
            }
            List<EmployeeData> employeeDatas = new ArrayList<>();
            for (Map<String, String> map : list) {
                if (!("").equals(map.get("Emp ID"))) {
                    EmployeeData employeeData = new EmployeeData();
                    employeeData.setId(Long.parseLong(map.get("Emp ID")));
                    employeeData.setName(map.get("Name"));
                    employeeData.setEmail(map.get("Email"));
                    employeeData.setServiceLine(map.get("Service Line"));
                    employeeData.setLocation(map.get("Location"));
                    employeeData.setGrade(map.get("Level"));
                    employeeData.setTechnology(map.get("Skills").split(","));
                    employeeData.setRole(map.get("Role"));
                    employeeDatas.add(employeeData);
                }
            }
            saveData(employeeDatas);
            return true;
        } catch (IOException e) {
            Logger.info(e, EXCEPTION);
        }
        return false;
    }

    private void saveData(List<EmployeeData> employeeDatas) {
        for (EmployeeData employeeData : employeeDatas) {
            EmployeeMasterEntity employeeMasterEntity = new EmployeeMasterEntity();
            employeeMasterEntity.setEmpId(employeeData.getId());
            employeeMasterEntity.setEmpName(employeeData.getName());
            employeeMasterEntity.setEmailId(employeeData.getEmail());
            employeeMasterEntity.setLocation(employeeData.getLocation());
            employeeMasterEntity.setActiveFlag(true);
            employeeMasterEntity.setCreatedBy("ADMIN");
            employeeMasterEntity.setCreatedDate(new Date());
            if (!(("").equals(employeeData.getGrade())) && employeeData.getGrade() != null) {
                GradeMasterEntity gradeMasterEntity = gradeMasterRepository.findByGradeName(employeeData.getGrade());
                gradeMasterEntity = saveGradeMasterEntity(gradeMasterEntity, employeeData);
                employeeMasterEntity.setGradeMasterEntity(gradeMasterEntity);
            }
            if (employeeMasterRepository.findOne(employeeData.getId()) == null) {
                employeeMasterEntity = employeeMasterRepository.save(employeeMasterEntity);
            }
            if (!(("").equals(employeeData.getRole())) && employeeData.getRole() != null) {
                RoleMasterEntity roleMasterEntity = roleMasterRepository.findByRoleName(employeeData.getRole());
                saveRoleMasterEntity(roleMasterEntity, employeeData, employeeMasterEntity);
            }
            if (!(("").equals(employeeData.getTechnology())) && employeeData.getTechnology() != null) {
                String[] technologies = employeeData.getTechnology();
                for (String technology : technologies) {
                    TechnologyMasterEntity technologyMasterEntity = technologyMasterRepository
                            .findByTechnologyName(technology);
                    saveTechnologyMaster(technologyMasterEntity, technology, employeeMasterEntity, employeeData);
                }
            }
        }
    }

    private void saveRoleMasterEntity(RoleMasterEntity roleMasterEntity, EmployeeData employeeData,
            EmployeeMasterEntity employeeMasterEntity) {
        RoleMasterEntity roleMaster = null;
        RoleMasterEntity roleMasterNew = null;
        RoleMasterEntity roleMasterFinal = roleMasterEntity;
        if (roleMasterEntity == null) {
            roleMaster = new RoleMasterEntity();
            roleMaster.setActiveFlag(true);
            roleMaster.setCreatedBy(ADMIN);
            roleMaster.setCreatedDate(new Date());
            roleMaster.setRoleName(employeeData.getRole());
            roleMasterNew = roleMasterRepository.save(roleMaster);
            roleMasterFinal = roleMasterNew;
        }

        if (roleMasterFinal != null) {
            EmployeeRoleDetailsEntity employeeRoleDetailsEntity = new EmployeeRoleDetailsEntity();
            employeeRoleDetailsEntity.setEmployeeMasterEntity(employeeMasterEntity);
            employeeRoleDetailsEntity.setRoleMasterEntity(roleMasterFinal);
            saveEmployeeRoleEntity(employeeRoleDetailsEntity, employeeData, roleMasterFinal);

        }
    }

    @SuppressWarnings("unused")
    private GradeMasterEntity saveGradeMasterEntity(GradeMasterEntity gradeMasterEntity, EmployeeData employeeData) {
        GradeMasterEntity gradeMaster = null;
        GradeMasterEntity gradeMasterNew = null;
        GradeMasterEntity gradeMasterFinal = gradeMasterEntity;
        if (gradeMasterEntity == null) {
            gradeMaster = new GradeMasterEntity();
            gradeMaster.setActiveFlag(true);
            gradeMaster.setCreatedBy(ADMIN);
            gradeMaster.setCreatedDate(new Date());
            gradeMaster.setGradeName(employeeData.getGrade());
            gradeMasterNew = gradeMasterRepository.save(gradeMaster);
            gradeMasterFinal = gradeMasterNew;
        }
        return gradeMasterFinal;
    }

    private void saveEmployeeRoleEntity(EmployeeRoleDetailsEntity employeeRoleDetailsEntity, EmployeeData employeeData,
            RoleMasterEntity roleMasterEntity) {
        if (employeeRoleRepository.findExisting(employeeData.getId(), roleMasterEntity.getRoleId()) == null) {
            employeeRoleRepository.save(employeeRoleDetailsEntity);
        }
    }

    private void saveTechnologyMaster(TechnologyMasterEntity technologyMasterEntity, String technology,
            EmployeeMasterEntity employeeMasterEntity, EmployeeData employeeData) {
        TechnologyMasterEntity technologyMaster = null;
        TechnologyMasterEntity technologyMasterNew = null;
        TechnologyMasterEntity technologyMasterFinal = technologyMasterEntity;
        if (technologyMasterEntity == null) {
            technologyMaster = new TechnologyMasterEntity();
            technologyMaster.setActiveFlag(true);
            technologyMaster.setCreatedBy(ADMIN);
            technologyMaster.setCreatedDate(new Date());
            technologyMaster.setTechnologyName(technology);
            technologyMasterNew = technologyMasterRepository.save(technologyMaster);
            technologyMasterFinal = technologyMasterNew;
        }
        if (technologyMasterFinal != null) {
            EmployeeTechnologyDetailsEntity employeeTechnologyDetailsEntity = new EmployeeTechnologyDetailsEntity();
            employeeTechnologyDetailsEntity.setEmployeeMasterEntity(employeeMasterEntity);
            employeeTechnologyDetailsEntity.setTechnologyMasterEntity(technologyMasterFinal);
            if (employeeTechnologyRepository.findExisting(employeeData.getId(),
                    technologyMasterFinal.getTechnologyId()) == null) {
                employeeTechnologyRepository.save(employeeTechnologyDetailsEntity);
            }
        }
    }

}
