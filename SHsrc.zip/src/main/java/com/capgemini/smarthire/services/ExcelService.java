package com.capgemini.smarthire.services;

public interface ExcelService {

    public Boolean readExcel();

}
