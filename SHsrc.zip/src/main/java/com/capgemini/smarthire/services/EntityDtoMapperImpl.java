package com.capgemini.smarthire.services;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import com.capgemini.smarthire.dtos.InterviewerCalendarSavedSlotDTO;
import com.capgemini.smarthire.dtos.InterviewerCalenderDetailsDto;
import com.capgemini.smarthire.dtos.InterviewerDropdownDTO;
import com.capgemini.smarthire.dtos.InterviewerDto;
import com.capgemini.smarthire.dtos.RecruiterCalendarDetailsDto;
import com.capgemini.smarthire.dtos.SlotDto;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.InterviewerCalendarDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RecruiterCalendarDetailsEntity;

@Service
public class EntityDtoMapperImpl implements EntityDtoMapper {

    @Override
    public RecruiterCalendarDetailsDto recruiterCalendarEntityToDto(
            RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity) {
        RecruiterCalendarDetailsDto recruiterCalendarDetailsDto = new RecruiterCalendarDetailsDto();
        recruiterCalendarDetailsDto.setRecruiterCalendarId(recruiterCalendarDetailsEntity.getRecruiterCalendarId());
        recruiterCalendarDetailsDto.setRecruiterId(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId());
        recruiterCalendarDetailsDto.setRecruiterCalendarId(recruiterCalendarDetailsEntity.getRecruiterCalendarId());
        recruiterCalendarDetailsDto.setRecruiterId(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId());

        recruiterCalendarDetailsDto
                .setRecruiterName(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName());
        recruiterCalendarDetailsDto.setCandidateName(recruiterCalendarDetailsEntity.getCandidateName());
        recruiterCalendarDetailsDto
                .setTechnologyId(recruiterCalendarDetailsEntity.getTechnologyMasterEntity().getTechnologyId());
        recruiterCalendarDetailsDto
                .setTechnologyName(recruiterCalendarDetailsEntity.getTechnologyMasterEntity().getTechnologyName());
        recruiterCalendarDetailsDto
                .setInterviewType(recruiterCalendarDetailsEntity.getInterviewTypeMasterEntity().getInterviewTypeId());
        recruiterCalendarDetailsDto
                .setInterviewTypeName(recruiterCalendarDetailsEntity.getInterviewTypeMasterEntity().getTypeName());
        recruiterCalendarDetailsDto.setFromTime(recruiterCalendarDetailsEntity.getFromTime());
        recruiterCalendarDetailsDto.setToTime(recruiterCalendarDetailsEntity.getToTime());
        recruiterCalendarDetailsDto.setComments(recruiterCalendarDetailsEntity.getComments());
        if (recruiterCalendarDetailsEntity.getInterviewer() != null) {
            InterviewerDto interviewerDto = new InterviewerDto();
            recruiterCalendarDetailsDto.setBuId(recruiterCalendarDetailsEntity.getInterviewer().getBuMasterEntity().getBUId());
            interviewerDto.setInterviewerId(recruiterCalendarDetailsEntity.getInterviewer().getEmpId());
            interviewerDto.setEmpName(recruiterCalendarDetailsEntity.getInterviewer().getEmpName());
            interviewerDto.setEmailId(recruiterCalendarDetailsEntity.getInterviewer().getEmailId());
            interviewerDto.setLocation(recruiterCalendarDetailsEntity.getInterviewer().getLocation());
            interviewerDto
                    .setGrade(recruiterCalendarDetailsEntity.getInterviewer().getGradeMasterEntity().getGradeName());
            if(recruiterCalendarDetailsEntity.getInterviewerCalendarDetailsEntity() != null){
                interviewerDto.setFeedbackComments(
                        recruiterCalendarDetailsEntity.getInterviewerCalendarDetailsEntity().getFeedbackComment());
                if(recruiterCalendarDetailsEntity.getInterviewerCalendarDetailsEntity().getFeedbackStatusEntity() != null){
                    interviewerDto.setFeedbackStatus(recruiterCalendarDetailsEntity.getInterviewerCalendarDetailsEntity()
                            .getFeedbackStatusEntity().getFeedbackStatusName());
                }
            }
            
            recruiterCalendarDetailsDto.setInterviewerDto(interviewerDto);
        }else{
            recruiterCalendarDetailsDto.setBuId(recruiterCalendarDetailsEntity.getBuMasterEntity().getBUId());
        }
        return recruiterCalendarDetailsDto;
    }

    @SuppressWarnings("unchecked")
    @Override
    public InterviewerCalenderDetailsDto interviewerCalendarEntityToDto(
            InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity) {
        InterviewerCalenderDetailsDto interviewerCalenderDetailsDto = new InterviewerCalenderDetailsDto();
        interviewerCalenderDetailsDto.setCalendarId(interviewerCalendarDetailsEntity.getInterviewerCalendarId());
        interviewerCalenderDetailsDto.setId(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId());
        SlotDto slotDto = new SlotDto();
        slotDto.setFrom(interviewerCalendarDetailsEntity.getFromTime());
        slotDto.setTo(interviewerCalendarDetailsEntity.getToTime());
        interviewerCalenderDetailsDto.setSlot(slotDto);
        interviewerCalenderDetailsDto.setBooked(interviewerCalendarDetailsEntity.isBooked());
        
        JSONObject interviewerDetails = new JSONObject();
        interviewerDetails.put("name", interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName());
        interviewerDetails.put("empId", interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId());
        interviewerDetails.put("email", interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
        interviewerDetails.put("grade", interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getGradeMasterEntity().getGradeName());
        interviewerCalenderDetailsDto.setInterviewDetails(interviewerDetails);
        if(interviewerCalendarDetailsEntity.getParticipationTypeEntity() != null){
        	interviewerCalenderDetailsDto.setParticipationTypeId(interviewerCalendarDetailsEntity.getParticipationTypeEntity().getParticipationId());
        }
        
        if (interviewerCalendarDetailsEntity.isBooked()
                && interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity() != null) {

            JSONObject details = new JSONObject();
            details.put("candidateName",
                    interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity().getCandidateName());
            details.put("technology", interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity()
                    .getTechnologyMasterEntity().getTechnologyName());
            details.put("interviewType", interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity()
                    .getInterviewTypeMasterEntity().getTypeName());
            details.put("recruiterName", interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity()
                    .getEmployeeMasterEntity().getEmpName());
            details.put("comments", interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity().getComments());
            interviewerCalenderDetailsDto.setDetails(details);
            
            
            
            details.put("feedbackComments", interviewerCalendarDetailsEntity.getFeedbackComment());
            if(interviewerCalendarDetailsEntity.getFeedbackStatusEntity() != null){
                details.put("feedbackStatus", interviewerCalendarDetailsEntity.getFeedbackStatusEntity().getFeedbackStatusName());
            }else{
                details.put("feedbackStatus", null);
            }

        }
        return interviewerCalenderDetailsDto;
    }

    @Override
    public InterviewerCalendarSavedSlotDTO interviewerCalendarDetailsEntityToDTO(
            InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity) {
        InterviewerCalendarSavedSlotDTO interviewerCalendarSavedSlotDTO = new InterviewerCalendarSavedSlotDTO();
        interviewerCalendarSavedSlotDTO
                .setEmail(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
        interviewerCalendarSavedSlotDTO.setFromTime(interviewerCalendarDetailsEntity.getFromTime());
        interviewerCalendarSavedSlotDTO.setGrade(
                interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getGradeMasterEntity().getGradeName());
        interviewerCalendarSavedSlotDTO
                .setInterviewerCalenderId(interviewerCalendarDetailsEntity.getInterviewerCalendarId());
        interviewerCalendarSavedSlotDTO
                .setInterviewerId(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId());
        interviewerCalendarSavedSlotDTO
                .setInterviewerName(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName());
        interviewerCalendarSavedSlotDTO
                .setLocation(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getLocation());
        interviewerCalendarSavedSlotDTO.setToTime(interviewerCalendarDetailsEntity.getToTime());
        return interviewerCalendarSavedSlotDTO;
    }

    @Override
    public InterviewerDropdownDTO interviewerEntityToDTO(EmployeeMasterEntity interviewer) {
        InterviewerDropdownDTO interviewerDropdownDTO = new InterviewerDropdownDTO();
        interviewerDropdownDTO.setInterviewerId(interviewer.getEmpId());
        interviewerDropdownDTO.setName(interviewer.getEmpName());
        if (interviewer.getGradeMasterEntity() != null) {
            interviewerDropdownDTO.setGrade(interviewer.getGradeMasterEntity().getGradeName());
        }
        interviewerDropdownDTO.setLocation(interviewer.getLocation());
//        interviewerDropdownDTO.setParticipationType(interviewer.);
        return interviewerDropdownDTO;
    }

}
