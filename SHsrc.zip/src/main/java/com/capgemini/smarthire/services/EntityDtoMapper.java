package com.capgemini.smarthire.services;

import com.capgemini.smarthire.dtos.InterviewerCalendarSavedSlotDTO;
import com.capgemini.smarthire.dtos.InterviewerCalenderDetailsDto;
import com.capgemini.smarthire.dtos.InterviewerDropdownDTO;
import com.capgemini.smarthire.dtos.RecruiterCalendarDetailsDto;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.InterviewerCalendarDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RecruiterCalendarDetailsEntity;

public interface EntityDtoMapper {

    public RecruiterCalendarDetailsDto recruiterCalendarEntityToDto(
            RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity);

    public InterviewerCalenderDetailsDto interviewerCalendarEntityToDto(
            InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity);

    public InterviewerCalendarSavedSlotDTO interviewerCalendarDetailsEntityToDTO(
            InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity);

    public InterviewerDropdownDTO interviewerEntityToDTO(EmployeeMasterEntity interviewer);

}
