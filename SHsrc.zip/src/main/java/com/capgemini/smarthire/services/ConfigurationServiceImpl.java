package com.capgemini.smarthire.services;

import java.util.Map;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;

import org.springframework.stereotype.Service;

import com.capgemini.smarthire.exception.SmarthireException;
import com.jcabi.log.Logger;

@Service
public class ConfigurationServiceImpl implements ConfigurationService {
    
    private static final String EXCEPTION_MESSAGE = "Exception is";

    @Override
    public Map<String, String> getAllConstants() throws SmarthireException {
        Map<String, String> constantsMap = new HashMap<>();
        try(FileInputStream fileInput = new FileInputStream(
                getClass().getClassLoader().getResource("constants.properties").getFile())) {
            Properties properties = new Properties();
            properties.load(fileInput);

            Enumeration enuKeys = properties.keys();

            while (enuKeys.hasMoreElements()) {
                String key = (String) enuKeys.nextElement();
                String value = properties.getProperty(key);
                constantsMap.put(key, value);
            }
            
                return constantsMap;
            

        } catch (IOException e) {
            Logger.info(e, EXCEPTION_MESSAGE);
            throw new SmarthireException(e.getMessage());
        }
    }

}
