package com.capgemini.smarthire.services;

import java.util.List;

import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.RecruiterCalendarDetailsDto;
import com.capgemini.smarthire.dtos.SaveRecruiterSlotDto;
import com.capgemini.smarthire.exception.SmarthireException;

public interface RecruiterService {

    public List<RecruiterCalendarDetailsDto> getAllRecruiterSlots(EmailDto emailDto) throws SmarthireException;

    public RecruiterCalendarDetailsDto saveInterviewSlot(SaveRecruiterSlotDto saveRecruiterSlotDto)
            throws SmarthireException;

    public RecruiterCalendarDetailsDto rescheduleSlot(SaveRecruiterSlotDto saveRecruiterSlotDto)
            throws SmarthireException;

    public Boolean deleteSlot(SaveRecruiterSlotDto saveRecruiterSlotDto) throws SmarthireException;

}
