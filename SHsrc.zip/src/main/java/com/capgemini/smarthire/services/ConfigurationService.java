package com.capgemini.smarthire.services;

import java.util.Map;

import com.capgemini.smarthire.exception.SmarthireException;

public interface ConfigurationService {

    public Map<String, String> getAllConstants() throws SmarthireException;

}
