package com.capgemini.smarthire.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.ResourceDTO;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.repositories.EmployeeMasterRepository;
import com.capgemini.smarthire.repositories.EmployeeRoleRepository;
import com.capgemini.smarthire.repositories.RoleMasterRepository;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RoleMasterEntity;

@Service
public class SupervisorServiceImpl implements SupervisorService {

	@Autowired
	EmployeeMasterRepository employeeMasterRepository;

	@Autowired
	EmployeeRoleRepository employeeRoleRepository;

	@Autowired
	RoleMasterRepository roleMasterRepository;

	private static final String SUPERVISORROLE = "Supervisior";

	@Override
	public List<ResourceDTO> getResources(EmailDto emailDto) throws SmarthireException {
		List<ResourceDTO> resourceList = new ArrayList<>();
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository.getEmployeeByEmail(emailDto.getEmail());
		long roleId = employeeRoleRepository.getEmployeeRoleDetails(employeeMasterEntity.getEmpId());
		RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(SUPERVISORROLE);
		if (roleMaster.getRoleId() == roleId && roleId != 0) {
			List<EmployeeMasterEntity> employeeDetailList = employeeMasterRepository.getResources(emailDto.getEmail());
			for (EmployeeMasterEntity employee : employeeDetailList) {
				ResourceDTO resourceDTO = new ResourceDTO();
				resourceDTO.setEmpId(employee.getEmpId());
				resourceDTO.setEmpName(employee.getEmpName());
				resourceDTO.setEmailId(employee.getEmailId());
				resourceList.add(resourceDTO);
			}
			return resourceList;
		} else {
			throw new SmarthireException("YOU ARE NOT AUTHORIZED TO VIEW RESOURCES");
		}
	}
}
