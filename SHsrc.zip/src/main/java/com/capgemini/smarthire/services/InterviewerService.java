package com.capgemini.smarthire.services;

import java.util.List;

import com.capgemini.smarthire.dtos.AvailabilityDTO;
import com.capgemini.smarthire.dtos.CheckAvailabilityDTO;
import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.FeedbackDTO;
import com.capgemini.smarthire.dtos.InterviewerCalendarSavedSlotDTO;
import com.capgemini.smarthire.dtos.InterviewerCalenderDetailsDto;
import com.capgemini.smarthire.dtos.InterviewerDropdownDTO;
import com.capgemini.smarthire.dtos.InterviewerDropdownRequestDTO;
import com.capgemini.smarthire.dtos.InterviewerSaveSlotDto;
import com.capgemini.smarthire.dtos.InterviewerSkillDTO;
import com.capgemini.smarthire.dtos.ReportDTO;
import com.capgemini.smarthire.dtos.RescheduleRequestDto;
import com.capgemini.smarthire.dtos.SlotDto;
import com.capgemini.smarthire.dtos.SmarthireReportDTO;
import com.capgemini.smarthire.dtos.StatusCountDto;
import com.capgemini.smarthire.dtos.StatusDTO;
import com.capgemini.smarthire.dtos.SupervisorDTO;
import com.capgemini.smarthire.dtos.TechnologyDTO;
import com.capgemini.smarthire.dtos.TimeDTO;
import com.capgemini.smarthire.exception.SmarthireException;

public interface InterviewerService {

    public List<InterviewerCalenderDetailsDto> getAllInterviewerSlots(EmailDto emailDto) throws SmarthireException;
    
    public List<InterviewerCalenderDetailsDto> getInterviewersSlots(CheckAvailabilityDTO heckAvailabilityDTO) throws SmarthireException;
    
    public InterviewerCalendarSavedSlotDTO saveFreeSlot(InterviewerSaveSlotDto interviewerSaveSlotDto)
            throws SmarthireException;

    public List<InterviewerDropdownDTO> fetchInterviewerDropdown(
            InterviewerDropdownRequestDTO interviewerDropdownRequestDTO) throws SmarthireException;

    public Boolean deleteInterviewSlot(long calenderId) throws SmarthireException;

    public Boolean saveFeedback(FeedbackDTO feedbackDto) throws SmarthireException;

	public List<ReportDTO> generateReport(SmarthireReportDTO reportDto) throws SmarthireException;

	public Boolean setRescheduledRequested(RescheduleRequestDto rescheduleRequestDto) throws SmarthireException;

	public List<StatusCountDto> fetchTypeCount() throws SmarthireException;
	
	public List<AvailabilityDTO> getAvailibility(SlotDto slotDTO) throws SmarthireException;

	public Boolean addSupervisior(SupervisorDTO supervisorDto) throws SmarthireException;

	public List<StatusDTO> fetchInterviewSuccess(TimeDTO timeDto) throws SmarthireException;

	public List<TechnologyDTO> fetchInterviewerSkills(EmailDto emailDto) throws SmarthireException;


}
