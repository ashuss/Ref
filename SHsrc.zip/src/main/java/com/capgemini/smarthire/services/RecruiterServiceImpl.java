package com.capgemini.smarthire.services;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smarthire.dtos.AppointmentDTO;
import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.RecruiterCalendarDetailsDto;
import com.capgemini.smarthire.dtos.SaveRecruiterSlotDto;
import com.capgemini.smarthire.dtos.SendEmailDTO;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.repositories.BUMasterRepository;
import com.capgemini.smarthire.repositories.EmployeeMasterRepository;
import com.capgemini.smarthire.repositories.EmployeeRoleRepository;
import com.capgemini.smarthire.repositories.InterviewTypeMasterRepository;
import com.capgemini.smarthire.repositories.InterviewerRepository;
import com.capgemini.smarthire.repositories.RecruiterCalendarDetailsRepository;
import com.capgemini.smarthire.repositories.RoleMasterRepository;
import com.capgemini.smarthire.repositories.TechnologyMasterRepository;
import com.capgemini.smarthire.reusable.transaction.entity.BUMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.InterviewTypeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.InterviewerCalendarDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RecruiterCalendarDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RoleMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.TechnologyMasterEntity;
import com.capgemini.smarthire.util.Utils;

@Service
public class RecruiterServiceImpl implements RecruiterService {

	private static final int HOUR = 5;
	private static final int MINUTES = 30;

	public static final String RECRUITERROLE = "Recruiter";

	@Autowired
	RecruiterCalendarDetailsRepository recruiterCalendarDetailsRepository;

	@Autowired
	EmployeeMasterRepository employeeMasterRepository;

	@Autowired
	TechnologyMasterRepository technologyMasterRepository;

	@Autowired
	InterviewTypeMasterRepository interviewTypeMasterRepository;

	@Autowired
	InterviewerRepository interviewerRepository;

	@Autowired
	EmployeeRoleRepository employeeRoleRepository;

	@Autowired
	EntityDtoMapper mapper;

	@Autowired
	RoleMasterRepository roleMasterRepository;

	@Autowired
	BUMasterRepository buMasterRepository;

	@Autowired
	AppointmentService appointmentService;

	@Autowired
	EmailService emailService;

	@Override
	public List<RecruiterCalendarDetailsDto> getAllRecruiterSlots(EmailDto emailDto) throws SmarthireException {
		RoleMasterEntity roleMasterEntity = roleMasterRepository.findByRoleName(RECRUITERROLE);
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository.getEmployeeByEmail(emailDto.getEmail());
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
		if (roleMasterList.contains(roleMasterEntity)) {
			List<RecruiterCalendarDetailsEntity> recruiterCalendarDetailsEntities = recruiterCalendarDetailsRepository
					.findSlotsByEmail(emailDto.getEmail());
			List<RecruiterCalendarDetailsDto> recruiterCalendarDetailsDtos = new ArrayList<>();
			for (RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity : recruiterCalendarDetailsEntities) {
				RecruiterCalendarDetailsDto recruiterCalendarDetailsDto = mapper
						.recruiterCalendarEntityToDto(recruiterCalendarDetailsEntity);
				recruiterCalendarDetailsDtos.add(recruiterCalendarDetailsDto);
			}
			return recruiterCalendarDetailsDtos;
		} else {
			throw new SmarthireException("YOU ARE NOT AUTHORIZED TO VIEW RECRUITER SLOTS");
		}

	}

	@Override
	public RecruiterCalendarDetailsDto saveInterviewSlot(SaveRecruiterSlotDto saveRecruiterSlotDto)
			throws SmarthireException {
		RoleMasterEntity roleMasterEntity = roleMasterRepository.findByRoleName(RECRUITERROLE);
		EmployeeMasterEntity employeeMaster = employeeMasterRepository
				.getEmployeeByEmail(saveRecruiterSlotDto.getEmailId());
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMaster.getEmpId());
		if (roleMasterList.contains(roleMasterEntity)) {
			RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity = new RecruiterCalendarDetailsEntity();
			recruiterCalendarDetailsEntity.setIsInterviewerAssigned(false);
			InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity = null;
			EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository
					.getEmployeeByEmail(saveRecruiterSlotDto.getEmailId());
			TechnologyMasterEntity technologyMasterEntity = technologyMasterRepository
					.findOne(saveRecruiterSlotDto.getTechnologyId());
			InterviewTypeMasterEntity interviewTypeMasterEntity = interviewTypeMasterRepository
					.findOne(saveRecruiterSlotDto.getInterviewTypeId());
			recruiterCalendarDetailsEntity.setEmployeeMasterEntity(employeeMasterEntity);
			recruiterCalendarDetailsEntity.setTechnologyMasterEntity(technologyMasterEntity);
			recruiterCalendarDetailsEntity.setCandidateName(saveRecruiterSlotDto.getCandidateName());
			recruiterCalendarDetailsEntity.setInterviewTypeMasterEntity(interviewTypeMasterEntity);
			recruiterCalendarDetailsEntity.setFromTime(saveRecruiterSlotDto.getFromTime());
			recruiterCalendarDetailsEntity.setToTime(saveRecruiterSlotDto.getToTime());
			BUMasterEntity buMasterEntity = buMasterRepository.findOne(saveRecruiterSlotDto.getBuId());
			recruiterCalendarDetailsEntity.setBuMasterEntity(buMasterEntity);
			if (saveRecruiterSlotDto.getInterviewerId() != 0) {
				EmployeeMasterEntity interviewer = employeeMasterRepository
						.findOne(saveRecruiterSlotDto.getInterviewerId());
				interviewerCalendarDetailsEntity = interviewerRepository.findCalenderBySlotAndId(
						saveRecruiterSlotDto.getFromTime(), saveRecruiterSlotDto.getToTime(),
						saveRecruiterSlotDto.getInterviewerId());
				if (interviewerCalendarDetailsEntity != null) {
					recruiterCalendarDetailsEntity.setInterviewer(interviewer);
					recruiterCalendarDetailsEntity
							.setInterviewerCalendarDetailsEntity(interviewerCalendarDetailsEntity);
					recruiterCalendarDetailsEntity.setIsInterviewerAssigned(true);
				}
			}
			recruiterCalendarDetailsEntity.setComments(saveRecruiterSlotDto.getComments());
			recruiterCalendarDetailsRepository.save(recruiterCalendarDetailsEntity);
			List<String> attendies = new ArrayList<>();
			attendies.add(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
			attendies.add(recruiterCalendarDetailsEntity.getInterviewerCalendarDetailsEntity().getEmployeeMasterEntity()
					.getEmailId());
			AppointmentDTO appointmentDTO = new AppointmentDTO();
			String msg = "";
			String fromdate = Utils.dateToString(saveRecruiterSlotDto.getFromTime());
			String todate = Utils.dateToString(saveRecruiterSlotDto.getToTime());
			DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			DateFormat timeFormat = new SimpleDateFormat("KK:mm a");
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

			try {
				Calendar from = Calendar.getInstance();
				from.setTime(inputFormat.parse(fromdate));
				from.add(Calendar.HOUR_OF_DAY, 0);
				from.add(Calendar.MINUTE, 0);

				Calendar to = Calendar.getInstance();
				to.setTime(inputFormat.parse(todate));
				to.add(Calendar.HOUR_OF_DAY, 0);
				to.add(Calendar.MINUTE, 0);
				msg = "Interview has been scheduled on " + dateFormat.format(inputFormat.parse(todate)) + " from "
						+ timeFormat.format(from.getTime()) + " to " + timeFormat.format(to.getTime())
						+ " for candidate : " + recruiterCalendarDetailsEntity.getCandidateName();
			} catch (ParseException e) {
				throw new SmarthireException(e.getMessage());
			}

			appointmentDTO.setBody(msg);
			appointmentDTO.setDomain("corp");
			appointmentDTO.setAttendies(attendies);
			appointmentDTO.setEndTime(saveRecruiterSlotDto.getToTime());
			appointmentDTO.setPassword("bUNRPBpEMGtoca/R2cDVCFxUd5vUFfT+BdhVKehT9g8=");
			appointmentDTO.setStartTime(saveRecruiterSlotDto.getFromTime());
			appointmentDTO.setSubscriptionKey("eO3cjl3SeOZFmumjZoSmQoVa5pCuIq8dfp19NQnqiUo=");
			appointmentDTO.setUserId("gisoni");
			appointmentDTO.setInterviewerName(recruiterCalendarDetailsEntity.getInterviewerCalendarDetailsEntity()
					.getEmployeeMasterEntity().getEmpName());
			appointmentDTO.setRecruiterName(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName());

			//String result = appointmentService.sendAppointment(appointmentDTO);
			if (saveRecruiterSlotDto.getInterviewerId() != 0
					&& recruiterCalendarDetailsEntity.getIsInterviewerAssigned()) {
				interviewerCalendarDetailsEntity = interviewerRepository.findCalenderBySlotAndId(
						saveRecruiterSlotDto.getFromTime(), saveRecruiterSlotDto.getToTime(),
						saveRecruiterSlotDto.getInterviewerId());
				interviewerCalendarDetailsEntity.setRecruiterCalendarDetailsEntity(recruiterCalendarDetailsEntity);
				interviewerCalendarDetailsEntity.setBooked(true);
				recruiterCalendarDetailsEntity.setIsInterviewerAssigned(true);
				interviewerCalendarDetailsEntity = interviewerRepository.save(interviewerCalendarDetailsEntity);
				recruiterCalendarDetailsEntity.setInterviewerCalendarDetailsEntity(interviewerCalendarDetailsEntity);
			}
			return mapper.recruiterCalendarEntityToDto(recruiterCalendarDetailsEntity);
		} else {
			throw new SmarthireException("YOU ARE NOT AUTHORIZED TO SAVE RECRUITER SLOTS");
		}
	}

	@Override
	public RecruiterCalendarDetailsDto rescheduleSlot(SaveRecruiterSlotDto saveRecruiterSlotDto)
			throws SmarthireException {
		RoleMasterEntity roleMasterEntity = roleMasterRepository.findByRoleName(RECRUITERROLE);
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository
				.getEmployeeByEmail(saveRecruiterSlotDto.getEmailId());
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
		if (roleMasterList.contains(roleMasterEntity)) {
			if (saveRecruiterSlotDto.getRecruiterCalendarId() != 0) {
				RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity = recruiterCalendarDetailsRepository
						.findOne(saveRecruiterSlotDto.getRecruiterCalendarId());
				return rescheduleSlotFinal(recruiterCalendarDetailsEntity, saveRecruiterSlotDto);

			} else {
				throw new SmarthireException("CALENDER ID IS NOT PRESENT");
			}
		} else {
			throw new SmarthireException("YOU ARE NOT AUTHORIZED TO RESCHEDULE RECRUITER SLOTS");
		}
	}

	private RecruiterCalendarDetailsDto rescheduleSlotFinal(
			RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity, SaveRecruiterSlotDto saveRecruiterSlotDto)
			throws SmarthireException {
		if (recruiterCalendarDetailsEntity != null) {
			recruiterCalendarDetailsEntity.setRecruiterCalendarId(saveRecruiterSlotDto.getRecruiterCalendarId());
			recruiterCalendarDetailsEntity.setCandidateName(saveRecruiterSlotDto.getCandidateName());
			recruiterCalendarDetailsEntity.setFromTime(saveRecruiterSlotDto.getFromTime());
			recruiterCalendarDetailsEntity.setToTime(saveRecruiterSlotDto.getToTime());
			recruiterCalendarDetailsEntity.setComments(saveRecruiterSlotDto.getComments());
			recruiterCalendarDetailsEntity.setUpdatedBy(saveRecruiterSlotDto.getEmailId());
			recruiterCalendarDetailsEntity.setUpdatedDate(new Date());
			InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity = null;
			if (saveRecruiterSlotDto.getInterviewerId() != 0) {
				EmployeeMasterEntity interviewer = employeeMasterRepository
						.findOne(saveRecruiterSlotDto.getInterviewerId());
				if (recruiterCalendarDetailsEntity.getIsInterviewerAssigned()) {
					changeOldInterviewer(recruiterCalendarDetailsEntity, saveRecruiterSlotDto);
				}
				interviewerCalendarDetailsEntity = interviewerRepository.findCalenderBySlotAndId(
						saveRecruiterSlotDto.getFromTime(), saveRecruiterSlotDto.getToTime(),
						saveRecruiterSlotDto.getInterviewerId());
				if (interviewerCalendarDetailsEntity != null) {
					recruiterCalendarDetailsEntity.setInterviewer(interviewer);
					recruiterCalendarDetailsEntity
							.setInterviewerCalendarDetailsEntity(interviewerCalendarDetailsEntity);
					recruiterCalendarDetailsEntity.setIsInterviewerAssigned(true);
					recruiterCalendarDetailsRepository.save(recruiterCalendarDetailsEntity);
					interviewerCalendarDetailsEntity.setRecruiterCalendarDetailsEntity(recruiterCalendarDetailsEntity);
					interviewerCalendarDetailsEntity.setBooked(true);
					recruiterCalendarDetailsEntity.setIsInterviewerAssigned(true);
					interviewerCalendarDetailsEntity = interviewerRepository.save(interviewerCalendarDetailsEntity);
					recruiterCalendarDetailsEntity
							.setInterviewerCalendarDetailsEntity(interviewerCalendarDetailsEntity);
					List<String> attendies = new ArrayList<>();
					attendies.add(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
					attendies.add(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
					AppointmentDTO appointmentDTO = new AppointmentDTO();
					String msg = "";
					String fromdate = Utils.dateToString(saveRecruiterSlotDto.getFromTime());
					String todate = Utils.dateToString(saveRecruiterSlotDto.getToTime());
					DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
					DateFormat timeFormat = new SimpleDateFormat("KK:mm a");
					DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

					try {
						Calendar from = Calendar.getInstance();
						from.setTime(inputFormat.parse(fromdate));
						from.add(Calendar.HOUR_OF_DAY, 0);
						from.add(Calendar.MINUTE, 0);

						Calendar to = Calendar.getInstance();
						to.setTime(inputFormat.parse(todate));
						to.add(Calendar.HOUR_OF_DAY, 0);
						to.add(Calendar.MINUTE, 0);
						msg = "Interview has been scheduled on " + dateFormat.format(inputFormat.parse(todate))
								+ " from " + timeFormat.format(from.getTime()) + " to "
								+ timeFormat.format(to.getTime()) + " for candidate : "
								+ recruiterCalendarDetailsEntity.getCandidateName();
					} catch (ParseException e) {
						throw new SmarthireException(e.getMessage());
					}
					appointmentDTO.setBody(msg);
					appointmentDTO.setDomain("corp");
					appointmentDTO.setAttendies(attendies);
					appointmentDTO.setEndTime(saveRecruiterSlotDto.getToTime());
					appointmentDTO.setPassword("bUNRPBpEMGtoca/R2cDVCFxUd5vUFfT+BdhVKehT9g8=");
					appointmentDTO.setStartTime(saveRecruiterSlotDto.getFromTime());
					appointmentDTO.setSubscriptionKey("eO3cjl3SeOZFmumjZoSmQoVa5pCuIq8dfp19NQnqiUo=");
					appointmentDTO.setUserId("gisoni");
					appointmentDTO.setInterviewerName(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName());
					appointmentDTO
							.setRecruiterName(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName());

					//String result = appointmentService.sendAppointment(appointmentDTO);

				} else {
					throw new SmarthireException("Slot already booked for the Interviewer");
				}
				return mapper.recruiterCalendarEntityToDto(recruiterCalendarDetailsEntity);

			} else {
				RecruiterCalendarDetailsEntity recruiterCalendar = null;
				if (recruiterCalendarDetailsEntity.getIsInterviewerAssigned()) {
					interviewerCalendarDetailsEntity = interviewerRepository.findCalenderBySlotAndId(
							saveRecruiterSlotDto.getOldFromTime(), saveRecruiterSlotDto.getOldToTime(),
							recruiterCalendarDetailsEntity.getInterviewer().getEmpId());
					InterviewerCalendarDetailsEntity oldInterviewerCalendarDetailsEntity = interviewerCalendarDetailsEntity;
					oldInterviewerCalendarDetailsEntity.setRecruiterCalendarDetailsEntity(null);
					oldInterviewerCalendarDetailsEntity.setBooked(false);
					interviewerRepository.save(oldInterviewerCalendarDetailsEntity);
					String msg = "";

					SendEmailDTO sendEmailDTO = new SendEmailDTO();
					sendEmailDTO.setDomain("corp");
					sendEmailDTO.setPassword("bUNRPBpEMGtoca/R2cDVCFxUd5vUFfT+BdhVKehT9g8=");
					sendEmailDTO.setSubject("SmartHire Slot Rescheduled");
					sendEmailDTO.setSubscriptionKey("eO3cjl3SeOZFmumjZoSmQoVa5pCuIq8dfp19NQnqiUo=");
					sendEmailDTO.setUserId("gisoni");

					String fromdate = Utils.dateToString(saveRecruiterSlotDto.getOldFromTime());
					String todate = Utils.dateToString(saveRecruiterSlotDto.getOldToTime());
					DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
					DateFormat timeFormat = new SimpleDateFormat("KK:mm a");
					DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

					try {
						Calendar from = Calendar.getInstance();
						from.setTime(inputFormat.parse(fromdate));
						from.add(Calendar.HOUR_OF_DAY, 0);
						from.add(Calendar.MINUTE, 0);

						Calendar to = Calendar.getInstance();
						to.setTime(inputFormat.parse(todate));
						to.add(Calendar.HOUR_OF_DAY, 0);
						to.add(Calendar.MINUTE, 0);

						msg = "SmartHire interview slot booked on " + dateFormat.format(inputFormat.parse(todate))
								+ " from " + timeFormat.format(from.getTime()) + " to "
								+ timeFormat.format(to.getTime()) + " has been freed by recruiter : "
								+ recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId();
						sendEmailDTO.setBodyContent(msg);
						sendEmailDTO.setTo(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
						sendEmailDTO.setCc(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
						//String emailSuccess = emailService.sendEmail(sendEmailDTO);

					} catch (ParseException e) {
						throw new SmarthireException(e.getMessage());
					}

					recruiterCalendarDetailsEntity.setInterviewer(null);
					recruiterCalendarDetailsEntity.setIsInterviewerAssigned(false);
					recruiterCalendar = recruiterCalendarDetailsRepository.save(recruiterCalendarDetailsEntity);
					return mapper.recruiterCalendarEntityToDto(recruiterCalendar);
				} else {
					recruiterCalendar = recruiterCalendarDetailsRepository.save(recruiterCalendarDetailsEntity);
					return mapper.recruiterCalendarEntityToDto(recruiterCalendar);
				}
			}
		} else {
			throw new SmarthireException("NO SLOT EXISTS");
		}
	}

	private void changeOldInterviewer(RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity,
			SaveRecruiterSlotDto saveRecruiterSlotDto) throws SmarthireException {
		if (recruiterCalendarDetailsEntity.getInterviewer() != null) {
			EmployeeMasterEntity oldInterviewer = employeeMasterRepository
					.findOne(recruiterCalendarDetailsEntity.getInterviewer().getEmpId());
			if (oldInterviewer != null) {
				InterviewerCalendarDetailsEntity oldInterviewerCalendarDetailsEntity = interviewerRepository
						.findCalenderBySlotAndId(saveRecruiterSlotDto.getOldFromTime(),
								saveRecruiterSlotDto.getOldToTime(), oldInterviewer.getEmpId());
				if (oldInterviewerCalendarDetailsEntity != null) {

					oldInterviewerCalendarDetailsEntity.setRecruiterCalendarDetailsEntity(null);
					oldInterviewerCalendarDetailsEntity.setBooked(false);
					interviewerRepository.save(oldInterviewerCalendarDetailsEntity);

					String msg = "";

					SendEmailDTO sendEmailDTO = new SendEmailDTO();
					sendEmailDTO.setDomain("corp");
					sendEmailDTO.setPassword("bUNRPBpEMGtoca/R2cDVCFxUd5vUFfT+BdhVKehT9g8=");
					sendEmailDTO.setSubject("SmartHire Slot Rescheduled");
					sendEmailDTO.setSubscriptionKey("eO3cjl3SeOZFmumjZoSmQoVa5pCuIq8dfp19NQnqiUo=");
					sendEmailDTO.setUserId("gisoni");

					String fromdate = Utils.dateToString(oldInterviewerCalendarDetailsEntity.getFromTime());
					String todate = Utils.dateToString(oldInterviewerCalendarDetailsEntity.getToTime());
					DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
					DateFormat timeFormat = new SimpleDateFormat("KK:mm a");
					DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

					try {
						Calendar from = Calendar.getInstance();
						from.setTime(inputFormat.parse(fromdate));
						from.add(Calendar.HOUR_OF_DAY, 0);
						from.add(Calendar.MINUTE, 0);

						Calendar to = Calendar.getInstance();
						to.setTime(inputFormat.parse(todate));
						to.add(Calendar.HOUR_OF_DAY, 0);
						to.add(Calendar.MINUTE, 0);

						msg = "SmartHire interview slot booked on " + dateFormat.format(inputFormat.parse(todate))
								+ " from " + timeFormat.format(from.getTime()) + " to "
								+ timeFormat.format(to.getTime()) + " has been freed by recruiter : "
								+ recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId();
						sendEmailDTO.setBodyContent(msg);
						sendEmailDTO.setTo(oldInterviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
						sendEmailDTO.setCc(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
						//String emailSuccess = emailService.sendEmail(sendEmailDTO);

					} catch (ParseException e) {
						throw new SmarthireException(e.getMessage());
					}
				}
			} else {
				throw new SmarthireException("Old Interviewer Assigned Not Found");
			}
		}
	}

	@Override
	public Boolean deleteSlot(SaveRecruiterSlotDto saveRecruiterSlotDto) throws SmarthireException {
		RoleMasterEntity roleMasterEntity = roleMasterRepository.findByRoleName(RECRUITERROLE);
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository
				.getEmployeeByEmail(saveRecruiterSlotDto.getEmailId());
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
		if (roleMasterList.contains(roleMasterEntity)) {
			return deleteSlotFinal(saveRecruiterSlotDto);

		} else {
			throw new SmarthireException("YOU ARE NOT AUTHORIZED TO RESCHEDULE RECRUITER SLOTS");
		}
	}

	private Boolean deleteSlotFinal(SaveRecruiterSlotDto saveRecruiterSlotDto) throws SmarthireException {
		if (saveRecruiterSlotDto.getRecruiterCalendarId() != 0) {
			RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity = recruiterCalendarDetailsRepository
					.findOne(saveRecruiterSlotDto.getRecruiterCalendarId());
			if (recruiterCalendarDetailsEntity != null) {
				if (!(recruiterCalendarDetailsEntity.getIsInterviewerAssigned())) {
					recruiterCalendarDetailsRepository.delete(recruiterCalendarDetailsEntity);
					return true;
				} else {
					throw new SmarthireException(
							"Interviewer is Already assigned to this slot, Can not delete this slot");
				}
			} else {
				throw new SmarthireException("NO SLOT EXISTS");
			}
		} else {
			throw new SmarthireException("CALENDER ID IS NOT PRESENT");
		}
	}

}
