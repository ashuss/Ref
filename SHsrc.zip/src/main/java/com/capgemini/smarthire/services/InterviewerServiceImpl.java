package com.capgemini.smarthire.services;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smarthire.dtos.AvailabilityDTO;

import com.capgemini.smarthire.dtos.CheckAvailabilityDTO;
import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.FeedbackDTO;
import com.capgemini.smarthire.dtos.FeedbackDetailsDTO;
import com.capgemini.smarthire.dtos.InterviewerCalendarSavedSlotDTO;
import com.capgemini.smarthire.dtos.InterviewerCalenderDetailsDto;
import com.capgemini.smarthire.dtos.InterviewerDetailsDTO;
import com.capgemini.smarthire.dtos.InterviewerDropdownDTO;
import com.capgemini.smarthire.dtos.InterviewerDropdownRequestDTO;
import com.capgemini.smarthire.dtos.InterviewerSaveSlotDto;

import com.capgemini.smarthire.dtos.RecruiterDetailsDTO;
import com.capgemini.smarthire.dtos.ReportDTO;
import com.capgemini.smarthire.dtos.RescheduleRequestDto;
import com.capgemini.smarthire.dtos.SendEmailDTO;
import com.capgemini.smarthire.dtos.SlotDetailsDTO;
import com.capgemini.smarthire.dtos.SlotDto;
import com.capgemini.smarthire.dtos.SlotsDTO;
import com.capgemini.smarthire.dtos.SmarthireReportDTO;
import com.capgemini.smarthire.dtos.StatusCountDto;
import com.capgemini.smarthire.dtos.StatusDTO;
import com.capgemini.smarthire.dtos.StatusDetailsDTO;
import com.capgemini.smarthire.dtos.StatusTypeDTO;
import com.capgemini.smarthire.dtos.SupervisorDTO;
import com.capgemini.smarthire.dtos.TechnologyDTO;
import com.capgemini.smarthire.dtos.TimeDTO;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.repositories.EmployeeMasterRepository;
import com.capgemini.smarthire.repositories.EmployeeRoleRepository;
import com.capgemini.smarthire.repositories.EmployeeTechnologyRepository;
import com.capgemini.smarthire.repositories.FeedbackStatusRepository;
import com.capgemini.smarthire.repositories.InterviewGradeTypeDetailsRepository;
import com.capgemini.smarthire.repositories.InterviewerRepository;
import com.capgemini.smarthire.repositories.ParticipationTypeRepository;
import com.capgemini.smarthire.repositories.RoleMasterRepository;
import com.capgemini.smarthire.repositories.TechnologyMasterRepository;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeMasterEntity;
import com.capgemini.smarthire.reusable.transaction.entity.EmployeeTechnologyDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.FeedbackStatusEntity;
import com.capgemini.smarthire.reusable.transaction.entity.InterviewGradeTypeDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.InterviewerCalendarDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.ParticipationTypeEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RecruiterCalendarDetailsEntity;
import com.capgemini.smarthire.reusable.transaction.entity.RoleMasterEntity;
import com.capgemini.smarthire.util.Utils;

@Service
public class InterviewerServiceImpl implements InterviewerService {

	private static final String INTERVIEWERROLE = "Interviewer";
	private static final int HOUR = 0;
	private static final int MINUTES = 0;
	private static final String SUPERVISORROLE = "Supervisior";
	public static final String RECRUITERROLE = "Recruiter";
	private static final String L1TYPE = "L1";
	private static final String L2TYPE = "L2";
	private static final String PASS = "Pass";
	private static final String FAIL = "Fail";

	@Autowired
	InterviewerRepository interviewerRepository;
	
	@Autowired
	ParticipationTypeRepository participationTypeRepository;

	@Autowired
	EntityDtoMapper mapper;

	@Autowired
	EmployeeMasterRepository employeeMasterRepository;

	@Autowired
	EmployeeRoleRepository employeeRoleRepository;

	@Autowired
	RoleMasterRepository roleMasterRepository;

	@Autowired
	FeedbackStatusRepository feedbackStatusRepository;

	@Autowired
	EmployeeTechnologyRepository employeeTechnologyRepository;

	@Autowired
	InterviewGradeTypeDetailsRepository interviewGradeTypeRepository;

	@Autowired
	TechnologyMasterRepository technologyMasterRepository;
	
	@Autowired
	EmailService emailService;
	
	private static final Date currentDate = new Date();
	
	@Override
	public List<InterviewerCalenderDetailsDto> getInterviewersSlots(CheckAvailabilityDTO checkAvailabilityDTO) throws SmarthireException {
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository.getEmployeeByEmail(checkAvailabilityDTO.getEmailId());
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
		
		RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(RECRUITERROLE);

		if (roleMasterList.contains(roleMaster)) {
			Date date = new Date();
			//date = Utils.incrementDaysToDate(date, -1);
			List<InterviewerCalendarDetailsEntity> interviewerCalendarDetailsEntities = interviewerRepository
					.findInterviewersSlots(checkAvailabilityDTO.getInterviewerTypeId(), 
							checkAvailabilityDTO.getTechnologyId(), checkAvailabilityDTO.getBuId(), new Date());
			
//			for(InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity : interviewerCalendarDetailsEntities){
//				System.out.println(interviewerCalendarDetailsEntity.getInterviewerCalendarId());
//			}
//			return null;
			List<InterviewerCalenderDetailsDto> interviewerCalenderDetailsDtos = new ArrayList<>();
			for (InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity : interviewerCalendarDetailsEntities) {
				InterviewerCalenderDetailsDto interviewerCalenderDetailsDto = mapper
						.interviewerCalendarEntityToDto(interviewerCalendarDetailsEntity);
				interviewerCalenderDetailsDtos.add(interviewerCalenderDetailsDto);
			}
			return interviewerCalenderDetailsDtos;
		}else{
			throw new SmarthireException("YOU ARE NOT AUTHORIZED TO VIEW FREE INTERVIEW SLOTS");
		}
		
	
	}

	@Override
	public List<InterviewerCalenderDetailsDto> getAllInterviewerSlots(EmailDto emailDto) throws SmarthireException {
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository.getEmployeeByEmail(emailDto.getEmail());
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
		
		RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(INTERVIEWERROLE);

		if (roleMasterList.contains(roleMaster)) {
			List<InterviewerCalendarDetailsEntity> interviewerCalendarDetailsEntities = interviewerRepository
					.findSlotsByEmail(emailDto.getEmail());
			List<InterviewerCalenderDetailsDto> interviewerCalenderDetailsDtos = new ArrayList<>();
			for (InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity : interviewerCalendarDetailsEntities) {
				InterviewerCalenderDetailsDto interviewerCalenderDetailsDto = mapper
						.interviewerCalendarEntityToDto(interviewerCalendarDetailsEntity);
				interviewerCalenderDetailsDtos.add(interviewerCalenderDetailsDto);
			}
			return interviewerCalenderDetailsDtos;
		} else {
			throw new SmarthireException("YOU ARE NOT AUTHORIZED TO VIEW INTERVIEW SLOTS");
		}

	}

	private InterviewerCalendarDetailsEntity fetchInterviewerCalendarEntity(
			InterviewerSaveSlotDto interviewerSaveSlotDto, EmployeeMasterEntity employeeMasterEntity)
			throws SmarthireException {
		InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity = null;
		if (interviewerSaveSlotDto.getCalendarId() != 0) {
			interviewerCalendarDetailsEntity = interviewerRepository.findOne(interviewerSaveSlotDto.getCalendarId());
			if (interviewerCalendarDetailsEntity != null) {
				if (interviewerCalendarDetailsEntity.isBooked()) {
					throw new SmarthireException("SLOT ALREADY BOOKED BY RECRUITER");
				}
				interviewerCalendarDetailsEntity.setInterviewerCalendarId(interviewerSaveSlotDto.getCalendarId());
				interviewerCalendarDetailsEntity.setUpdatedBy(interviewerSaveSlotDto.getEmail());
				interviewerCalendarDetailsEntity.setUpdatedDate(new Date());
			} else {
				throw new SmarthireException("INTERVIEW SLOT DOES NOT EXIST");
			}
		} else {
			interviewerCalendarDetailsEntity = new InterviewerCalendarDetailsEntity();
			interviewerCalendarDetailsEntity.setCreatedBy(interviewerSaveSlotDto.getEmail());
			interviewerCalendarDetailsEntity.setCreatedDate(new Date());
		}
		ParticipationTypeEntity participationTypeEntity = participationTypeRepository.findOne(interviewerSaveSlotDto.getParticipationTypeId());
		interviewerCalendarDetailsEntity.setEmployeeMasterEntity(employeeMasterEntity);
		interviewerCalendarDetailsEntity.setBooked(false);
		interviewerCalendarDetailsEntity.setFromTime(interviewerSaveSlotDto.getFromTime());
		interviewerCalendarDetailsEntity.setToTime(interviewerSaveSlotDto.getToTime());
		interviewerCalendarDetailsEntity.setActiveFlag(true);
		interviewerCalendarDetailsEntity.setParticipationTypeEntity(participationTypeEntity);
		return interviewerRepository.save(interviewerCalendarDetailsEntity);
	}

	@Override
	public InterviewerCalendarSavedSlotDTO saveFreeSlot(InterviewerSaveSlotDto interviewerSaveSlotDto)
			throws SmarthireException {
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository
				.getEmployeeByEmail(interviewerSaveSlotDto.getEmail());
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
		RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(INTERVIEWERROLE);
		InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity = null;
		if (roleMasterList.contains(roleMaster)) {
			if (interviewerRepository.findCalenderBySlotAndIdAndParticipation(interviewerSaveSlotDto.getFromTime(),
					interviewerSaveSlotDto.getToTime(), employeeMasterEntity.getEmpId(), interviewerSaveSlotDto.getParticipationTypeId()) == null) {
				interviewerCalendarDetailsEntity = fetchInterviewerCalendarEntity(interviewerSaveSlotDto,
						employeeMasterEntity);
				return mapper.interviewerCalendarDetailsEntityToDTO(interviewerCalendarDetailsEntity);
			} else {
				String fromdate = Utils.dateToString(interviewerSaveSlotDto.getFromTime());
				String todate = Utils.dateToString(interviewerSaveSlotDto.getToTime());
				DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				DateFormat timeFormat = new SimpleDateFormat("KK:mm a");
				DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

				try {
					Calendar from = Calendar.getInstance();
					from.setTime(inputFormat.parse(fromdate));
					from.add(Calendar.HOUR_OF_DAY, HOUR);
					from.add(Calendar.MINUTE, MINUTES);

					Calendar to = Calendar.getInstance();
					to.setTime(inputFormat.parse(todate));
					to.add(Calendar.HOUR_OF_DAY, HOUR);
					to.add(Calendar.MINUTE, MINUTES);

					String exception = "SLOT ALREADY BOOKED FROM " + timeFormat.format(from.getTime()) + " TO "
							+ timeFormat.format(to.getTime()) + " ON " + dateFormat.format(inputFormat.parse(todate));
					throw new SmarthireException(exception);
				} catch (ParseException e) {
					throw new SmarthireException(e.getMessage());
				}
			}
		} else {
			throw new SmarthireException("YOU ARE NOT AUTHORIZED TO ADD INTERVIEW SLOTS");
		}
	}

	@Override
	public List<InterviewerDropdownDTO> fetchInterviewerDropdown(
			InterviewerDropdownRequestDTO interviewerDropdownRequestDTO) throws SmarthireException {
		List<EmployeeMasterEntity> employeeMasterList = interviewerRepository.fetchInterviewerDropdown(
				interviewerDropdownRequestDTO.getFromTime(), interviewerDropdownRequestDTO.getToTime(),
				interviewerDropdownRequestDTO.getTechnologyId(), interviewerDropdownRequestDTO.getInterviewTypeId(),
				interviewerDropdownRequestDTO.getBuId());

		if (employeeMasterList != null) {
			List<InterviewerDropdownDTO> interviewerDropdownList = new ArrayList<>();
					 
			for (EmployeeMasterEntity interviewer : employeeMasterList) {
				
				InterviewerCalendarDetailsEntity interviewerCalendar = interviewerRepository.findParticipationType(interviewer.getEmpId(),interviewerDropdownRequestDTO.getFromTime(),
						interviewerDropdownRequestDTO.getToTime());
				InterviewerDropdownDTO interviewerDto = mapper.interviewerEntityToDTO(interviewer);
				interviewerDto.setParticipationType(interviewerCalendar.getParticipationTypeEntity().getParticipationName());
				
				interviewerDropdownList.add(interviewerDto);
			}
			return interviewerDropdownList;
		} else {
			throw new SmarthireException("NO INTERVIEWER AVAILABLE");
		}

	}

	@Override
	public Boolean deleteInterviewSlot(long calenderId) throws SmarthireException {
		InterviewerCalendarDetailsEntity interviewerCalender = interviewerRepository.findOne(calenderId);
		if (interviewerCalender != null) {
			EmployeeMasterEntity employeeMasterEntity = interviewerCalender.getEmployeeMasterEntity();
			RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(INTERVIEWERROLE);
			List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
			if (roleMasterList.contains(roleMaster)) {
				interviewerRepository.delete(interviewerCalender);
				return true;
			} else {
				throw new SmarthireException("YOU ARE NOT AUTHORIZED TO DELETE INTERVIEW SLOTS");
			}

		} else {
			throw new SmarthireException("NO INTERVIEW SLOT FOUND");
		}
	}

	@Override
	public Boolean saveFeedback(FeedbackDTO feedbackDto) throws SmarthireException {
		
		InterviewerCalendarDetailsEntity interviewerCalender = interviewerRepository
				.findOne(feedbackDto.getCalendarId());
		if (interviewerCalender != null) {
			EmployeeMasterEntity employeeMasterEntity = interviewerCalender.getEmployeeMasterEntity();
			RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(INTERVIEWERROLE);
			List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
			if (roleMasterList.contains(roleMaster)) {
				interviewerCalender.setFeedbackComment(feedbackDto.getFeedbackComments());
				ParticipationTypeEntity participationTypeEntity = participationTypeRepository.findOne(feedbackDto.getParticipationId());
				interviewerCalender.setParticipationTypeEntity(participationTypeEntity);
				
				FeedbackStatusEntity feedbackStatusEntity = feedbackStatusRepository
						.findOne(feedbackDto.getFeedbackStatusId());
				if (feedbackStatusEntity != null) {
					interviewerCalender.setFeedbackStatusEntity(feedbackStatusEntity);
					InterviewerCalendarDetailsEntity interviewCalendarNew = interviewerRepository
							.save(interviewerCalender);
					return (interviewCalendarNew != null) ? true : false;
				} else {
					throw new SmarthireException("NO FEEDBACK STATUS FOUND");
				}
			} else {
				throw new SmarthireException("YOU ARE NOT AUTHORIZED TO GIVE FEEDBACK COMMENTS");
			}
		} else {
			throw new SmarthireException("NO INTERVIEW SLOT FOUND");
		}
	}

	@Override
	public List<ReportDTO> generateReport(SmarthireReportDTO reportDto) throws SmarthireException {

		List<InterviewerCalendarDetailsEntity> interviewerCalendarDetailsEntity = null;
		if (reportDto.getInterviewerEmailId() != null) {
			interviewerCalendarDetailsEntity = interviewerRepository.fetchInterviewerReport(
					employeeMasterRepository.getEmployeeByEmail(reportDto.getInterviewerEmailId()).getEmpId(),
					reportDto.getFromTime(), reportDto.getToTime());
		}

		else if (reportDto.getSupervisorEmailId() != null && reportDto.getRecruiterEmailId() == null) {
			RoleMasterEntity recruiterRoleEntity = roleMasterRepository.findByRoleName(RECRUITERROLE);

			if (reportDto.getTechId() != 0 && reportDto.getInterviewTypeId() != 0) {
				interviewerCalendarDetailsEntity = interviewerRepository.fetchSupervisorReportByTechAndType(
						reportDto.getFromTime(), reportDto.getToTime(),
						employeeMasterRepository.getEmployeeByEmail(reportDto.getSupervisorEmailId()).getEmpId(),
						reportDto.getTechId(), reportDto.getInterviewTypeId(), recruiterRoleEntity.getRoleId());
			} else if (reportDto.getTechId() != 0) {
				interviewerCalendarDetailsEntity = interviewerRepository.fetchSupervisorReportByTech(
						reportDto.getFromTime(), reportDto.getToTime(),
						employeeMasterRepository.getEmployeeByEmail(reportDto.getSupervisorEmailId()).getEmpId(),
						reportDto.getTechId(), recruiterRoleEntity.getRoleId());
			} else if (reportDto.getInterviewTypeId() != 0) {
				interviewerCalendarDetailsEntity = interviewerRepository.fetchSupervisorReportByType(
						reportDto.getFromTime(), reportDto.getToTime(),
						employeeMasterRepository.getEmployeeByEmail(reportDto.getSupervisorEmailId()).getEmpId(),
						reportDto.getInterviewTypeId(), recruiterRoleEntity.getRoleId());
			} else if (reportDto.getTechId() == 0 && reportDto.getInterviewTypeId() == 0) {
				interviewerCalendarDetailsEntity = interviewerRepository.fetchSupervisorReport(reportDto.getFromTime(),
						reportDto.getToTime(),
						employeeMasterRepository.getEmployeeByEmail(reportDto.getSupervisorEmailId()).getEmpId(),
						recruiterRoleEntity.getRoleId());
			}
		}

		else if (reportDto.getSupervisorEmailId() != null && reportDto.getRecruiterEmailId() != null) {
			RoleMasterEntity roleMasterEntity = roleMasterRepository.findByRoleName(RECRUITERROLE);
			EmployeeMasterEntity recruiter = employeeMasterRepository
					.getEmployeeByEmail(reportDto.getRecruiterEmailId());
			EmployeeMasterEntity supervisor = employeeMasterRepository
					.getEmployeeByEmail(reportDto.getSupervisorEmailId());
			List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(recruiter.getEmpId());
			Boolean isSupervisor = (supervisor == recruiter.getSupervisorMasterEntity()) ? true : false;
			if (roleMasterList.contains(roleMasterEntity) && isSupervisor) {
				if (reportDto.getTechId() != 0 && reportDto.getInterviewTypeId() != 0) {
					interviewerCalendarDetailsEntity = interviewerRepository
							.fetchSupervisorResourceReportByTechIdAndTypeId(reportDto.getFromTime(),
									reportDto.getToTime(), reportDto.getTechId(), reportDto.getInterviewTypeId(),
									recruiter.getEmpId());
				} else if (reportDto.getTechId() != 0) {
					interviewerCalendarDetailsEntity = interviewerRepository.fetchSupervisorResourceReportByTechId(
							reportDto.getFromTime(), reportDto.getToTime(), reportDto.getTechId(),
							recruiter.getEmpId());
				} else if (reportDto.getInterviewTypeId() != 0) {
					interviewerCalendarDetailsEntity = interviewerRepository.fetchSupervisorResourceReportByTypeId(
							reportDto.getFromTime(), reportDto.getToTime(), reportDto.getInterviewTypeId(),
							recruiter.getEmpId());
				} else {
					interviewerCalendarDetailsEntity = interviewerRepository.fetchSupervisorResourceReport(
							reportDto.getFromTime(), reportDto.getToTime(), recruiter.getEmpId());
				}

			} else {
				throw new SmarthireException("RECRUITER ROLE OR SUPERVISOR NOT VERIFIED. CANNOT DISPLAY REPORTS");
			}
		}

		else {
			if (reportDto.getTechId() != 0 && reportDto.getInterviewTypeId() != 0) {
				interviewerCalendarDetailsEntity = interviewerRepository.fetchReportByTechIdAndTypeId(
						reportDto.getFromTime(), reportDto.getToTime(), reportDto.getTechId(),
						reportDto.getInterviewTypeId());
			} else if (reportDto.getTechId() != 0) {
				interviewerCalendarDetailsEntity = interviewerRepository.fetchReportByTechId(reportDto.getFromTime(),
						reportDto.getToTime(), reportDto.getTechId());
			} else if (reportDto.getInterviewTypeId() != 0) {
				interviewerCalendarDetailsEntity = interviewerRepository.fetchReportByTypeId(reportDto.getFromTime(),
						reportDto.getToTime(), reportDto.getInterviewTypeId());
			} else {
				System.out.println("hi i am in");
				interviewerCalendarDetailsEntity = interviewerRepository.getAvailibility(reportDto.getFromTime(),
						reportDto.getToTime());
			}
		}

		List<ReportDTO> reportDTOList = new ArrayList<>();

		ReportDTO availableReport = new ReportDTO();
		availableReport.setStatus("AVAILABLE");
		ReportDTO bookedReport = new ReportDTO();
		bookedReport.setStatus("BOOKED");
		ReportDTO interviewedReport = new ReportDTO();
		interviewedReport.setStatus("INTERVIEWED");
		ReportDTO notInterviewedReport = new ReportDTO();
		notInterviewedReport.setStatus("NOT INTERVIEWED");
		long availableCount = 0;
		long bookedCount = 0;
		long interviewedCount = 0;
		long notInterviewedCount = 0;

		List<SlotDetailsDTO> availableSlotDetailsDTOs = null;
		List<SlotDetailsDTO> bookedSlotDetailsDTOs = null;
		List<SlotDetailsDTO> interviewedSlotDetailsDTOs = null;
		List<SlotDetailsDTO> notInterviewedSlotDetailsDTOs = null;

		List<SlotsDTO> availableSlotDtoList = new ArrayList<>();
		List<SlotsDTO> bookedSlotDtoList = new ArrayList<>();
		List<SlotsDTO> interviewedSlotDtoList = new ArrayList<>();
		List<SlotsDTO> notInterviewedSlotDtoList = new ArrayList<>();

		SlotsDTO availableSlotsDTO = null;
		SlotsDTO bookedSlotsDTO = null;
		SlotsDTO interviewedSlotsDTO = null;
		SlotsDTO notInterviewedSlotsDTO = null;

		long interviewerId = -1;
		long interviewerIdOld = -1;
		long availableInterviewerId = -1;
		long bookedInterviewerId = -1;
		long interviewedInterviewerId = -1;
		long notInterviewedInterviewerId = -1;
		for (InterviewerCalendarDetailsEntity interviewerCalendar : interviewerCalendarDetailsEntity) {
			if (interviewerCalendar.getEmployeeMasterEntity().getEmpId() != interviewerId) {
				if (interviewerIdOld != -1
						&& interviewerIdOld != interviewerCalendar.getEmployeeMasterEntity().getEmpId()) {
					if (availableSlotsDTO != null) {
						availableSlotDtoList.add(availableSlotsDTO);
					}
					if (bookedSlotsDTO != null) {
						bookedSlotDtoList.add(bookedSlotsDTO);
					}
					if (interviewedSlotsDTO != null) {
						interviewedSlotDtoList.add(interviewedSlotsDTO);
					}
					if (notInterviewedSlotsDTO != null) {
						notInterviewedSlotDtoList.add(notInterviewedSlotsDTO);
					}
				}
				interviewerId = interviewerCalendar.getEmployeeMasterEntity().getEmpId();
				interviewerIdOld = interviewerId;
			}

			if (!interviewerCalendar.isBooked()) {
				if (interviewerCalendar.getEmployeeMasterEntity().getEmpId() != availableInterviewerId) {
					availableSlotsDTO = new SlotsDTO();
					availableSlotsDTO.setEmailId(interviewerCalendar.getEmployeeMasterEntity().getEmailId());
					availableSlotsDTO.setInterviewerId(interviewerCalendar.getEmployeeMasterEntity().getEmpId());
					availableSlotsDTO.setInterviewerName(interviewerCalendar.getEmployeeMasterEntity().getEmpName());
					availableSlotsDTO.setInterviewerType(interviewGradeTypeRepository.findInterviewType(
							interviewerCalendar.getEmployeeMasterEntity().getGradeMasterEntity().getGradeId()));
					availableSlotDetailsDTOs = new ArrayList<>();
					availableInterviewerId = interviewerCalendar.getEmployeeMasterEntity().getEmpId();
				}

				SlotDetailsDTO slotDetailsDTO = new SlotDetailsDTO();
				FeedbackDetailsDTO feedbackDTO = null;
				if (interviewerCalendar.getFeedbackStatusEntity() != null) {
					feedbackDTO = new FeedbackDetailsDTO();
					feedbackDTO
							.setFeedbackComment(interviewerCalendar.getFeedbackStatusEntity().getFeedbackStatusName());
					feedbackDTO.setFeedbackStatus(interviewerCalendar.getFeedbackComment());

				}
				RecruiterDetailsDTO recruiterDetailsDTO = null;
				if (interviewerCalendar.getRecruiterCalendarDetailsEntity() != null) {
					recruiterDetailsDTO = new RecruiterDetailsDTO();
					recruiterDetailsDTO.setId(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpId());
					recruiterDetailsDTO.setName(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpName());
					recruiterDetailsDTO.setEmailId(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmailId());
					slotDetailsDTO.setCandidateName(
							interviewerCalendar.getRecruiterCalendarDetailsEntity().getCandidateName());
				}

				slotDetailsDTO.setFromDate(interviewerCalendar.getFromTime());
				slotDetailsDTO.setToDate(interviewerCalendar.getToTime());
				slotDetailsDTO.setFeedbackDetails(feedbackDTO);
				slotDetailsDTO.setRecruiterDetails(recruiterDetailsDTO);
				availableSlotDetailsDTOs.add(slotDetailsDTO);
				availableSlotsDTO.setInterviewerCount(availableSlotDetailsDTOs.size());
				availableSlotsDTO.setSlotsDetails(availableSlotDetailsDTOs);
				availableCount++;

			} else if (interviewerCalendar.isBooked()
					&& interviewerCalendar.getRecruiterCalendarDetailsEntity().getIsInterviewerAssigned()
					&& interviewerCalendar.getToTime().after(currentDate)) {
				if (interviewerCalendar.getEmployeeMasterEntity().getEmpId() != bookedInterviewerId) {
					bookedSlotsDTO = new SlotsDTO();
					bookedSlotsDTO.setEmailId(interviewerCalendar.getEmployeeMasterEntity().getEmailId());
					bookedSlotsDTO.setInterviewerId(interviewerCalendar.getEmployeeMasterEntity().getEmpId());
					bookedSlotsDTO.setInterviewerName(interviewerCalendar.getEmployeeMasterEntity().getEmpName());
					bookedSlotsDTO.setInterviewerType(interviewGradeTypeRepository.findInterviewType(
							interviewerCalendar.getEmployeeMasterEntity().getGradeMasterEntity().getGradeId()));
					bookedSlotDetailsDTOs = new ArrayList<>();
					bookedInterviewerId = interviewerCalendar.getEmployeeMasterEntity().getEmpId();
				}

				SlotDetailsDTO slotDetailsDTO = new SlotDetailsDTO();
				FeedbackDetailsDTO feedbackDTO = null;
				if (interviewerCalendar.getFeedbackStatusEntity() != null) {
					feedbackDTO = new FeedbackDetailsDTO();
					feedbackDTO
							.setFeedbackComment(interviewerCalendar.getFeedbackStatusEntity().getFeedbackStatusName());
					feedbackDTO.setFeedbackStatus(interviewerCalendar.getFeedbackComment());

				}
				RecruiterDetailsDTO recruiterDetailsDTO = null;
				if (interviewerCalendar.getRecruiterCalendarDetailsEntity() != null) {
					recruiterDetailsDTO = new RecruiterDetailsDTO();
					recruiterDetailsDTO.setId(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpId());
					recruiterDetailsDTO.setName(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpName());
					recruiterDetailsDTO.setEmailId(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmailId());
					slotDetailsDTO.setCandidateName(
							interviewerCalendar.getRecruiterCalendarDetailsEntity().getCandidateName());

				}

				slotDetailsDTO.setFromDate(interviewerCalendar.getFromTime());
				slotDetailsDTO.setToDate(interviewerCalendar.getToTime());
				slotDetailsDTO.setFeedbackDetails(feedbackDTO);
				slotDetailsDTO.setRecruiterDetails(recruiterDetailsDTO);
				bookedSlotDetailsDTOs.add(slotDetailsDTO);
				bookedSlotsDTO.setInterviewerCount(bookedSlotDetailsDTOs.size());
				bookedSlotsDTO.setSlotsDetails(bookedSlotDetailsDTOs);
				bookedCount++;
			} else if (interviewerCalendar.isBooked()
					&& interviewerCalendar.getRecruiterCalendarDetailsEntity().getIsInterviewerAssigned()
					&& interviewerCalendar.getToTime().before(currentDate)
					&& interviewerCalendar.getFeedbackStatusEntity() != null) {
				if (interviewerCalendar.getEmployeeMasterEntity().getEmpId() != interviewedInterviewerId) {
					interviewedSlotsDTO = new SlotsDTO();
					interviewedSlotsDTO.setEmailId(interviewerCalendar.getEmployeeMasterEntity().getEmailId());
					interviewedSlotsDTO.setInterviewerId(interviewerCalendar.getEmployeeMasterEntity().getEmpId());
					interviewedSlotsDTO.setInterviewerName(interviewerCalendar.getEmployeeMasterEntity().getEmpName());
					interviewedSlotsDTO.setInterviewerType(interviewGradeTypeRepository.findInterviewType(
							interviewerCalendar.getEmployeeMasterEntity().getGradeMasterEntity().getGradeId()));
					interviewedSlotDetailsDTOs = new ArrayList<>();
					interviewedInterviewerId = interviewerCalendar.getEmployeeMasterEntity().getEmpId();
				}
				SlotDetailsDTO slotDetailsDTO = new SlotDetailsDTO();
				FeedbackDetailsDTO feedbackDTO = null;
				if (interviewerCalendar.getFeedbackStatusEntity() != null) {
					feedbackDTO = new FeedbackDetailsDTO();
					feedbackDTO
							.setFeedbackComment(interviewerCalendar.getFeedbackStatusEntity().getFeedbackStatusName());
					feedbackDTO.setFeedbackStatus(interviewerCalendar.getFeedbackComment());

				}
				RecruiterDetailsDTO recruiterDetailsDTO = null;
				if (interviewerCalendar.getRecruiterCalendarDetailsEntity() != null) {
					recruiterDetailsDTO = new RecruiterDetailsDTO();
					recruiterDetailsDTO.setId(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpId());
					recruiterDetailsDTO.setName(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpName());
					recruiterDetailsDTO.setEmailId(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmailId());
					slotDetailsDTO.setCandidateName(
							interviewerCalendar.getRecruiterCalendarDetailsEntity().getCandidateName());
				}

				slotDetailsDTO.setFromDate(interviewerCalendar.getFromTime());
				slotDetailsDTO.setToDate(interviewerCalendar.getToTime());
				slotDetailsDTO.setFeedbackDetails(feedbackDTO);
				slotDetailsDTO.setRecruiterDetails(recruiterDetailsDTO);
				interviewedSlotDetailsDTOs.add(slotDetailsDTO);
				interviewedSlotsDTO.setInterviewerCount(interviewedSlotDetailsDTOs.size());
				interviewedSlotsDTO.setSlotsDetails(interviewedSlotDetailsDTOs);
				interviewedCount++;
			} else if (interviewerCalendar.isBooked()
					&& interviewerCalendar.getRecruiterCalendarDetailsEntity().getIsInterviewerAssigned()
					&& interviewerCalendar.getToTime().before(currentDate)
					&& interviewerCalendar.getFeedbackStatusEntity() == null) {
				if (interviewerCalendar.getEmployeeMasterEntity().getEmpId() != notInterviewedInterviewerId) {
					notInterviewedSlotsDTO = new SlotsDTO();
					notInterviewedSlotsDTO.setEmailId(interviewerCalendar.getEmployeeMasterEntity().getEmailId());
					notInterviewedSlotsDTO.setInterviewerId(interviewerCalendar.getEmployeeMasterEntity().getEmpId());
					notInterviewedSlotsDTO
							.setInterviewerName(interviewerCalendar.getEmployeeMasterEntity().getEmpName());
					notInterviewedSlotsDTO.setInterviewerType(interviewGradeTypeRepository.findInterviewType(
							interviewerCalendar.getEmployeeMasterEntity().getGradeMasterEntity().getGradeId()));
					notInterviewedSlotDetailsDTOs = new ArrayList<>();
					notInterviewedInterviewerId = interviewerCalendar.getEmployeeMasterEntity().getEmpId();
				}
				SlotDetailsDTO slotDetailsDTO = new SlotDetailsDTO();
				FeedbackDetailsDTO feedbackDTO = null;
				if (interviewerCalendar.getFeedbackStatusEntity() != null) {
					feedbackDTO = new FeedbackDetailsDTO();
					feedbackDTO
							.setFeedbackComment(interviewerCalendar.getFeedbackStatusEntity().getFeedbackStatusName());
					feedbackDTO.setFeedbackStatus(interviewerCalendar.getFeedbackComment());

				}
				RecruiterDetailsDTO recruiterDetailsDTO = null;
				if (interviewerCalendar.getRecruiterCalendarDetailsEntity() != null) {
					recruiterDetailsDTO = new RecruiterDetailsDTO();
					recruiterDetailsDTO.setId(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpId());
					recruiterDetailsDTO.setName(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpName());
					recruiterDetailsDTO.setEmailId(interviewerCalendar.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmailId());
					slotDetailsDTO.setCandidateName(
							interviewerCalendar.getRecruiterCalendarDetailsEntity().getCandidateName());
				}

				slotDetailsDTO.setFromDate(interviewerCalendar.getFromTime());
				slotDetailsDTO.setToDate(interviewerCalendar.getToTime());
				slotDetailsDTO.setFeedbackDetails(feedbackDTO);
				slotDetailsDTO.setRecruiterDetails(recruiterDetailsDTO);
				notInterviewedSlotDetailsDTOs.add(slotDetailsDTO);
				notInterviewedSlotsDTO.setInterviewerCount(notInterviewedSlotDetailsDTOs.size());
				notInterviewedSlotsDTO.setSlotsDetails(notInterviewedSlotDetailsDTOs);
				notInterviewedCount++;
			}
		}

		if (availableSlotsDTO != null) {
			availableSlotDtoList.add(availableSlotsDTO);
		}
		if (bookedSlotsDTO != null) {
			bookedSlotDtoList.add(bookedSlotsDTO);
		}
		if (interviewedSlotsDTO != null) {
			interviewedSlotDtoList.add(interviewedSlotsDTO);
		}
		if (notInterviewedSlotsDTO != null) {
			notInterviewedSlotDtoList.add(notInterviewedSlotsDTO);
		}

		availableReport.setStatusCount(availableCount);
		availableReport.setSlotsDTO(availableSlotDtoList);
		bookedReport.setStatusCount(bookedCount);
		bookedReport.setSlotsDTO(bookedSlotDtoList);
		interviewedReport.setStatusCount(interviewedCount);
		interviewedReport.setSlotsDTO(interviewedSlotDtoList);
		notInterviewedReport.setStatusCount(notInterviewedCount);
		notInterviewedReport.setSlotsDTO(notInterviewedSlotDtoList);
		reportDTOList.add(availableReport);
		reportDTOList.add(bookedReport);
		reportDTOList.add(interviewedReport);
		reportDTOList.add(notInterviewedReport);

		return reportDTOList;
	}

	@Override
	public Boolean setRescheduledRequested(RescheduleRequestDto rescheduleRequestDto) throws SmarthireException {
		InterviewerCalendarDetailsEntity interviewerCalender = interviewerRepository
				.findOne(rescheduleRequestDto.getCalendarId());
		if (interviewerCalender != null) {
			EmployeeMasterEntity employeeMasterEntity = interviewerCalender.getEmployeeMasterEntity();
			RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(INTERVIEWERROLE);
			List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
			if (roleMasterList.contains(roleMaster)) {
				InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity = interviewerRepository.findOne(rescheduleRequestDto.getCalendarId());
				RecruiterCalendarDetailsEntity recruiterCalendarDetailsEntity = interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity();
				SendEmailDTO sendEmailDTO = new SendEmailDTO();
				sendEmailDTO.setDomain("corp");
				sendEmailDTO.setPassword("bUNRPBpEMGtoca/R2cDVCFxUd5vUFfT+BdhVKehT9g8=");
				sendEmailDTO.setSubject("SmartHire Reschedule Slot Requested");
				sendEmailDTO.setSubscriptionKey("eO3cjl3SeOZFmumjZoSmQoVa5pCuIq8dfp19NQnqiUo=");
				sendEmailDTO.setUserId("gisoni");
				String msg = "";
				String msg1 = "";
				String fromdate = Utils.dateToString(interviewerCalendarDetailsEntity.getFromTime());
				String todate = Utils.dateToString(interviewerCalendarDetailsEntity.getToTime());
				DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				DateFormat timeFormat = new SimpleDateFormat("KK:mm a");
				DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

				try {
					Calendar from = Calendar.getInstance();
					from.setTime(inputFormat.parse(fromdate));
					from.add(Calendar.HOUR_OF_DAY, 0);
					from.add(Calendar.MINUTE, 0);

					Calendar to = Calendar.getInstance();
					to.setTime(inputFormat.parse(todate));
					to.add(Calendar.HOUR_OF_DAY, 0);
					to.add(Calendar.MINUTE, 0);
					msg = "Reschedule request raised successfully to " + interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity().getEmployeeMasterEntity().getEmpName() + " for the slot booked on " + dateFormat.format(inputFormat.parse(todate)) + " from " + timeFormat.format(from.getTime()) + " to " + timeFormat.format(to.getTime());
					msg1 = interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName() + " has raised a request to reschedule a slot booked on " +  dateFormat.format(inputFormat.parse(todate)) + " from " + timeFormat.format(from.getTime()) + " to " + timeFormat.format(to.getTime());
				} catch (ParseException e) {
					throw new SmarthireException(e.getMessage());
				}
				 
				sendEmailDTO.setBodyContent(msg);
				sendEmailDTO.setTo(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
				sendEmailDTO.setCc(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
				
				//String emailSuccess = emailService.sendEmail(sendEmailDTO);
				
				sendEmailDTO.setBodyContent(msg1);
				sendEmailDTO.setTo(recruiterCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
				sendEmailDTO.setCc(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
				
				//String emailSuccess1 = emailService.sendEmail(sendEmailDTO);
				return true;
			} else {
				throw new SmarthireException("YOU ARE NOT AUTHORIZED TO DELETE INTERVIEW SLOTS");
			}

		} else {
			throw new SmarthireException("NO INTERVIEW SLOT FOUND");
		}
	}

	@Override
	public Boolean addSupervisior(SupervisorDTO supervisorDto) throws SmarthireException {
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository
				.getEmployeeByEmail(supervisorDto.getSupervisiorEmailId());
		RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(SUPERVISORROLE);
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
		if (roleMasterList.contains(roleMaster)) {
			EmployeeMasterEntity employeeMasterEntity1 = employeeMasterRepository
					.getEmployeeByEmail(supervisorDto.getResourceEmailId());
			RoleMasterEntity roleMaster1 = roleMasterRepository.findByRoleName(RECRUITERROLE);
			List<RoleMasterEntity> roleMasterList1 = roleMasterRepository.findRoleByEmpId(employeeMasterEntity1.getEmpId());
			if (roleMasterList1.contains(roleMaster1)) {

				employeeMasterEntity1.setSupervisorMasterEntity(employeeMasterEntity);
				EmployeeMasterEntity employeeMasterSaved = employeeMasterRepository.save(employeeMasterEntity1);
				if (employeeMasterSaved != null) {
					return true;
				} else {
					throw new SmarthireException("Failed to save EmployeeMaster");
				}

			} else {
				throw new SmarthireException("Resource Exception");
			}

		} else {
			throw new SmarthireException("Supervisior Exception");
		}
	}

	@Override
	public List<AvailabilityDTO> getAvailibility(SlotDto slotDTO) throws SmarthireException {
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository.getEmployeeByEmail(slotDTO.getEmailId());
		RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(RECRUITERROLE);
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
		if (roleMasterList.contains(roleMaster)) {
			List<AvailabilityDTO> availabilityDTO = new ArrayList<>();
			List<InterviewerCalendarDetailsEntity> interviewerCalendarDetailsEntity = null;

			interviewerCalendarDetailsEntity = interviewerRepository.getAvailibility(slotDTO.getFrom(),
					slotDTO.getTo());
			for (InterviewerCalendarDetailsEntity interviewerCalendar : interviewerCalendarDetailsEntity) {
				if (!interviewerCalendar.isBooked()) {
					AvailabilityDTO availableDTO = new AvailabilityDTO();

					String fromdate = Utils.dateToString(interviewerCalendar.getFromTime());
					String todate = Utils.dateToString(interviewerCalendar.getToTime());
					DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
					DateFormat timeFormat = new SimpleDateFormat("KK:mm a");
					DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

					try {
						Calendar from = Calendar.getInstance();
						from.setTime(inputFormat.parse(fromdate));
						from.add(Calendar.HOUR_OF_DAY, HOUR);
						from.add(Calendar.MINUTE, MINUTES);

						Calendar to = Calendar.getInstance();
						to.setTime(inputFormat.parse(todate));
						to.add(Calendar.HOUR_OF_DAY, HOUR);
						to.add(Calendar.MINUTE, MINUTES);

						availableDTO.setFromDate(timeFormat.format(from.getTime()));
						availableDTO.setToDate(timeFormat.format(to.getTime()));
						availableDTO.setBookingDate(dateFormat.format(inputFormat.parse(todate)));
					} catch (ParseException e) {
						throw new SmarthireException(e.getMessage());
					}

					availableDTO.setTechnologyType(employeeTechnologyRepository
							.getDetails(interviewerCalendar.getEmployeeMasterEntity().getEmpId()));
					availableDTO.setEmpId(interviewerCalendar.getEmployeeMasterEntity().getEmpId());
					availableDTO.setEmpName(interviewerCalendar.getEmployeeMasterEntity().getEmpName());
					availableDTO.setEmailId(interviewerCalendar.getEmployeeMasterEntity().getEmailId());
					availableDTO.setLocation(interviewerCalendar.getEmployeeMasterEntity().getLocation());
					availableDTO.setInterviewerType(interviewGradeTypeRepository.findInterviewType(
							interviewerCalendar.getEmployeeMasterEntity().getGradeMasterEntity().getGradeId()));
					availabilityDTO.add(availableDTO);
				}
			}
			return availabilityDTO;
		} else {
			throw new SmarthireException("YOU ARE NOT AUTHORIZED TO VIEW INTERVIEWER AVAILABLE SLOTS");
		}
	}

	@Override
	public List<StatusCountDto> fetchTypeCount() throws SmarthireException {
		List<StatusCountDto> statusDtoList = new ArrayList<StatusCountDto>();
		StatusCountDto statusDto1 = new StatusCountDto();

		StatusCountDto statusDto2 = new StatusCountDto();

		List<StatusTypeDTO> statusTypeDtoList = new ArrayList<StatusTypeDTO>();
		List<StatusTypeDTO> statusTypeDtoList1 = new ArrayList<StatusTypeDTO>();

		StatusTypeDTO statusTypeDto = new StatusTypeDTO();
		StatusTypeDTO statusTypeDto2 = new StatusTypeDTO();

		int countL2Available = 0;
		int countL2Booked = 0;
		int countL2IsInterviwed = 0;
		int countL2NotInterviewed = 0;

		int countL1Available = 0;
		int countL1Booked = 0;
		int countL1IsInterviwed = 0;
		int countL1NotInterviewed = 0;

		Date date = new Date();

		List<InterviewerCalendarDetailsEntity> interviewerCalender = interviewerRepository.findAll();

		for (InterviewerCalendarDetailsEntity interviewerCalendr : interviewerCalender) {

			List<InterviewGradeTypeDetailsEntity> Interviewermaster = interviewerCalendr.getEmployeeMasterEntity()
					.getGradeMasterEntity().getInterviewGradeTypeDetailsEntities();
			for (InterviewGradeTypeDetailsEntity interviwerMaster : Interviewermaster) {

				if (interviwerMaster.getInterviewTypeMasterEntity().getTypeName().equals(L1TYPE)) {

					if (interviewerCalendr.isBooked()) {
						if (interviewerCalendr.getRecruiterCalendarDetailsEntity() != null) {
							if (interviewerCalendr.getRecruiterCalendarDetailsEntity().getIsInterviewerAssigned()
									&& interviewerCalendr.getFeedbackComment() == null
									&& (interviewerCalendr.getToTime()).before(date)) {
								countL1NotInterviewed++;

							} else if (interviewerCalendr.getFeedbackComment() != null
									&& (interviewerCalendr.getToTime()).before(date)) {

								countL1IsInterviwed++;

							} else if (interviewerCalendr.getToTime().after(date)) {
								countL1Booked++;
							}
						} else {
							throw new SmarthireException("Recruiter Calender Details Entities not found");
						}
					} else if (!interviewerCalendr.isBooked()
							|| !interviewerCalendr.getRecruiterCalendarDetailsEntity().getIsInterviewerAssigned()) {
						countL1Available++;
					}

				} else if (interviwerMaster.getInterviewTypeMasterEntity().getTypeName().equals(L2TYPE)) {

					if (interviewerCalendr.isBooked()) {
						if (interviewerCalendr.getRecruiterCalendarDetailsEntity() != null) {
							if (interviewerCalendr.getRecruiterCalendarDetailsEntity().getIsInterviewerAssigned()
									&& interviewerCalendr.getFeedbackComment() == null
									&& (interviewerCalendr.getToTime()).before(date)) {
								countL2NotInterviewed++;

							} else if (interviewerCalendr.getFeedbackComment() != null
									&& (interviewerCalendr.getToTime()).before(date)) {
								countL2IsInterviwed++;

							} else if (interviewerCalendr.getToTime().after(date)) {
								countL2Booked++;
							}
						} else {
							throw new SmarthireException("Recruiter Calender Details Entities not found");
						}
					} else if (!interviewerCalendr.isBooked()
							|| !interviewerCalendr.getRecruiterCalendarDetailsEntity().getIsInterviewerAssigned()) {
						countL2Available++;
					}

				}

			}

		}
		statusTypeDto = new StatusTypeDTO();
		statusTypeDto.setAvailable(countL1Available);
		statusTypeDto.setBooked(countL1Booked);
		statusTypeDto.setInterviewed(countL1IsInterviwed);
		statusTypeDto.setNotInterviewed(countL1NotInterviewed);
		statusTypeDtoList1.add(statusTypeDto);
		statusTypeDto2 = new StatusTypeDTO();
		statusTypeDto2.setAvailable(countL2Available);
		statusTypeDto2.setBooked(countL2Booked);
		statusTypeDto2.setInterviewed(countL2IsInterviwed);
		statusTypeDto2.setNotInterviewed(countL2NotInterviewed);
		statusTypeDtoList.add(statusTypeDto);
		statusDto1.setStatus(statusTypeDto);
		statusDto1.setType(L1TYPE);
		statusDto2.setType(L2TYPE);
		statusDto2.setStatus(statusTypeDto2);
		statusDtoList.add(statusDto1);
		statusDtoList.add(statusDto2);
		return statusDtoList;
	}

	@Override
	public List<StatusDTO> fetchInterviewSuccess(TimeDTO timeDto) {
		List<StatusDTO> StatusDtoList = new ArrayList<StatusDTO>();
		StatusDTO StatusDTO1 = new StatusDTO();
		StatusDTO StatusDTO2 = new StatusDTO();
		List<StatusDetailsDTO> statusDetails1List = new ArrayList<StatusDetailsDTO>();
		List<StatusDetailsDTO> statusDetails2List = new ArrayList<StatusDetailsDTO>();

		StatusDetailsDTO statusDetails1 = new StatusDetailsDTO();
		StatusDetailsDTO statusDetails2 = new StatusDetailsDTO();
		InterviewerDetailsDTO interviewerDetails1 = new InterviewerDetailsDTO();
		InterviewerDetailsDTO interviewerDetails2 = new InterviewerDetailsDTO();

		RecruiterDetailsDTO recruiterDetails1 = new RecruiterDetailsDTO();
		RecruiterDetailsDTO recruiterDetails2 = new RecruiterDetailsDTO();

		Date cal = new Date();
		List<InterviewerCalendarDetailsEntity> interviewerDetailsEntity = null;
		if (timeDto.getTechId() != 0) {
			interviewerDetailsEntity = interviewerRepository.findByToTimeAndFromTimeAndTechId(timeDto.getFromTime(),
					timeDto.getToTime(), timeDto.getTechId());
		} else {
			interviewerDetailsEntity = interviewerRepository.findByToTimeAndFromTime(timeDto.getFromTime(),
					timeDto.getToTime());
		}

		for (InterviewerCalendarDetailsEntity interviewerCalendarDetailsEntity : interviewerDetailsEntity) {
			if (interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity() != null
					&& interviewerCalendarDetailsEntity.getFeedbackComment() != null
					&& (interviewerCalendarDetailsEntity.getToTime()).before(cal)) {
				if (interviewerCalendarDetailsEntity.getFeedbackStatusEntity().getFeedbackStatusName().equals(PASS)) {
					statusDetails1 = new StatusDetailsDTO();
					interviewerDetails1 = new InterviewerDetailsDTO();
					recruiterDetails1 = new RecruiterDetailsDTO();
					statusDetails1.setFromtime(interviewerCalendarDetailsEntity.getFromTime());
					statusDetails1.setTotime(interviewerCalendarDetailsEntity.getToTime());
					interviewerDetails1
							.setEmailId(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
					interviewerDetails1
							.setEmployeeId(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId());
					interviewerDetails1.setInterviewerName(
							interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName());
					statusDetails1.setInterviewerDetails(interviewerDetails1);
					recruiterDetails1.setId(interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpId());
					recruiterDetails1.setName(interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpName());
					recruiterDetails1.setEmailId(interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmailId());
					statusDetails1.setRecruiterDetails(recruiterDetails1);
					statusDetails1.setFeedbackComments(interviewerCalendarDetailsEntity.getFeedbackComment());
					statusDetails1List.add(statusDetails1);

				} else if (interviewerCalendarDetailsEntity.getFeedbackStatusEntity().getFeedbackStatusName()
						.equals(FAIL)) {
					statusDetails2 = new StatusDetailsDTO();
					interviewerDetails2 = new InterviewerDetailsDTO();
					recruiterDetails2 = new RecruiterDetailsDTO();
					statusDetails2.setFromtime(interviewerCalendarDetailsEntity.getFromTime());
					statusDetails2.setTotime(interviewerCalendarDetailsEntity.getToTime());
					interviewerDetails2
							.setEmailId(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmailId());
					interviewerDetails2
							.setEmployeeId(interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpId());
					interviewerDetails2.setInterviewerName(
							interviewerCalendarDetailsEntity.getEmployeeMasterEntity().getEmpName());
					statusDetails2.setInterviewerDetails(interviewerDetails2);
					recruiterDetails2.setId(interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpId());
					recruiterDetails2.setName(interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmpName());
					recruiterDetails2.setEmailId(interviewerCalendarDetailsEntity.getRecruiterCalendarDetailsEntity()
							.getEmployeeMasterEntity().getEmailId());
					statusDetails2.setRecruiterDetails(recruiterDetails2);
					statusDetails2.setFeedbackComments(interviewerCalendarDetailsEntity.getFeedbackComment());
					statusDetails2List.add(statusDetails2);

				}

			}
		}
		StatusDTO2.setStatus(FAIL);
		StatusDTO1.setStatus(PASS);

		StatusDTO1.setDetails(statusDetails1List);
		StatusDTO2.setDetails(statusDetails2List);
		StatusDtoList.add(StatusDTO1);
		StatusDtoList.add(StatusDTO2);

		return StatusDtoList;
	}

	@Override
	public List<TechnologyDTO> fetchInterviewerSkills(EmailDto emailDto) throws SmarthireException {
		List<TechnologyDTO> technologyDtoList = new ArrayList<>();
		TechnologyDTO technologyDTO = null;
		EmployeeMasterEntity employeeMasterEntity = employeeMasterRepository.getEmployeeByEmail(emailDto.getEmail());
		RoleMasterEntity roleMaster = roleMasterRepository.findByRoleName(INTERVIEWERROLE);
		List<RoleMasterEntity> roleMasterList = roleMasterRepository.findRoleByEmpId(employeeMasterEntity.getEmpId());
		if (roleMasterList.contains(roleMaster)) {
			List<EmployeeTechnologyDetailsEntity> employeeTechnologyDetailsEntities = employeeMasterEntity
					.getEmployeeTechnologyDetailsEntities();

			for (EmployeeTechnologyDetailsEntity employeeTechnologyDetailsEntity : employeeTechnologyDetailsEntities) {
				technologyDTO = new TechnologyDTO();
				technologyDTO
						.setTechnologyId(employeeTechnologyDetailsEntity.getTechnologyMasterEntity().getTechnologyId());
				technologyDTO.setTechnologyName(
						employeeTechnologyDetailsEntity.getTechnologyMasterEntity().getTechnologyName());
				technologyDtoList.add(technologyDTO);
			}

			return technologyDtoList;
		} else {
			throw new SmarthireException("YOU ARE NOT AUTHORISED TO SEE INTERVIEWER SKILLSET");
		}
	}

	

}
