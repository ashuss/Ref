package com.capgemini.smarthire.services;

import java.io.InputStream;
import java.io.PushbackInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

import com.capgemini.smarthire.dtos.ReaderReturnDTO;
import com.capgemini.smarthire.dtos.SplitResultDTO;
import com.capgemini.smarthire.dtos.SplitReturnDTO;

import java.util.ArrayList;

public class CSV {
    private static final int NUMMARK = 10;
    private static final char DQUOTE = '"';
    private static final char CRETURN = '\r';
    private static final char LFEED = '\n';
    private static final char COMMENT = '#';
    private static final int THREE = 3;
    private static final int TWO = 2;

    private boolean stripMultipleNewlines;

    private char separator;
    private List<String> fields;
    private boolean eofSeen;
    private Reader in;

    public CSV(boolean stripMultipleNewlines, char separator, InputStream input)
            throws IOException {
        this.stripMultipleNewlines = stripMultipleNewlines;
        this.separator = separator;
        this.fields = new ArrayList<>();
        this.eofSeen = false;
        this.in = new BufferedReader(stripBom(input));
    }

    public static Reader stripBom(InputStream in) throws IOException {
        PushbackInputStream pin = new PushbackInputStream(in, THREE);
        byte[] b = new byte[THREE];
        int len = pin.read(b, 0, b.length);
        ReaderReturnDTO reader = null;
        if (len >= TWO) {
            reader = readerConditionB(b, pin, len);
            if (reader.getIsReturn()) {
                return reader.getReturnReader();
            }
        } else if (len > 0) {
            pin.unread(b, 0, len);
        }
        return new InputStreamReader(pin, "UTF-8");
    }

    private static ReaderReturnDTO readerConditionB(byte[] b, PushbackInputStream pin, int len) throws IOException {
        ReaderReturnDTO reader = new ReaderReturnDTO();
        reader.setIsReturn(false);
        if ((b[0] & 0xFF) == 0xFE && (b[1] & 0xFF) == 0xFF) {
            reader.setIsReturn(true);
            reader.setReturnReader(new InputStreamReader(pin, "UTF-16BE"));
            return reader;
        } else if ((b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xFE) {
            reader.setIsReturn(true);
            reader.setReturnReader(new InputStreamReader(pin, "UTF-16LE"));
            return reader;
        } else {
            pin.unread(b, 0, len);
        }
        return reader;
    }

    public boolean hasNext() throws java.io.IOException {
        if (eofSeen) {
            return false;
        }
        fields.clear();
        eofSeen = split(in, fields);
        if (eofSeen) {
            return !fields.isEmpty();
        } else {
            return true;
        }
    }

    public List<String> next() {
        return fields;
    }

    private static boolean discardLinefeed(Reader in, boolean stripMultiple) throws java.io.IOException {
        if (stripMultiple) {
            return discardLinefeedIf(in);
        } else {
            return discardLinefeedElse(in);
        }
    }

    private static boolean discardLinefeedIf(Reader in) throws IOException {
        in.mark(NUMMARK);
        int value = in.read();
        while (value != -1) {
            char c = (char) value;
            if (c != CRETURN && c != LFEED) {
                in.reset();
                return false;
            } else {
                in.mark(NUMMARK);
                value = in.read();
            }
        }
        return true;
    }

    private static boolean discardLinefeedElse(Reader in) throws IOException {
        in.mark(NUMMARK);
        int value = in.read();
        if (value == -1) {
            return true;
        } else if ((char) value != LFEED) {
            in.reset();
        }
        return false;
    }

    private boolean skipComment(Reader in) throws java.io.IOException {
        int value;
        while ((value = in.read()) != -1) {
            char c = (char) value;
            if (c == CRETURN) {
                return discardLinefeed(in, stripMultipleNewlines);
            }

        }
        return true;
    }

    private SplitResultDTO cReturnCase(StringBuilder sbuf, List<String> fields, Reader in) throws IOException {
        SplitResultDTO splitResultDTO = new SplitResultDTO();
        splitResultDTO.setFields(fields);
        splitResultDTO.setIn(in);
        splitResultDTO.setSbuf(sbuf);
        splitResultDTO.setIsBreak(false);
        if (sbuf.length() > 0) {
            fields.add(sbuf.toString());
            sbuf.delete(0, sbuf.length());
            splitResultDTO.setFields(fields);
            splitResultDTO.setSbuf(sbuf);
            splitResultDTO.setIsBreak(true);
        }
        splitResultDTO.setIsReturn(true);
        splitResultDTO.setReturnValue(discardLinefeed(in, stripMultipleNewlines));
        return splitResultDTO;
    }

    private SplitResultDTO lfeedCase(StringBuilder sbuf, List<String> fields, Reader in) throws IOException {
        SplitResultDTO splitResultDTO = new SplitResultDTO();
        splitResultDTO.setFields(fields);
        splitResultDTO.setSbuf(sbuf);
        if (sbuf.length() > 0) {
            fields.add(sbuf.toString());
            sbuf.delete(0, sbuf.length());
            splitResultDTO.setFields(fields);
            splitResultDTO.setSbuf(sbuf);
        }
        splitResultDTO.setIsReturn(true);
        if (stripMultipleNewlines) {
            splitResultDTO.setReturnValue(discardLinefeed(in, stripMultipleNewlines));
            return splitResultDTO;
        } else {
            splitResultDTO.setReturnValue(false);
            return splitResultDTO;
        }
    }

    private boolean split(Reader in1, List<String> field) throws java.io.IOException {
        fields = field;
        in = in1;
        StringBuilder sbuf = new StringBuilder();
        int value;
        while ((value = in.read()) != -1) {
            SplitResultDTO splitDto = null;
            char c = (char) value;
            switch (c) {
            case CRETURN: 
                List<String> field1 = fields;
                splitDto = cReturnCase(sbuf, field1, in);
                return splitDto.getReturnValue();
            case LFEED: 
                List<String> field2 = fields;
                splitDto = lfeedCase(sbuf, field2, in);
                return splitDto.getReturnValue();
            case DQUOTE: 
                splitDto = dquoteCase(value, c, sbuf, in, fields);
                in = splitDto.getIn();
                if (splitDto.getIsReturn()) {
                    return splitDto.getReturnValue();
                }
            break;
            default: 
                List<String> fieldDefault = fields;
                splitDto = defaultCase(c, sbuf, fieldDefault, in);
                if (splitDto.getIsReturn()) {
                    return splitDto.getReturnValue();
                }
            }
            sbuf = splitDto.getSbuf();
            fields = splitDto.getFields();
        }
        if (sbuf.length() > 0) {
            fields.add(sbuf.toString());
            sbuf.delete(0, sbuf.length());
        }
        return true;
    }

    private SplitResultDTO dquoteCase(int value2, char c2, StringBuilder sbuf, Reader in1, List<String> field)
            throws IOException {
        fields = field;
        in = in1;
        int value1 = value2;
        char c1 = c2;
        SplitResultDTO splitResultDTO = new SplitResultDTO();
        splitResultDTO.setIsBreak(false);
        splitResultDTO.setIsReturn(false);
        splitResultDTO.setSbuf(sbuf);
        splitResultDTO.setFields(fields);
        splitResultDTO.setIn(in);
        while ((value1 = in.read()) != -1) {
            c1 = (char) value1;
            if (c1 == DQUOTE) {
                Reader in2 = in;
                SplitReturnDTO splitReturn = dquoteCaseMatch(splitResultDTO, sbuf, value1, c1, in2, fields);
                if (splitReturn.getIsBreak()) {
                    in = splitReturn.getSplitResultDTO().getIn();
                    break;
                }
                if (splitReturn.getIsReturn()) {
                    return splitReturn.getSplitResultDTO();
                } else {
                    splitResultDTO = splitReturn.getSplitResultDTO();
                }
            } else {
                sbuf.append(c1);
                splitResultDTO.setSbuf(sbuf);
            }
        }
        if (value1 == -1) {
            return dquoteCaseFinal(fields, sbuf, splitResultDTO);

        }
        return splitResultDTO;
    }

    private SplitReturnDTO dquoteCaseMatch(SplitResultDTO splitResultDTO, StringBuilder sbuf, int value2, char c2,
            Reader in1, List<String> field) throws IOException {
        fields = field;
        SplitReturnDTO splitReturnDTO = new SplitReturnDTO();
        splitReturnDTO.setIsReturn(false);
        splitReturnDTO.setIsBreak(false);
        in = in1;
        int value1 =0;
        value1 = value2;
        char c1 = c2; 
        in.mark(NUMMARK);
        if ((value1 = in.read()) == -1) {
            splitReturnDTO.setIsReturn(true);
            splitReturnDTO.setSplitResultDTO(dquoteCaseFinal(fields, sbuf, splitResultDTO));
        } else if ((c1 = (char) value1) == DQUOTE) {
            sbuf.append(DQUOTE);
            splitResultDTO.setSbuf(sbuf);
            splitReturnDTO.setSplitResultDTO(splitResultDTO);
        } else if (c1 == CRETURN) {
            splitReturnDTO.setIsReturn(true);
            splitReturnDTO.setSplitResultDTO(creturnCaseFinal(sbuf, splitResultDTO, fields));
        } else if (c1 == LFEED) {
            splitReturnDTO.setIsReturn(true);
            splitReturnDTO.setSplitResultDTO(lfeedCaseFinal(sbuf, splitResultDTO));
        } else {
            in.reset();
            splitResultDTO.setIn(in);
            splitReturnDTO.setSplitResultDTO(splitResultDTO);
            splitReturnDTO.setIsBreak(true);
        }
        return splitReturnDTO;
    }

    private SplitResultDTO dquoteCaseFinal(List<String> field, StringBuilder sbuf, SplitResultDTO splitResultDTO1) {
        SplitResultDTO splitResultDTO = splitResultDTO1;
        fields = field;
        if (sbuf.length() > 0) {
            fields.add(sbuf.toString());
            sbuf.delete(0, sbuf.length());
            splitResultDTO.setIsBreak(true);
            splitResultDTO.setFields(fields);
            splitResultDTO.setSbuf(sbuf);
        }
        splitResultDTO.setIsReturn(true);
        splitResultDTO.setReturnValue(true);
        return splitResultDTO;
    }

    private SplitResultDTO creturnCaseFinal(StringBuilder sbuf, SplitResultDTO splitResultDTO1, List<String> field1)
            throws IOException {
        SplitResultDTO splitResultDTO = splitResultDTO1;
        fields = field1;
        if (sbuf.length() > 0) {
            fields.add(sbuf.toString());
            sbuf.delete(0, sbuf.length());
            splitResultDTO.setIsBreak(true);
            splitResultDTO.setFields(fields);
            splitResultDTO.setSbuf(sbuf);
        }
        splitResultDTO.setIsReturn(true);
        splitResultDTO.setReturnValue(discardLinefeed(in, stripMultipleNewlines));
        return splitResultDTO;
    }

    private SplitResultDTO lfeedCaseFinal(StringBuilder sbuf, SplitResultDTO splitResultDTO1) throws IOException {
        SplitResultDTO splitResultDTO = splitResultDTO1;
        if (sbuf.length() > 0) {
            fields.add(sbuf.toString());
            sbuf.delete(0, sbuf.length());
            splitResultDTO.setIsBreak(true);
            splitResultDTO.setFields(fields);
            splitResultDTO.setSbuf(sbuf);
        }
        if (stripMultipleNewlines) {
            splitResultDTO.setIsReturn(true);
            splitResultDTO.setReturnValue(discardLinefeed(in, stripMultipleNewlines));
            return splitResultDTO;
        } else {
            splitResultDTO.setIsReturn(true);
            splitResultDTO.setReturnValue(false);
            return splitResultDTO;
        }
    }

    private SplitResultDTO defaultCase(char c, StringBuilder sbuf, List<String> fields, Reader in) throws IOException {
        SplitResultDTO splitDto = new SplitResultDTO();
        splitDto.setIsReturn(false);
        splitDto.setFields(fields);
        splitDto.setSbuf(sbuf);
        if (c == separator) {
            fields.add(sbuf.toString());
            sbuf.delete(0, sbuf.length());
            splitDto.setFields(fields);
            splitDto.setSbuf(sbuf);
        } else {
            if (c == COMMENT && fields.isEmpty() && sbuf.toString().trim().isEmpty()) {
                boolean eof = skipComment(in);
                if (eof) {
                    splitDto.setIsReturn(true);
                    splitDto.setReturnValue(eof);
                    return splitDto;
                } else {
                    sbuf.delete(0, sbuf.length());
                    splitDto.setSbuf(sbuf);
                }
            } else {
                sbuf.append(c);
                splitDto.setSbuf(sbuf);
            }
        }
        return splitDto;
    }

}