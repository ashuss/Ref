package com.capgemini.smarthire.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smarthire.dtos.LookupDTO;
import com.capgemini.smarthire.dtos.ResponseDto;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.services.LookupService;
import com.jcabi.log.Logger;

@RestController
@RequestMapping("/lookup")
public class LookupController {
    
    private static final String EXCEPTION_MESSAGE = "Exception is";

    @Autowired
    LookupService lookupService;

    @RequestMapping("/fetchDropdown")
    public ResponseDto fetchDropdown(@RequestParam long screenId) {
        ResponseDto responseDto = new ResponseDto();
        try {
            List<LookupDTO> lookupList = lookupService.fetchDropdown(screenId);
            List<Object> response = new ArrayList<>();
            response.add(lookupList);
            responseDto.setResponse(response);
        } catch (SmarthireException e) {
            Logger.info(e, EXCEPTION_MESSAGE);
            responseDto.setException(e.getMessage());
        }
 
        return responseDto;
    }

}
