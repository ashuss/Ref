package com.capgemini.smarthire.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.RecruiterCalendarDetailsDto;
import com.capgemini.smarthire.dtos.ResponseDto;
import com.capgemini.smarthire.dtos.SaveRecruiterSlotDto;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.services.RecruiterService;
import com.jcabi.log.Logger;

@RestController
@RequestMapping("/recruiter")
public class RecruiterController {
    
    private static final String EXCEPTION_MESSAGE = "Exception is";

    @Autowired
    RecruiterService recruiterService;

    @RequestMapping("/getAllRecruiterSlots")
    public ResponseDto getAllRecruiterSlots(@RequestBody EmailDto emailDto) {
        ResponseDto responseDto = new ResponseDto();
        List<RecruiterCalendarDetailsDto> recruiterCalendarDetailsDtos;
        try {
            recruiterCalendarDetailsDtos = recruiterService.getAllRecruiterSlots(emailDto);
            List<Object> response = new ArrayList<>();
            response.add(recruiterCalendarDetailsDtos);
            responseDto.setResponse(response);
        } catch (SmarthireException e) {
            Logger.info(e, EXCEPTION_MESSAGE);
            responseDto.setException(e.getMessage());
        }

        return responseDto;
    }

    @RequestMapping("/saveInterviewSlot")
    public ResponseDto saveInterviewSlot(@RequestBody SaveRecruiterSlotDto saveRecruiterSlotDto) {
        ResponseDto responseDto = new ResponseDto();
        List<Object> response = new ArrayList<>();
        RecruiterCalendarDetailsDto recruiterCalendarDetailsDto;
        try {
            recruiterCalendarDetailsDto = recruiterService.saveInterviewSlot(saveRecruiterSlotDto);
            response.add(recruiterCalendarDetailsDto);
            responseDto.setResponse(response);
        } catch (SmarthireException e) {
            Logger.info(e, EXCEPTION_MESSAGE);
            responseDto.setException(e.getMessage());
        }
        return responseDto;
    }

    @RequestMapping("/rescheduleSlot")
    public ResponseDto rescheduleSlot(@RequestBody SaveRecruiterSlotDto saveRecruiterSlotDto) {
        ResponseDto responseDto = new ResponseDto();
        List<Object> response = new ArrayList<>();
        RecruiterCalendarDetailsDto recruiterCalendarDetailsDto;
        try {
            recruiterCalendarDetailsDto = recruiterService.rescheduleSlot(saveRecruiterSlotDto);
            response.add(recruiterCalendarDetailsDto);
            responseDto.setResponse(response);
            responseDto.setMessage("RESCHEDULED SLOT SUCCESSFULLY");
        } catch (SmarthireException e) {
            Logger.info(e, EXCEPTION_MESSAGE);
            responseDto.setException(e.getMessage());
        }

        return responseDto;
    }

    @RequestMapping("/deleteSlot")
    public ResponseDto deleteSlot(@RequestBody SaveRecruiterSlotDto saveRecruiterSlotDto) {
        ResponseDto responseDto = new ResponseDto();
        try {
            Boolean deleteSuccess = recruiterService.deleteSlot(saveRecruiterSlotDto);
            List<Object> response = new ArrayList<>();
            response.add(deleteSuccess);
            responseDto.setResponse(response);
            responseDto.setMessage("DELETED SLOT SUCCESSFULLY");
        } catch (SmarthireException e) {
            Logger.info(e, EXCEPTION_MESSAGE);
            responseDto.setException(e.getMessage());
        }
        return responseDto;
    }
}
