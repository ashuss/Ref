package com.capgemini.smarthire.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smarthire.dtos.ResponseDto;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.services.ConfigurationService;
import com.jcabi.log.Logger;

@RestController
@RequestMapping("/configuration")
public class ConfigurationController {
    
    private static final String EXCEPTION_MESSAGE = "Exception is";

    @Autowired
    ConfigurationService configService;

    @RequestMapping("/constants")
    public ResponseDto getAllConfigurationConstants() {
        ResponseDto responseDto = new ResponseDto();
        try {
            Map<String, String> constantsMap = configService.getAllConstants();
            List<Object> response = new ArrayList<>();
            response.add(constantsMap);
            responseDto.setResponse(response);
        } catch (SmarthireException e) {
            Logger.info(e, EXCEPTION_MESSAGE);
            responseDto.setException(e.getMessage());
        }
        return responseDto;
    }

}
