package com.capgemini.smarthire.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smarthire.services.ExcelService;

@RestController
@RequestMapping("/excel")
public class ExcelReader {

    @Autowired
    ExcelService excelService;

    @RequestMapping("/readExcel")
    public Boolean readExcel() {
        return excelService.readExcel();
    }
}
