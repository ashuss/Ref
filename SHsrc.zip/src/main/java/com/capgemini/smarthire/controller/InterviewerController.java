package com.capgemini.smarthire.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.smarthire.dtos.AvailabilityDTO;
import com.capgemini.smarthire.dtos.CheckAvailabilityDTO;
import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.FeedbackDTO;
import com.capgemini.smarthire.dtos.InterviewerCalendarSavedSlotDTO;
import com.capgemini.smarthire.dtos.InterviewerCalenderDetailsDto;
import com.capgemini.smarthire.dtos.InterviewerDropdownDTO;
import com.capgemini.smarthire.dtos.InterviewerDropdownRequestDTO;
import com.capgemini.smarthire.dtos.InterviewerSaveSlotDto;
import com.capgemini.smarthire.dtos.ReportDTO;
import com.capgemini.smarthire.dtos.RescheduleRequestDto;
import com.capgemini.smarthire.dtos.ResponseDto;
import com.capgemini.smarthire.dtos.SlotDto;
import com.capgemini.smarthire.dtos.SmarthireReportDTO;
import com.capgemini.smarthire.dtos.StatusCountDto;
import com.capgemini.smarthire.dtos.StatusDTO;
import com.capgemini.smarthire.dtos.SupervisorDTO;
import com.capgemini.smarthire.dtos.TechnologyDTO;
import com.capgemini.smarthire.dtos.TimeDTO;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.services.InterviewerService;
import com.jcabi.log.Logger;

@RestController
@RequestMapping("/interviewer")
public class InterviewerController {

	private static final String EXCEPTION_MESSAGE = "Exception is ";

	@Autowired
	InterviewerService interviewerService;
	
	@RequestMapping("/getInterviewerSlots")
	public ResponseDto getInterviewerSlots(@RequestBody CheckAvailabilityDTO checkAvailabilityDTO) {
		ResponseDto responseDto = new ResponseDto();
		List<InterviewerCalenderDetailsDto> interviewerCalenderDetailsDtos;
		try {
			interviewerCalenderDetailsDtos = interviewerService.getInterviewersSlots(checkAvailabilityDTO);
			List<Object> response = new ArrayList<>();
			response.add(interviewerCalenderDetailsDtos);
			responseDto.setResponse(response);
		} catch (SmarthireException e) {
			Logger.info(e, EXCEPTION_MESSAGE + e.getMessage());
			responseDto.setException(e.getMessage());
		}

		return responseDto;
	}

	@RequestMapping("/getAllInterviewerSlots")
	public ResponseDto getAllInterviewerSlots(@RequestBody EmailDto emailDto) {
		ResponseDto responseDto = new ResponseDto();
		List<InterviewerCalenderDetailsDto> interviewerCalenderDetailsDtos;
		try {
			interviewerCalenderDetailsDtos = interviewerService.getAllInterviewerSlots(emailDto);
			List<Object> response = new ArrayList<>();
			response.add(interviewerCalenderDetailsDtos);
			responseDto.setResponse(response);
		} catch (SmarthireException e) {
			Logger.info(e, EXCEPTION_MESSAGE + e.getMessage());
			responseDto.setException(e.getMessage());
		}

		return responseDto;
	}

	@RequestMapping("/saveFreeSlot")
	public ResponseDto saveFreeSlot(@RequestBody InterviewerSaveSlotDto interviewerSaveSlotDto) {
		ResponseDto responseDto = new ResponseDto();
		List<Object> response = new ArrayList<>();
		InterviewerCalendarSavedSlotDTO interviewerCalenderSavedSlotDTO;
		try {
			interviewerCalenderSavedSlotDTO = interviewerService.saveFreeSlot(interviewerSaveSlotDto);
			response.add(interviewerCalenderSavedSlotDTO);
			responseDto.setResponse(response);
			responseDto.setMessage("INTERVIEW SLOT SAVED SUCCESSFULLY");
		} catch (SmarthireException e) {
			Logger.info(e, EXCEPTION_MESSAGE + e.getMessage());
			responseDto.setException(e.getMessage());
		}
		return responseDto;
	}

	@RequestMapping("/interviewerDropdown")
	public ResponseDto fetchInterviewerDropdown(
			@RequestBody InterviewerDropdownRequestDTO interviewerDropdownRequestDTO) {
		ResponseDto responseDto = new ResponseDto();
		List<Object> response = new ArrayList<>();
		List<InterviewerDropdownDTO> interviewerDropdownList;
		try {
			interviewerDropdownList = interviewerService.fetchInterviewerDropdown(interviewerDropdownRequestDTO);
			response.add(interviewerDropdownList);
			responseDto.setResponse(response);
		} catch (SmarthireException e) {
			Logger.info(e, EXCEPTION_MESSAGE + e.getMessage());
			responseDto.setException(e.getMessage());
		}
		return responseDto;

	}

	@RequestMapping("/deleteInterviewSlot")
	public ResponseDto deleteInterviewSlot(@RequestParam long calenderId) {
		ResponseDto responseDto = new ResponseDto();

		try {
			Boolean deleteSuccess = interviewerService.deleteInterviewSlot(calenderId);
			List<Object> response = new ArrayList<>();
			response.add(deleteSuccess);
			responseDto.setResponse(response);
			responseDto.setMessage("INTERVIEW SLOT DELETED SUCCESSFULLY");
		} catch (SmarthireException e) {
			Logger.info(e, EXCEPTION_MESSAGE + e.getMessage());
			responseDto.setException(e.getMessage());
		}
		return responseDto;

	}

	@RequestMapping("/saveFeedback")
	public ResponseDto saveFeedback(@RequestBody FeedbackDTO feedbackDto) {
		ResponseDto responseDto = new ResponseDto();

		try {
			Boolean feedbackSaveSuccess = interviewerService.saveFeedback(feedbackDto);
			List<Object> response = new ArrayList<>();
			response.add(feedbackSaveSuccess);
			responseDto.setResponse(response);
			responseDto.setMessage("FEEDBACK SAVED SUCCESSFULLY");
		} catch (SmarthireException e) {
			responseDto.setException(e.getMessage());
		}
		return responseDto;
	}

	@RequestMapping("/generateReport")
	public ResponseDto generateReport(@RequestBody SmarthireReportDTO reportDto) {
		ResponseDto responseDto = new ResponseDto();
		try {
			List<ReportDTO> smarthireReport = interviewerService.generateReport(reportDto);
			List<Object> response = new ArrayList<>();
			response.add(smarthireReport);
			responseDto.setResponse(response);
		} catch (SmarthireException e) {
			responseDto.setException(e.getMessage());
		}
		return responseDto;
	}

	@RequestMapping("/rescheduledRequest")
	public ResponseDto setRescheduledRequested(@RequestBody RescheduleRequestDto rescheduleRequestDto) {
		ResponseDto responseDto = new ResponseDto();
		try {
			Boolean isRescheduled = interviewerService.setRescheduledRequested(rescheduleRequestDto);
			List<Object> response = new ArrayList<>();
			response.add(isRescheduled);
			responseDto.setResponse(response);
		} catch (SmarthireException e) {
			responseDto.setException(e.getMessage());
		}
		return responseDto;
	}

	@RequestMapping("/interviewTypeReport")
	public ResponseDto fetchTypeCount() {
		ResponseDto responseDto = new ResponseDto();
		try {
			List<StatusCountDto> interviewTypeReport = interviewerService.fetchTypeCount();
			List<Object> response = new ArrayList<>();
			response.add(interviewTypeReport);
			responseDto.setResponse(response);
		} catch (SmarthireException e) {
			responseDto.setException(e.getMessage());
		}
		return responseDto;

	}
	
	@RequestMapping("/addSupervisior")
    public ResponseDto addSupervisior(@RequestBody SupervisorDTO supervisorDto) throws SmarthireException{
        ResponseDto responseDto = new ResponseDto();
         Boolean isRescheduled = interviewerService.addSupervisior(supervisorDto);
             List<Object> response = new ArrayList<>();
             response.add(isRescheduled);
             responseDto.setResponse(response);
             return responseDto;
    }
	
	@RequestMapping("/getAvailibility")
    public ResponseDto getAvailibility(@RequestBody SlotDto slotDTO){
		ResponseDto responseDto = new ResponseDto();
		try {
			List<AvailabilityDTO> availabilityReport = interviewerService.getAvailibility(slotDTO);
			List<Object> response = new ArrayList<>();
			response.add(availabilityReport);
			responseDto.setResponse(response);
		} catch (SmarthireException e) {
			Logger.info(e, EXCEPTION_MESSAGE + e.getMessage());
			responseDto.setException(e.getMessage());
		}
		return responseDto;
    }
	
	@RequestMapping("/interviewSuccessReport")
    public ResponseDto fetchInterviewSuccess(@RequestBody TimeDTO timeDto) throws ParseException{
        ResponseDto responseDto = new ResponseDto();
        try {
        	List<StatusDTO> interviwerReport = interviewerService.fetchInterviewSuccess(timeDto);
			List<Object> response = new ArrayList<>();
			response.add(interviwerReport);
			responseDto.setResponse(response);
		} catch (SmarthireException e) {
			Logger.info(e, EXCEPTION_MESSAGE + e.getMessage());
			responseDto.setException(e.getMessage());
		}
		return responseDto;
    }
	
	@RequestMapping("/interviewerSkill")
    public ResponseDto fetchInterviewerSkill(@RequestBody EmailDto emailDto){
        ResponseDto responseDto = new ResponseDto();
        try {
        	List<TechnologyDTO> interviwerSkill = interviewerService.fetchInterviewerSkills(emailDto);
			List<Object> response = new ArrayList<>();
			response.add(interviwerSkill);
			responseDto.setResponse(response);
		} catch (SmarthireException e) {
			Logger.info(e, EXCEPTION_MESSAGE + e.getMessage());
			responseDto.setException(e.getMessage());
		}
		return responseDto;
    }




}
