package com.capgemini.smarthire.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.ResourceDTO;
import com.capgemini.smarthire.dtos.ResponseDto;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.services.SupervisorService;
import com.jcabi.log.Logger;

@RestController
@RequestMapping("/supervisor")
public class SupervisorController {
	
	@Autowired
	SupervisorService supervisorService;
	
	 private static final String EXCEPTION_MESSAGE = "Exception is ";
	
    @RequestMapping("/getResources")
    public ResponseDto getResources(@RequestBody EmailDto emailDto){
        ResponseDto responseDto = new ResponseDto();

    	try{
    		List<ResourceDTO>  resource=supervisorService.getResources(emailDto);
    		 List<Object> response = new ArrayList<>();
             response.add(resource);
             responseDto.setResponse(response);
    	}
    	catch(SmarthireException e){
    		 Logger.info(e, EXCEPTION_MESSAGE+e.getMessage());
             responseDto.setException(e.getMessage());	 
    	}
    	return responseDto;
    } 
}
