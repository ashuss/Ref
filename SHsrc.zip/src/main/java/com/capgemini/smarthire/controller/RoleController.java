package com.capgemini.smarthire.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.services.RoleService;

@RestController
@RequestMapping("/role")
public class RoleController {

    @Autowired
    RoleService roleService;

    @RequestMapping(value = "/getRole", method = RequestMethod.POST, produces = "application/json", consumes = "application/json", headers = "Accept=application/json")
    public List<String> getRole(@RequestBody EmailDto emailDto) {
        return roleService.getRole(emailDto);
    }
}
