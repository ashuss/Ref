package com.capgemini.smarthire.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smarthire.dtos.SmarthireReportDTO;
import com.capgemini.smarthire.services.ReportService;

@RestController
@RequestMapping("/report")
public class ReportController {

	@Autowired
    ReportService reportService;
	
	@RequestMapping("/generateReport")
    public void buildExcelDocument(SmarthireReportDTO reportDto, HttpServletRequest request,HttpServletResponse response) throws Exception{
		reportService.buildExcelDocument(reportDto, request, response);
    }
}
