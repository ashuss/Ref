package com.capgemini.smarthire.dtos;

import java.util.Date;

public class RecruiterCalendarDetailsDto {

    private long recruiterCalendarId;

    private long recruiterId;

    private String recruiterName;

    private String candidateName;

    private long technologyId;

    private String technologyName;

    private long interviewType;

    private String interviewTypeName;

    private Date fromTime;

    private Date toTime;

    private InterviewerDto interviewerDto;

    private String comments;

    private long buId;

    public long getRecruiterCalendarId() {
        return recruiterCalendarId;
    }

    public void setRecruiterCalendarId(long recruiterCalendarId) {
        this.recruiterCalendarId = recruiterCalendarId;
    }

    public long getRecruiterId() {
        return recruiterId;
    }

    public void setRecruiterId(long recruiterId) {
        this.recruiterId = recruiterId;
    }

    public String getRecruiterName() {
        return recruiterName;
    }

    public void setRecruiterName(String recruiterName) {
        this.recruiterName = recruiterName;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public long getTechnologyId() {
        return technologyId;
    }

    public void setTechnologyId(long technologyId) {
        this.technologyId = technologyId;
    }

    public String getTechnologyName() {
        return technologyName;
    }

    public void setTechnologyName(String technologyName) {
        this.technologyName = technologyName;
    }

    public long getInterviewType() {
        return interviewType;
    }

    public void setInterviewType(long interviewType) {
        this.interviewType = interviewType;
    }

    public String getInterviewTypeName() {
        return interviewTypeName;
    }

    public void setInterviewTypeName(String interviewTypeName) {
        this.interviewTypeName = interviewTypeName;
    }

    public Date getFromTime() {
        return fromTime;
    }

    public void setFromTime(Date fromTime) {
        this.fromTime = fromTime;
    }

    public Date getToTime() {
        return toTime;
    }

    public void setToTime(Date toTime) {
        this.toTime = toTime;
    }

    public InterviewerDto getInterviewerDto() {
        return interviewerDto;
    }

    public void setInterviewerDto(InterviewerDto interviewerDto) {
        this.interviewerDto = interviewerDto;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public long getBuId() {
        return buId;
    }

    public void setBuId(long buId) {
        this.buId = buId;
    }

}
