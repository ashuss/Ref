package com.capgemini.smarthire.dtos;

public class InterviewerDetailsDTO {
	
	private long employeeId;
	private String InterviewerName;
	private String emailId;
	public long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}
	public String getInterviewerName() {
		return InterviewerName;
	}
	public void setInterviewerName(String interviewerName) {
		InterviewerName = interviewerName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	

}
