package com.capgemini.smarthire.dtos;

public class SplitReturnDTO {

    private SplitResultDTO splitResultDTO;
    private Boolean isReturn;
    private Boolean isBreak;
    public SplitResultDTO getSplitResultDTO() {
        return splitResultDTO;
    }
    public void setSplitResultDTO(SplitResultDTO splitResultDTO) {
        this.splitResultDTO = splitResultDTO;
    }
    public Boolean getIsReturn() {
        return isReturn;
    }
    public void setIsReturn(Boolean isReturn) {
        this.isReturn = isReturn;
    }
    public Boolean getIsBreak() {
        return isBreak;
    }
    public void setIsBreak(Boolean isBreak) {
        this.isBreak = isBreak;
    }
}
