package com.capgemini.smarthire.dtos;

import java.util.List;

public class AvailabilityDTO {

	private long empId;
	private String empName;
	private String emailId;
	private String location;
	private String fromDate;
	private String toDate;
	private String bookingDate;
	private String interviewerType;
	private List<String> technologyType;
	
	public long getEmpId() {
		return empId;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getInterviewerType() {
		return interviewerType;
	}
	public void setInterviewerType(String interviewerType) {
		this.interviewerType = interviewerType;
	}
	public List<String> getTechnologyType() {
		return technologyType;
	}
	public void setTechnologyType(List<String> technologyType) {
		this.technologyType = technologyType;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

}
