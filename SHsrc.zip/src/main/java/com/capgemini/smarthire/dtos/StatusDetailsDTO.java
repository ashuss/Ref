package com.capgemini.smarthire.dtos;

import java.util.Date;

public class StatusDetailsDTO {
	
	private Date fromtime;
	private Date totime;
	private InterviewerDetailsDTO interviewerDetails;
	private RecruiterDetailsDTO recruiterDetails;
	private String feedbackComments;
	public Date getFromtime() {
		return fromtime;
	}
	public void setFromtime(Date fromtime) {
		this.fromtime = fromtime;
	}
	public Date getTotime() {
		return totime;
	}
	public void setTotime(Date totime) {
		this.totime = totime;
	}
	public InterviewerDetailsDTO getInterviewerDetails() {
		return interviewerDetails;
	}
	public void setInterviewerDetails(InterviewerDetailsDTO interviewerDetails) {
		this.interviewerDetails = interviewerDetails;
	}
	public RecruiterDetailsDTO getRecruiterDetails() {
		return recruiterDetails;
	}
	public void setRecruiterDetails(RecruiterDetailsDTO recruiterDetails) {
		this.recruiterDetails = recruiterDetails;
	}
	public String getFeedbackComments() {
		return feedbackComments;
	}
	public void setFeedbackComments(String feedbackComments) {
		this.feedbackComments = feedbackComments;
	}
	
	
	

}
