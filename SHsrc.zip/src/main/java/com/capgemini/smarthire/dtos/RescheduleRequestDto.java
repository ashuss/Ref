package com.capgemini.smarthire.dtos;

public class RescheduleRequestDto {

	private long calendarId;

	public long getCalendarId() {
		return calendarId;
	}

	public void setCalendarId(long calendarId) {
		this.calendarId = calendarId;
	}

}
