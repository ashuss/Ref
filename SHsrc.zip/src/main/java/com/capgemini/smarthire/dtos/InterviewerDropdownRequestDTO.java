package com.capgemini.smarthire.dtos;

import java.util.Date;

public class InterviewerDropdownRequestDTO {

    private Date fromTime;
    private Date toTime;
    private long technologyId;
    private long interviewTypeId;
    private long buId;

    public Date getFromTime() {
        return fromTime;
    }

    public void setFromTime(Date fromTime) {
        this.fromTime = fromTime;
    }

    public Date getToTime() {
        return toTime;
    }

    public void setToTime(Date toTime) {
        this.toTime = toTime;
    }

    public long getTechnologyId() {
        return technologyId;
    }

    public void setTechnologyId(long technologyId) {
        this.technologyId = technologyId;
    }

    public long getInterviewTypeId() {
        return interviewTypeId;
    }

    public void setInterviewTypeId(long interviewTypeId) {
        this.interviewTypeId = interviewTypeId;
    }

    public long getBuId() {
        return buId;
    }

    public void setBuId(long buId) {
        this.buId = buId;
    }

}
