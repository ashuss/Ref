package com.capgemini.smarthire.dtos;

import java.io.Reader;
import java.util.List;

public class SplitResultDTO {

    private List<String> fields;
    private StringBuilder sbuf;
    private Boolean isReturn;
    private Boolean isBreak;
    private Boolean isBuf;
    private Boolean returnValue;
    private Reader in;
    private Boolean isReader;
    public List<String> getFields() {
        return fields;
    }
    public void setFields(List<String> fields) {
        this.fields = fields;
    }
    public StringBuilder getSbuf() {
        return sbuf;
    }
    public void setSbuf(StringBuilder sbuf) {
        this.sbuf = sbuf;
    }
    public Boolean getIsReturn() {
        return isReturn;
    }
    public void setIsReturn(Boolean isReturn) {
        this.isReturn = isReturn;
    }
    public Boolean getIsBreak() {
        return isBreak;
    }
    public void setIsBreak(Boolean isBreak) {
        this.isBreak = isBreak;
    }
    public Boolean getReturnValue() {
        return returnValue;
    }
    public void setReturnValue(Boolean returnValue) {
        this.returnValue = returnValue;
    }
    public Boolean getIsBuf() {
        return isBuf;
    }
    public void setIsBuf(Boolean isBuf) {
        this.isBuf = isBuf;
    }
    public Reader getIn() {
        return in;
    }
    public void setIn(Reader in) {
        this.in = in;
    }
    public Boolean getIsReader() {
        return isReader;
    }
    public void setIsReader(Boolean isReader) {
        this.isReader = isReader;
    }
    
}
