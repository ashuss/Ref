package com.capgemini.smarthire.dtos;

import java.util.Date;
import java.util.List;

public class SlotDetailsDTO {

	private Date fromDate;
	private Date toDate;
	private String candidateName;
	private FeedbackDetailsDTO feedbackDetails;
	private RecruiterDetailsDTO recruiterDetails;
	
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public FeedbackDetailsDTO getFeedbackDetails() {
		return feedbackDetails;
	}
	public void setFeedbackDetails(FeedbackDetailsDTO feedbackDetails) {
		this.feedbackDetails = feedbackDetails;
	}
	public RecruiterDetailsDTO getRecruiterDetails() {
		return recruiterDetails;
	}
	public void setRecruiterDetails(RecruiterDetailsDTO recruiterDetails) {
		this.recruiterDetails = recruiterDetails;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
}
