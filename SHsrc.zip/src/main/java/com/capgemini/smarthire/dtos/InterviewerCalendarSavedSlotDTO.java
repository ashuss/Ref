package com.capgemini.smarthire.dtos;

import java.util.Date;

public class InterviewerCalendarSavedSlotDTO {

    private long interviewerCalenderId;

    private long interviewerId;

    private String interviewerName;

    private String email;

    private String location;

    private String grade;

    private Date fromTime;

    private Date toTime;

    public long getInterviewerCalenderId() {
        return interviewerCalenderId;
    }

    public void setInterviewerCalenderId(long interviewerCalenderId) {
        this.interviewerCalenderId = interviewerCalenderId;
    }

    public long getInterviewerId() {
        return interviewerId;
    }

    public void setInterviewerId(long interviewerId) {
        this.interviewerId = interviewerId;
    }

    public String getInterviewerName() {
        return interviewerName;
    }

    public void setInterviewerName(String interviewerName) {
        this.interviewerName = interviewerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public Date getFromTime() {
        return fromTime;
    }

    public void setFromTime(Date fromTime) {
        this.fromTime = fromTime;
    }

    public Date getToTime() {
        return toTime;
    }

    public void setToTime(Date toTime) {
        this.toTime = toTime;
    }
}
