package com.capgemini.smarthire.dtos;

import java.util.Date;

public class SmarthireReportDTO {

	private Date fromTime;
	private Date toTime;
	private String interviewerEmailId;
	private long techId;
	private String supervisorEmailId;
	private long interviewTypeId;
	private String recruiterEmailId;

	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public Date getToTime() {
		return toTime;
	}

	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}

	public String getInterviewerEmailId() {
		return interviewerEmailId;
	}

	public void setInterviewerEmailId(String interviewerEmailId) {
		this.interviewerEmailId = interviewerEmailId;
	}

	public long getTechId() {
		return techId;
	}

	public void setTechId(long techId) {
		this.techId = techId;
	}

	public String getSupervisorEmailId() {
		return supervisorEmailId;
	}

	public void setSupervisorEmailId(String supervisorEmailId) {
		this.supervisorEmailId = supervisorEmailId;
	}

	public long getInterviewTypeId() {
		return interviewTypeId;
	}

	public void setInterviewTypeId(long interviewTypeId) {
		this.interviewTypeId = interviewTypeId;
	}

	public String getRecruiterEmailId() {
		return recruiterEmailId;
	}

	public void setRecruiterEmailId(String recruiterEmailId) {
		this.recruiterEmailId = recruiterEmailId;
	}

}
