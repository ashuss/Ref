package com.capgemini.smarthire.dtos;

public class SupervisorDTO {

	private String supervisiorEmailId;
	private String resourceEmailId;

	public String getSupervisiorEmailId() {
		return supervisiorEmailId;
	}

	public void setSupervisiorEmailId(String supervisiorEmailId) {
		this.supervisiorEmailId = supervisiorEmailId;
	}

	public String getResourceEmailId() {
		return resourceEmailId;
	}

	public void setResourceEmailId(String resourceEmailId) {
		this.resourceEmailId = resourceEmailId;
	}

}
