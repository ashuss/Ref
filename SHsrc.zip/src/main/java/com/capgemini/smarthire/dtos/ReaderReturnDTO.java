package com.capgemini.smarthire.dtos;

import java.io.Reader;

public class ReaderReturnDTO {
    
    private Reader returnReader;
    
    private Boolean isReturn;

    public Reader getReturnReader() {
        return returnReader;
    }

    public void setReturnReader(Reader returnReader) {
        this.returnReader = returnReader;
    }

    public Boolean getIsReturn() {
        return isReturn;
    }

    public void setIsReturn(Boolean isReturn) {
        this.isReturn = isReturn;
    }
    
    

}
