package com.capgemini.smarthire.dtos;


public class InterviewerSkillDTO {
	
	private String interviwerName;
	private TechnologyDTO technology;
	public String getInterviwerName() {
		return interviwerName;
	}
	public void setInterviwerName(String interviwerName) {
		this.interviwerName = interviwerName;
	}
	public TechnologyDTO getTechnology() {
		return technology;
	}
	public void setTechnology(TechnologyDTO technology) {
		this.technology = technology;
	}
	
	

}
