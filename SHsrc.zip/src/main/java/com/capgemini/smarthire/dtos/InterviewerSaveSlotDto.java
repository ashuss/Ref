package com.capgemini.smarthire.dtos;

import java.util.Date;

public class InterviewerSaveSlotDto {

    private long calendarId;
    private String email;
    private Date fromTime;
    private Date toTime;
    private Long participationTypeId;

    public Long getParticipationTypeId() {
		return participationTypeId;
	}

	public void setParticipationTypeId(Long participationTypeId) {
		this.participationTypeId = participationTypeId;
	}

	public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getFromTime() {
        return fromTime;
    }

    public void setFromTime(Date fromTime) {
        this.fromTime = fromTime;
    }

    public Date getToTime() {
        return toTime;
    }

    public void setToTime(Date toTime) {
        this.toTime = toTime;
    }

    public long getCalendarId() {
        return calendarId;
    }

    public void setCalendarId(long calendarId) {
        this.calendarId = calendarId;
    }

}
