package com.capgemini.smarthire.dtos;

import java.util.List;

public class SlotsDTO {
	private Long interviewerId;
	private String interviewerName;
	private String emailId;
	private Long phoneNo;
	private String interviewerType;
	private long interviewerCount;
	private List<SlotDetailsDTO> slotsDetails;

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public List<SlotDetailsDTO> getSlotsDetails() {
		return slotsDetails;
	}

	public void setSlotsDetails(List<SlotDetailsDTO> slotsDetails) {
		this.slotsDetails = slotsDetails;
	}

	public Long getInterviewerId() {
		return interviewerId;
	}

	public void setInterviewerId(Long interviewerId) {
		this.interviewerId = interviewerId;
	}

	public String getInterviewerName() {
		return interviewerName;
	}

	public void setInterviewerName(String interviewerName) {
		this.interviewerName = interviewerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getInterviewerType() {
		return interviewerType;
	}

	public void setInterviewerType(String interviewerType) {
		this.interviewerType = interviewerType;
	}

	public long getInterviewerCount() {
		return interviewerCount;
	}

	public void setInterviewerCount(long interviewerCount) {
		this.interviewerCount = interviewerCount;
	}

}
