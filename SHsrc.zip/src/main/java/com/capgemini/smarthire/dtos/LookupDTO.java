package com.capgemini.smarthire.dtos;

import org.json.simple.JSONObject;

public class LookupDTO {

    private String dropdownName;
    private JSONObject dropdown;

    public String getDropdownName() {
        return dropdownName;
    }

    public void setDropdownName(String dropdownName) {
        this.dropdownName = dropdownName;
    }

    public JSONObject getDropdown() {
        return dropdown;
    }

    public void setDropdown(JSONObject dropdown) {
        this.dropdown = dropdown;
    }

}
