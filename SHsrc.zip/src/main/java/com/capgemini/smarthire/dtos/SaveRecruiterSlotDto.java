package com.capgemini.smarthire.dtos;

import java.util.Date;

public class SaveRecruiterSlotDto {

    private long recruiterCalendarId;

    private String emailId;

    private String candidateName;

    private long technologyId;

    private long interviewTypeId;

    private Date fromTime;

    private Date toTime;

    private Date oldFromTime;

    private Date oldToTime;

    private String comments;

    private long interviewerId;

    private long buId;

    public long getRecruiterCalendarId() {
        return recruiterCalendarId;
    }

    public void setRecruiterCalendarId(long recruiterCalendarId) {
        this.recruiterCalendarId = recruiterCalendarId;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public long getTechnologyId() {
        return technologyId;
    }

    public void setTechnologyId(long technologyId) {
        this.technologyId = technologyId;
    }

    public long getInterviewTypeId() {
        return interviewTypeId;
    }

    public void setInterviewTypeId(long interviewTypeId) {
        this.interviewTypeId = interviewTypeId;
    }

    public Date getFromTime() {
        return fromTime;
    }

    public void setFromTime(Date fromTime) {
        this.fromTime = fromTime;
    }

    public Date getToTime() {
        return toTime;
    }

    public void setToTime(Date toTime) {
        this.toTime = toTime;
    }

    public long getInterviewerId() {
        return interviewerId;
    }

    public void setInterviewerId(long interviewerId) {
        this.interviewerId = interviewerId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getOldFromTime() {
        return oldFromTime;
    }

    public void setOldFromTime(Date oldFromTime) {
        this.oldFromTime = oldFromTime;
    }

    public Date getOldToTime() {
        return oldToTime;
    }

    public void setOldToTime(Date oldToTime) {
        this.oldToTime = oldToTime;
    }

    public long getBuId() {
        return buId;
    }

    public void setBuId(long buId) {
        this.buId = buId;
    }

}
