package com.capgemini.smarthire.dtos;

import org.json.simple.JSONObject;


public class StatusCountDto {
	
	public String type;
	public StatusTypeDTO status;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public StatusTypeDTO getStatus() {
		return status;
	}
	public void setStatus(StatusTypeDTO status) {
		this.status = status;
	}
	
	
	
	

}
