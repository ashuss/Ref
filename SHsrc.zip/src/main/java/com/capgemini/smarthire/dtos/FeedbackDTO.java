package com.capgemini.smarthire.dtos;

public class FeedbackDTO {

    private long calendarId;

    private String feedbackComments;

    private long feedbackStatusId;
    
    private long participationId;

    public long getParticipationId() {
		return participationId;
	}

	public void setParticipationId(long participationId) {
		this.participationId = participationId;
	}

	public long getCalendarId() {
        return calendarId;
    }

    public void setCalendarId(long calendarId) {
        this.calendarId = calendarId;
    }

    public String getFeedbackComments() {
        return feedbackComments;
    }

    public void setFeedbackComments(String feedbackComments) {
        this.feedbackComments = feedbackComments;
    }

    public long getFeedbackStatusId() {
        return feedbackStatusId;
    }

    public void setFeedbackStatusId(long feedbackStatusId) {
        this.feedbackStatusId = feedbackStatusId;
    }

}
