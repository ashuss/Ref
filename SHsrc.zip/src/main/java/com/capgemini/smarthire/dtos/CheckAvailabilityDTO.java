package com.capgemini.smarthire.dtos;

public class CheckAvailabilityDTO {
	private String emailId;
	private Long interviewerTypeId;
	private Long technologyId;
	private Long buId;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Long getInterviewerTypeId() {
		return interviewerTypeId;
	}
	public void setInterviewerTypeId(Long interviewerTypeId) {
		this.interviewerTypeId = interviewerTypeId;
	}
	@Override
	public String toString() {
		return "CheckAvailabilityDTO [emailId=" + emailId + ", interviewerTypeId=" + interviewerTypeId
				+ ", technologyId=" + technologyId + ", buId=" + buId + "]";
	}
	public Long getTechnologyId() {
		return technologyId;
	}
	public void setTechnologyId(Long technologyId) {
		this.technologyId = technologyId;
	}
	public Long getBuId() {
		return buId;
	}
	public void setBuId(Long buId) {
		this.buId = buId;
	}
	
}	
