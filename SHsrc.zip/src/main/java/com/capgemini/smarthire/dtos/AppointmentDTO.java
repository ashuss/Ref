package com.capgemini.smarthire.dtos;

import java.util.Date;
import java.util.List;

public class AppointmentDTO {
	private String subscriptionKey;
	private String domain;
	private String userId;
	private String password;
	private Date startTime;
	private Date endTime;
	private String body;
	private String interviewerName;
	private String recruiterName;
	private List<String> attendies;

	public String getSubscriptionKey() {
		return subscriptionKey;
	}

	public void setSubscriptionKey(String subscriptionKey) {
		this.subscriptionKey = subscriptionKey;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public List<String> getAttendies() {
		return attendies;
	}

	public void setAttendies(List<String> attendies) {
		this.attendies = attendies;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getInterviewerName() {
		return interviewerName;
	}

	public void setInterviewerName(String interviewerName) {
		this.interviewerName = interviewerName;
	}

	public String getRecruiterName() {
		return recruiterName;
	}

	public void setRecruiterName(String recruiterName) {
		this.recruiterName = recruiterName;
	}

	@Override
	public String toString() {
		return "AppointmentDTO [subscriptionKey=" + subscriptionKey + ", domain=" + domain + ", userId=" + userId
				+ ", password=" + password + ", startTime=" + startTime + ", endTime=" + endTime + ", body=" + body
				+ ", interviewerName=" + interviewerName + ", recruiterName=" + recruiterName + ", attendies="
				+ attendies + "]";
	}

}
