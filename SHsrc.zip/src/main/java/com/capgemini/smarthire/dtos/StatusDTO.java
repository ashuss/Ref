package com.capgemini.smarthire.dtos;

import java.util.List;

public class StatusDTO {
	
	private String status;
	
	private List<StatusDetailsDTO> details;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<StatusDetailsDTO> getDetails() {
		return details;
	}

	public void setDetails(List<StatusDetailsDTO> details) {
		this.details = details;
	}
	
	
	

}
