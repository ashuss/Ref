package com.capgemini.smarthire.dtos;

public class StatusTypeDTO {
	
	private long available;
	private long booked;
	private long interviewed;
	private long notInterviewed;
	public long getAvailable() {
		return available;
	}
	public void setAvailable(long available) {
		this.available = available;
	}
	public long getBooked() {
		return booked;
	}
	public void setBooked(long booked) {
		this.booked = booked;
	}
	public long getInterviewed() {
		return interviewed;
	}
	public void setInterviewed(long interviewed) {
		this.interviewed = interviewed;
	}
	public long getNotInterviewed() {
		return notInterviewed;
	}
	public void setNotInterviewed(long notInterviewed) {
		this.notInterviewed = notInterviewed;
	}
	
	
	

}
