package com.capgemini.smarthire.dtos;

import org.json.simple.JSONObject;

public class InterviewerCalenderDetailsDto {

	private long calendarId;
	private long id;
	private SlotDto slot;
	private boolean isBooked;
	private JSONObject details;
	private JSONObject interviewDetails;
	private long participationTypeId;

	public JSONObject getInterviewDetails() {
		return interviewDetails;
	}

	public void setInterviewDetails(JSONObject interviewDetails) {
		this.interviewDetails = interviewDetails;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public SlotDto getSlot() {
		return slot;
	}

	public void setSlot(SlotDto slot) {
		this.slot = slot;
	}

	public boolean isBooked() {
		return isBooked;
	}

	public void setBooked(boolean isBooked) {
		this.isBooked = isBooked;
	}

	public JSONObject getDetails() {
		return details;
	}

	public void setDetails(JSONObject details) {
		this.details = details;
	}

	public long getCalendarId() {
		return calendarId;
	}

	public void setCalendarId(long calendarId) {
		this.calendarId = calendarId;
	}

	public long getParticipationTypeId() {
		return participationTypeId;
	}

	public void setParticipationTypeId(long participationTypeId) {
		this.participationTypeId = participationTypeId;
	}

}
