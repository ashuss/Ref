package com.capgemini.smarthire.dtos;

import java.util.List;

public class ReportDTO {

	private String status;
	private Long statusCount;
	private List<SlotsDTO> slotsDTO;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getStatusCount() {
		return statusCount;
	}
	public void setStatusCount(Long statusCount) {
		this.statusCount = statusCount;
	}
	public List<SlotsDTO> getSlotsDTO() {
		return slotsDTO;
	}
	public void setSlotsDTO(List<SlotsDTO> slotsDTO) {
		this.slotsDTO = slotsDTO;
	}
}
