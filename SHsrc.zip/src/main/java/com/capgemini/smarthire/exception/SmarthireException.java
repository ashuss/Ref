package com.capgemini.smarthire.exception;

public class SmarthireException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public SmarthireException() {
        super();
       
    }

    public SmarthireException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
       
    }

    public SmarthireException(String message, Throwable cause) {
        super(message, cause);
        
    }

    public SmarthireException(String message) {
        super(message);
        
    }

    public SmarthireException(Throwable cause) {
        super(cause);
        
    }

}
