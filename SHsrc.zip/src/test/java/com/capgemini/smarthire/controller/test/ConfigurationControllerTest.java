package com.capgemini.smarthire.controller.test;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.capgemini.smarthire.controller.ConfigurationController;
import com.capgemini.smarthire.dtos.ResponseDto;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.services.ConfigurationService;
import com.jcabi.log.Logger;

import static org.mockito.BDDMockito.given;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ConfigurationControllerTest {
    
    private static final String EXCEPTION_MESSAGE = "Exception is";

    @Autowired
    ConfigurationController configurationController;

    @Autowired 
    private MockMvc mvc;

    @MockBean
    ConfigurationService configuraionService;

    @Before
    public void setUp() {
        mvc = MockMvcBuilders.standaloneSetup(this.configurationController).build();
    }

    @Test
    public void getAllConfigurationConstantsTest() {
        ResponseDto responseDto = new ResponseDto();
        Map<String, String> constantsMap = new HashMap<>();
        constantsMap.put("slotDuration", "1");
        List<Object> response = new ArrayList<>();
        response.add(constantsMap);
        responseDto.setResponse(response);

        try {
            given(this.configuraionService.getAllConstants()).willReturn(constantsMap);
        } catch (SmarthireException e) {
            
            Logger.info(e, EXCEPTION_MESSAGE);
        }

        try {
            mvc.perform(get("/configuration/constants").contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk()).andExpect(jsonPath("$.response", is(response)));
        } catch (Exception e) {
            Logger.info(e, EXCEPTION_MESSAGE);
        }

    }

}
