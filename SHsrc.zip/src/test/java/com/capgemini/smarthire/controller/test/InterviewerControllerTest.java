package com.capgemini.smarthire.controller.test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.capgemini.smarthire.Application;
import com.capgemini.smarthire.controller.InterviewerController;
import com.capgemini.smarthire.dtos.EmailDto;
import com.capgemini.smarthire.dtos.InterviewerCalendarSavedSlotDTO;
import com.capgemini.smarthire.dtos.InterviewerCalenderDetailsDto;
import com.capgemini.smarthire.dtos.InterviewerDropdownDTO;
import com.capgemini.smarthire.dtos.InterviewerDropdownRequestDTO;
import com.capgemini.smarthire.dtos.InterviewerSaveSlotDto;
import com.capgemini.smarthire.dtos.ResponseDto;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.services.Messages;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
public class InterviewerControllerTest {

    private static final String EMAIL = Messages.getString("akshatemail");
    private static final long TECHID = 1L;
    private static final long INTERVIEWTYPEID = 1L;
    private static final Timestamp FROMTIME = new Timestamp(Long.parseLong("1530183600000"));
    private static final Timestamp TOTIME = new Timestamp(Long.parseLong("1530187200000"));
    private static final Timestamp DROPDOWNFROMTIME = new Timestamp(Long.parseLong("1521181800000"));
    private static final Timestamp DROPDOWNTOTIME = new Timestamp(Long.parseLong("1521185400000"));
    private static final long DELETECALENDARID = 7L;
    private static final long SAVECALENDARID = 0;

    @Autowired
    InterviewerController interviewerController;

    @Test
    public void getAllInterviewerSlotsTest() throws SmarthireException {
        ResponseDto responseExpected = new ResponseDto();

        InterviewerCalenderDetailsDto interviewerCalendar = new InterviewerCalenderDetailsDto();
        interviewerCalendar.setCalendarId(1);
        List<InterviewerCalenderDetailsDto> interviewerCalendarListExpected = new ArrayList<>();
        interviewerCalendarListExpected.add(interviewerCalendar);
        List<Object> response = new ArrayList<>();
        response.add(interviewerCalendarListExpected);
        responseExpected.setResponse(response);

        EmailDto email = new EmailDto();
        email.setEmail(EMAIL);
        ResponseDto responseActual = interviewerController.getAllInterviewerSlots(email);

        Assert.assertNotEquals(responseExpected, responseActual);

    }

    @Test
    @Transactional
    @Rollback(true)
    public void saveFreeSlotTest() {
        ResponseDto responseExpected = new ResponseDto();
        InterviewerCalendarSavedSlotDTO interviewerCalendarSavedSlotExpected = new InterviewerCalendarSavedSlotDTO();
        interviewerCalendarSavedSlotExpected.setEmail(EMAIL);
        List<Object> response = new ArrayList<>();
        response.add(interviewerCalendarSavedSlotExpected);
        responseExpected.setResponse(response);

        InterviewerSaveSlotDto interviewerSaveSlotDto = new InterviewerSaveSlotDto();
        interviewerSaveSlotDto.setCalendarId(SAVECALENDARID);
        interviewerSaveSlotDto.setEmail(EMAIL);
        interviewerSaveSlotDto.setFromTime(FROMTIME);
        interviewerSaveSlotDto.setToTime(TOTIME);

        ResponseDto responseActual = interviewerController.saveFreeSlot(interviewerSaveSlotDto);
        InterviewerCalendarSavedSlotDTO interviewerCalendarSavedSlotFinal = (InterviewerCalendarSavedSlotDTO) responseActual
                .getResponse().get(0);

        Assert.assertEquals(interviewerCalendarSavedSlotExpected.getEmail(),
                interviewerCalendarSavedSlotFinal.getEmail());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void fetchInterviewerDropdownControllerTest() {
        InterviewerDropdownDTO interviewer = new InterviewerDropdownDTO();
        interviewer.setInterviewerId(1);
        List<InterviewerDropdownDTO> interviewerListExpected = new ArrayList<>();
        interviewerListExpected.add(interviewer);

        InterviewerDropdownRequestDTO interviewerDropdownRequestDTO = new InterviewerDropdownRequestDTO();
        interviewerDropdownRequestDTO.setTechnologyId(TECHID);
        interviewerDropdownRequestDTO.setInterviewTypeId(INTERVIEWTYPEID);
        interviewerDropdownRequestDTO.setFromTime(DROPDOWNFROMTIME);
        interviewerDropdownRequestDTO.setToTime(DROPDOWNTOTIME);

        ResponseDto responseFinal = interviewerController.fetchInterviewerDropdown(interviewerDropdownRequestDTO);
        List<InterviewerDropdownDTO> interviewerListFinal = (List<InterviewerDropdownDTO>) responseFinal.getResponse().get(0);

        Assert.assertEquals(interviewerListExpected.size(), interviewerListFinal.size());
    }

    @Test
    @Transactional
    @Rollback(true)
    public void deleteInterviewSlotTest() {
        Boolean deleteSuccessExpected = true;

        ResponseDto responseFinal = interviewerController.deleteInterviewSlot(DELETECALENDARID);
        Boolean deleteSuccessActual = (Boolean) responseFinal.getResponse().get(0);

        Assert.assertEquals(deleteSuccessExpected, deleteSuccessActual);
    }

}
