package com.capgemini.smarthire.service.test;


import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.smarthire.Application;
import com.capgemini.smarthire.exception.SmarthireException;
import com.capgemini.smarthire.services.ConfigurationService;
import com.jcabi.log.Logger;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
public class ConfigurationServiceTest {
    
    private static final String EXCEPTION_MESSAGE = "Exception is";

    @Autowired
    ConfigurationService configurationService;

    @Test
    public void getAllConstantsTest() {
        Map<String, String> configConstantsExpected = new HashMap<>();
        configConstantsExpected.put("slotDuration", "1");

        Map<String, String> configConstantsActual = new HashMap<>();
        try {
            configConstantsActual = configurationService.getAllConstants();
        } catch (SmarthireException e) {
            Logger.info(e, EXCEPTION_MESSAGE);
        }

        Assert.assertNotEquals(configConstantsExpected.size(), configConstantsActual.size());
    } 

}
